<?php

namespace Database\Seeders;

use App\Models\Market;
use App\Models\User;
use App\Support\Catalog;
use Illuminate\Database\Seeder;

/**
 * Turns the market names farmers already saved on their profiles into real
 * market records (and pivot links). Idempotent — safe to re-run.
 */
class MarketSeeder extends Seeder
{
    public function run(): void
    {
        $farmers = User::where('role', User::ROLE_FARMER)->with('farmer')->get();

        foreach ($farmers as $farmer) {
            $names = $farmer->farmer?->markets ?? [];

            if ($names === []) {
                continue;
            }

            Market::syncForFarmer(
                $farmer,
                $names,
                Catalog::cityOf($farmer->farmer?->address ?? $farmer->address),
                $farmer->farmer?->operating_days ?? []
            );
        }
    }
}
