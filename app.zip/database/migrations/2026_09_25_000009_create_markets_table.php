<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /** Real markets table (admin CRUD + public market pages). */
    public function up(): void
    {
        Schema::create('markets', function (Blueprint $table) {
            $table->id();
            $table->string('name')->unique();
            $table->string('city')->nullable();
            $table->string('address')->nullable();
            $table->json('days')->nullable();
            $table->string('open_time', 8)->nullable();
            $table->string('close_time', 8)->nullable();
            $table->text('description')->nullable();
            $table->string('image')->nullable();
            $table->string('google_maps_url')->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        Schema::create('farmer_market', function (Blueprint $table) {
            $table->id();
            $table->foreignId('farmer_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('market_id')->constrained('markets')->cascadeOnDelete();
            $table->timestamps();
            $table->unique(['farmer_id', 'market_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('farmer_market');
        Schema::dropIfExists('markets');
    }
};
