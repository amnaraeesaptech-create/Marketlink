<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

/**
 * SRS gap-closure migration.
 *
 * Adds the pieces the MarketLink SRS asks for that were still missing:
 *  - farmers.cutoff_hours        → "farmers can set order cut-off times"
 *  - markets lat/long            → map markers (Google Maps API / OpenStreetMap)
 *  - reviews.product_id          → "rate and review Farmers AND individual products"
 *  - reviews.farmer_reply        → "farmers can respond to customer reviews"
 *  - favorites.farmer_id / market_id → "save favourite Farmers / preferred markets"
 *  - app_notifications           → in-app alerts for order confirmation & ready-for-pickup
 *  - categories                  → admin master data
 *  - announcements               → platform-wide notifications
 */
return new class extends Migration
{
    public function up(): void
    {
        Schema::table('farmers', function (Blueprint $table) {
            $table->unsignedSmallInteger('cutoff_hours')->default(12)->after('pickup_windows');
        });

        Schema::table('markets', function (Blueprint $table) {
            $table->decimal('latitude', 10, 7)->nullable()->after('google_maps_url');
            $table->decimal('longitude', 10, 7)->nullable()->after('latitude');
        });

        Schema::table('reviews', function (Blueprint $table) {
            $table->unsignedBigInteger('product_id')->nullable()->after('farmer_id');
            $table->text('farmer_reply')->nullable()->after('comment');
            $table->timestamp('replied_at')->nullable()->after('farmer_reply');
        });

        Schema::table('favorites', function (Blueprint $table) {
            $table->unsignedBigInteger('farmer_id')->nullable()->after('product_id');
            $table->unsignedBigInteger('market_id')->nullable()->after('farmer_id');
        });

        Schema::create('app_notifications', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id');
            $table->string('type', 40)->default('info');
            $table->string('title', 150);
            $table->text('body')->nullable();
            $table->string('url', 255)->nullable();
            $table->timestamp('read_at')->nullable();
            $table->timestamps();

            $table->index(['user_id', 'read_at']);
        });

        Schema::create('categories', function (Blueprint $table) {
            $table->id();
            $table->string('name', 60)->unique();
            $table->string('description', 255)->nullable();
            $table->boolean('is_active')->default(true);
            $table->unsignedSmallInteger('sort_order')->default(0);
            $table->timestamps();
        });

        Schema::create('announcements', function (Blueprint $table) {
            $table->id();
            $table->string('title', 150);
            $table->text('body');
            $table->string('audience', 20)->default('all'); // all | customers | farmers
            $table->boolean('is_active')->default(true);
            $table->timestamp('published_at')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::table('farmers', fn (Blueprint $t) => $t->dropColumn('cutoff_hours'));
        Schema::table('markets', fn (Blueprint $t) => $t->dropColumn(['latitude', 'longitude']));
        Schema::table('reviews', fn (Blueprint $t) => $t->dropColumn(['product_id', 'farmer_reply', 'replied_at']));
        Schema::table('favorites', fn (Blueprint $t) => $t->dropColumn(['farmer_id', 'market_id']));
        Schema::dropIfExists('app_notifications');
        Schema::dropIfExists('categories');
        Schema::dropIfExists('announcements');
    }
};
