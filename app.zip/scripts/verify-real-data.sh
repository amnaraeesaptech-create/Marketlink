#!/usr/bin/env bash
# ============================================================================
#  MarketLink — end-to-end "real data only" verification
#
#  Drives the running app over HTTP (registration, logins, product CRUD,
#  pre-orders, favorites, reviews, order status, admin moderation + market CRUD)
#  and checks the SQLite database after every write.
#
#  Usage:  bash scripts/verify-real-data.sh [base-url]
# ============================================================================
set -uo pipefail

BASE="${1:-http://127.0.0.1:8000}"
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DB="$DIR/database/database.sqlite"
JAR="$(mktemp)"
PASS=0
FAIL=0

c_ok()   { printf "  \033[32m✓\033[0m %s\n" "$1"; PASS=$((PASS+1)); }
c_bad()  { printf "  \033[31m✗\033[0m %s\n" "$1"; FAIL=$((FAIL+1)); }
head_()  { printf "\n\033[1m%s\033[0m\n" "$1"; }

# --- tiny helpers -----------------------------------------------------------
db() {
  DB_PATH="$DB" Q="$1" php -r 'try {
      $db = new PDO("sqlite:" . getenv("DB_PATH"));
      $stmt = $db->query(getenv("Q"));
      $v = $stmt ? $stmt->fetchColumn() : "";
      echo $v === false ? "" : $v;
    } catch (Throwable $e) { echo ""; }'
}

assert_eq() { [ "$2" == "$3" ] && c_ok "$1 ($3)" || c_bad "$1 — expected '$3', got '$2'"; }
assert_ge() { [ "${2:-0}" -ge "$3" ] 2>/dev/null && c_ok "$1 ($2)" || c_bad "$1 — expected >= $3, got '$2'"; }

# One CSRF token per session is enough for every form in that session.
TOKEN=""
refresh_token() { # refresh_token <page-with-a-form>
  TOKEN="$(curl -s -b "$JAR" -c "$JAR" "$BASE$1" | grep -o 'name="_token" value="[^"]*"' | head -1 | sed 's/.*value="//;s/"$//')"
}

post() { # post <path> <data...>
  local path="$1"; shift
  [ -z "$TOKEN" ] && refresh_token "/"
  curl -s -b "$JAR" -c "$JAR" -o /tmp/ml_body -w '%{http_code}' -X POST \
       -H "X-CSRF-TOKEN: $TOKEN" -d "_token=$TOKEN" "$@" "$BASE$path"
}

get() { curl -s -b "$JAR" -c "$JAR" -o /tmp/ml_page -w '%{http_code}' "$BASE$1"; }

logout() { # end the current session and drop the stale token
  TOKEN=""
  refresh_token "/"
  post /logout >/dev/null
  TOKEN=""
}

login() { # login <login-path> <email> <password>
  logout
  refresh_token "$1"
  post "$1" -d "email=$2" -d "password=$3" >/dev/null
  TOKEN=""
}

# ===========================================================================
STAMP="$(date +%s)"
FARMER_EMAIL="verify.farmer.$STAMP@marketlink.test"
CLIENT_EMAIL="verify.client.$STAMP@marketlink.test"

head_ "1. Health check"
for p in / /farmers /markets /products /cart /about /contact /login /farmer-login /admin-login /data-feed.js; do
  code=$(curl -s -o /dev/null -w '%{http_code}' "$BASE$p")
  [ "$code" == "200" ] && c_ok "GET $p → 200" || c_bad "GET $p → $code"
done

# ===========================================================================
head_ "2. Farmer registration → farmer dashboard (real login wiring)"
post /farmer-register \
  -d "stall_name=Verify Stall $STAMP" \
  -d "contact_person=Verify Farmer" \
  -d "phone=0300 9998887" \
  -d "email=$FARMER_EMAIL" \
  -d "address=Test Farm Road, Karachi" \
  -d "markets[]=Verify Signup Market $STAMP" \
  -d "operating_days[]=Sat" \
  -d "categories[]=Vegetables" \
  -d "password=Verify@123" -d "password_confirmation=Verify@123" -d "terms=1" >/dev/null
FARMER_ID=$(db "SELECT id FROM users WHERE email='$FARMER_EMAIL'")
assert_ge "farmer account row created" "$FARMER_ID" 1
assert_eq "new farmer linked to a real market row" "$(db "SELECT COUNT(*) FROM farmer_market WHERE farmer_id=$FARMER_ID")" "1"

refresh_token /farmer-dashboard
code=$(get /farmer-dashboard)
assert_eq "farmer lands on /farmer-dashboard after signup" "$code" "200"
grep -q "Verify Stall $STAMP" /tmp/ml_page && c_ok "dashboard shows the real stall name" || c_bad "dashboard missing stall name"
assert_eq "new farmer starts un-approved (SRS admin approval)" "$(db "SELECT is_approved FROM farmers WHERE user_id=$FARMER_ID")" "0"
curl -s "$BASE/data-feed.js" | grep -q "Verify Stall $STAMP" && c_bad "unapproved stall leaked into the storefront feed" || c_ok "unapproved stall hidden from /data-feed.js"

# admin approval gate: /admin-farmers/{id}/approve flips the real column
logout
login /admin-login "admin@marketlink.com" "Admin@123"
post "/admin-farmers/$FARMER_ID/approve" >/dev/null
assert_eq "admin APPROVE sets farmers.is_approved" "$(db "SELECT is_approved FROM farmers WHERE user_id=$FARMER_ID")" "1"
logout
login /farmer-login "$FARMER_EMAIL" "Verify@123"
refresh_token /farmer-dashboard
curl -s "$BASE/data-feed.js" | grep -q "Verify Stall $STAMP" && c_ok "approved stall now served in /data-feed.js" || c_bad "approved stall still missing from the feed"
logout

# ===========================================================================
head_ "3. Farmer login → dashboard + product CRUD"
login /farmer-login "$FARMER_EMAIL" "Verify@123"
refresh_token /farmer-dashboard
code=$(get /farmer-dashboard)
assert_eq "farmer login reaches dashboard" "$code" "200"

# CREATE
post /farmer-products \
  -d "name=Verify Tomatoes $STAMP" -d "category=Vegetables" -d "price=123" \
  -d "unit=kg" -d "stock=20" -d "description=Created by verification script" \
  -d "is_available=1" >/dev/null
PROD_ID=$(db "SELECT id FROM products WHERE name='Verify Tomatoes $STAMP'")
assert_ge "product CREATE wrote a real row" "$PROD_ID" 1
assert_eq "product belongs to the logged-in farmer" "$(db "SELECT farmer_id FROM products WHERE id=$PROD_ID")" "$FARMER_ID"

# UPDATE
post "/farmer-products/$PROD_ID" -d "_method=PUT" -d "name=Verify Tomatoes $STAMP" \
  -d "category=Vegetables" -d "price=150" -d "unit=kg" -d "stock=33" \
  -d "description=Updated by verification script" -d "is_available=1" >/dev/null
assert_eq "product UPDATE persisted (price)" "$(db "SELECT price FROM products WHERE id=$PROD_ID")" "150"
assert_eq "product UPDATE persisted (stock)" "$(db "SELECT stock FROM products WHERE id=$PROD_ID")" "33"

# TOGGLE availability
post "/farmer-products/$PROD_ID/toggle" >/dev/null
assert_eq "availability TOGGLE persisted" "$(db "SELECT is_available FROM products WHERE id=$PROD_ID")" "0"
post "/farmer-products/$PROD_ID/toggle" >/dev/null

# public pages must show the new product (fetch = real)
curl -s -o /tmp/pub1.html -w '%{http_code}' "$BASE/product-details?id=$PROD_ID" > /tmp/pub1.code
if grep -q "Verify Tomatoes $STAMP" /tmp/pub1.html; then
  c_ok "product FETCH on /product-details shows the new row"
else
  c_bad "product not visible on /product-details (http $(cat /tmp/pub1.code))"
fi
curl -s -o /tmp/pub2.html -w '%{http_code}' "$BASE/farmers" > /tmp/pub2.code
if grep -q "Verify Stall $STAMP" /tmp/pub2.html; then
  c_ok "new stall FETCH on /farmers"
else
  c_bad "new stall missing on /farmers (http $(cat /tmp/pub2.code))"
fi
curl -s "$BASE/data-feed.js" | grep -q "Verify Tomatoes $STAMP" && c_ok "new product FETCH in /data-feed.js" || c_bad "feed not updated"

# ===========================================================================
head_ "4. Client registration → client dashboard, favorites, pre-order, review"
logout
post /register -d "name=Verify Client" -d "phone=0300 7776665" -d "email=$CLIENT_EMAIL" \
  -d "address=Test Street 1, Karachi" -d "city=Karachi" \
  -d "password=Verify@123" -d "password_confirmation=Verify@123" -d "terms=1" >/dev/null
CLIENT_ID=$(db "SELECT id FROM users WHERE email='$CLIENT_EMAIL'")
assert_ge "client account row created" "$CLIENT_ID" 1
refresh_token /customer-dashboard
code=$(get /customer-dashboard)
assert_eq "client lands on /customer-dashboard after signup" "$code" "200"

# favorite toggle (AJAX JSON)
T="$TOKEN"
curl -s -b "$JAR" -c "$JAR" -H "X-CSRF-TOKEN: $T" -H "Accept: application/json" \
     -d "_token=$T" -d "product_id=$PROD_ID" "$BASE/favorites/toggle" > /tmp/fav.json
assert_eq "favorite ADD persisted" "$(db "SELECT COUNT(*) FROM favorites WHERE customer_id=$CLIENT_ID AND product_id=$PROD_ID")" "1"
curl -s -b "$JAR" -c "$JAR" -H "X-CSRF-TOKEN: $T" -H "Accept: application/json" \
     -d "_token=$T" -d "product_id=$PROD_ID" "$BASE/favorites/toggle" > /dev/null
assert_eq "favorite REMOVE persisted" "$(db "SELECT COUNT(*) FROM favorites WHERE customer_id=$CLIENT_ID AND product_id=$PROD_ID")" "0"

# pre-order (stock must decrement)
STOCK_BEFORE=$(db "SELECT stock FROM products WHERE id=$PROD_ID")
PICKUP=$(date -d "+3 days" +%Y-%m-%d 2>/dev/null || date -v+3d +%Y-%m-%d)
post /preorder -d "market=Verify Market $STAMP" -d "pickup_date=$PICKUP" -d "pickup_slot=8:00 AM - 9:00 AM" \
  -d "notes=verify script order" -d "items_json=[{\"id\":$PROD_ID,\"qty\":2}]" >/dev/null
ORDER_ID=$(db "SELECT MAX(id) FROM orders WHERE customer_id=$CLIENT_ID")
assert_ge "pre-order CREATE wrote a real order" "$ORDER_ID" 1
assert_eq "order total computed from real price" "$(db "SELECT subtotal FROM orders WHERE id=$ORDER_ID")" "300"
assert_eq "order line item stored" "$(db "SELECT COUNT(*) FROM order_items WHERE order_id=$ORDER_ID")" "1"
assert_eq "stock decremented by 2" "$(db "SELECT stock FROM products WHERE id=$PROD_ID")" "$((STOCK_BEFORE-2))"

# customer cancels -> stock restored
post "/customer-orders/$ORDER_ID/cancel" >/dev/null
assert_eq "cancel sets status" "$(db "SELECT status FROM orders WHERE id=$ORDER_ID")" "cancelled"
assert_eq "stock restored on cancel" "$(db "SELECT stock FROM products WHERE id=$PROD_ID")" "$STOCK_BEFORE"

# review flow on a completed order
post /preorder -d "market=Verify Market $STAMP" -d "pickup_date=$PICKUP" -d "pickup_slot=9:00 AM - 10:00 AM" \
  -d "items_json=[{\"id\":$PROD_ID,\"qty\":1}]" >/dev/null
ORDER2=$(db "SELECT MAX(id) FROM orders WHERE customer_id=$CLIENT_ID")
post "/reviews" -d "order_id=$ORDER2" -d "rating=4" -d "comment=Should be rejected: order not completed" >/dev/null
assert_eq "review blocked before completion" "$(db "SELECT COUNT(*) FROM reviews WHERE order_id=$ORDER2")" "0"

# farmer completes it, then the review is allowed
login /farmer-login "$FARMER_EMAIL" "Verify@123"
post "/farmer-orders/$ORDER2/status" -d "status=confirmed" >/dev/null
post "/farmer-orders/$ORDER2/status" -d "status=ready" >/dev/null
post "/farmer-orders/$ORDER2/status" -d "status=completed" >/dev/null
assert_eq "farmer status UPDATE persisted" "$(db "SELECT status FROM orders WHERE id=$ORDER2")" "completed"

login /login "$CLIENT_EMAIL" "Verify@123"
refresh_token /customer-dashboard
post /reviews -d "order_id=$ORDER2" -d "rating=5" -d "comment=Verification review $STAMP" >/dev/null
REVIEW_ID=$(db "SELECT id FROM reviews WHERE order_id=$ORDER2")
assert_ge "review CREATE persisted" "$REVIEW_ID" 1
assert_eq "farmer rating reflects the new review" "$(db "SELECT COUNT(*) FROM reviews WHERE farmer_id=$FARMER_ID")" "1"
curl -s -o /tmp/rev.html -w '%{http_code}' "$BASE/farmer-profile?id=$FARMER_ID" > /tmp/rev.code
if grep -q "Verification review $STAMP" /tmp/rev.html; then
  c_ok "review FETCH on the public stall profile"
else
  c_bad "review not shown on stall profile (http $(cat /tmp/rev.code), stall hits: $(grep -c "Verify Stall" /tmp/rev.html))"
fi

post "/reviews/$REVIEW_ID" -d "_method=DELETE" >/dev/null
assert_eq "review DELETE persisted" "$(db "SELECT COUNT(*) FROM reviews WHERE id=$REVIEW_ID")" "0"

# ===========================================================================
head_ "5. Admin: real counts, market CRUD, moderation"
login /admin-login "admin@marketlink.com" "Admin@123"
refresh_token /admin-dashboard
code=$(get /admin-dashboard)
assert_eq "admin login reaches dashboard" "$code" "200"

post /admin-markets -d "name=Verify Market $STAMP" -d "city=Karachi" -d "address=Test Road" \
  -d "days[]=Saturday" -d "open_time=08:00" -d "close_time=13:00" \
  -d "description=Created by verification script" -d "is_active=1" >/dev/null
MARKET_ID=$(db "SELECT id FROM markets WHERE name='Verify Market $STAMP'")
assert_ge "market CREATE persisted" "$MARKET_ID" 1

post "/admin-markets/$MARKET_ID" -d "_method=PUT" -d "name=Verify Market $STAMP" -d "city=Karachi" \
  -d "address=Test Road 2" -d "days[]=Saturday" -d "days[]=Sunday" -d "open_time=08:00" \
  -d "close_time=14:00" -d "description=Updated" -d "is_active=1" >/dev/null
assert_eq "market UPDATE persisted (address)" "$(db "SELECT address FROM markets WHERE id=$MARKET_ID")" "Test Road 2"
assert_eq "market UPDATE persisted (days)" "$(db "SELECT days FROM markets WHERE id=$MARKET_ID")" '["Saturday","Sunday"]'
curl -s -o /tmp/mkt.html -w '%{http_code}' "$BASE/markets" > /tmp/mkt.code
if grep -q "Verify Market $STAMP" /tmp/mkt.html; then
  c_ok "market FETCH on public /markets"
else
  c_bad "market missing on /markets (http $(cat /tmp/mkt.code), cards: $(grep -c 'market-item' /tmp/mkt.html))"
fi
curl -s -o /tmp/mktd.html -w '%{http_code}' "$BASE/market-details?id=$MARKET_ID" > /tmp/mktd.code
if grep -q "Verify Market $STAMP" /tmp/mktd.html; then
  c_ok "market FETCH on /market-details"
else
  c_bad "market details page wrong (http $(cat /tmp/mktd.code))"
fi

# moderation on the throwaway farmer
post "/admin-farmers/$FARMER_ID/toggle" >/dev/null
assert_eq "admin SUSPEND farmer persisted" "$(db "SELECT is_active FROM users WHERE id=$FARMER_ID")" "0"
post "/admin-farmers/$FARMER_ID/toggle" >/dev/null
assert_eq "admin RESTORE farmer persisted" "$(db "SELECT is_active FROM users WHERE id=$FARMER_ID")" "1"

# ===========================================================================
head_ "6. Deletes really delete (and clean up the test data)"
post "/admin-farmers/$FARMER_ID" -d "_method=DELETE" >/dev/null
assert_eq "farmer DELETE removed the user" "$(db "SELECT COUNT(*) FROM users WHERE id=$FARMER_ID")" "0"
assert_eq "farmer DELETE cascaded to products" "$(db "SELECT COUNT(*) FROM products WHERE farmer_id=$FARMER_ID")" "0"
assert_eq "farmer DELETE cascaded to orders" "$(db "SELECT COUNT(*) FROM orders WHERE farmer_id=$FARMER_ID")" "0"

post "/admin-customers/$CLIENT_ID" -d "_method=DELETE" >/dev/null
assert_eq "client DELETE removed the user" "$(db "SELECT COUNT(*) FROM users WHERE id=$CLIENT_ID")" "0"
assert_eq "client DELETE cascaded to orders" "$(db "SELECT COUNT(*) FROM orders WHERE customer_id=$CLIENT_ID")" "0"

post "/admin-markets/$MARKET_ID" -d "_method=DELETE" >/dev/null
assert_eq "market DELETE persisted" "$(db "SELECT COUNT(*) FROM markets WHERE id=$MARKET_ID")" "0"
assert_eq "market DELETE cleaned the pivot" "$(db "SELECT COUNT(*) FROM farmer_market WHERE market_id=$MARKET_ID")" "0"

# the signup-created market (auto-created by Market::syncForFarmer) must go too
SIGNUP_MARKET=$(db "SELECT id FROM markets WHERE name='Verify Signup Market $STAMP'")
post "/admin-markets/$SIGNUP_MARKET" -d "_method=DELETE" >/dev/null
assert_eq "signup-created market cleaned up" "$(db "SELECT COUNT(*) FROM markets WHERE name LIKE 'Verify%$STAMP'")" "0"

# ===========================================================================
head_ "7. Access control (no mock login shortcuts)"
logout
rm -f "$JAR"
code=$(curl -s -o /dev/null -w '%{http_code}' -L "$BASE/farmer-dashboard")
curl -s -o /tmp/anon.html -w '%{redirect_url}' "$BASE/farmer-dashboard" > /tmp/redirect
grep -q "/farmer-login" /tmp/redirect || grep -q "/login" /tmp/redirect
[ $? -eq 0 ] && c_ok "guest hitting /farmer-dashboard is sent to a login page" || c_bad "farmer dashboard not protected"
code=$(curl -s -o /dev/null -w '%{http_code}' "$BASE/customer-dashboard")
[ "$code" == "302" ] || [ "$code" == "401" ] && c_ok "guest hitting /customer-dashboard is blocked ($code)" || c_bad "client dashboard not protected ($code)"
code=$(curl -s -o /dev/null -w '%{http_code}' "$BASE/admin-dashboard")
[ "$code" == "302" ] || [ "$code" == "401" ] && c_ok "guest hitting /admin-dashboard is blocked ($code)" || c_bad "admin dashboard not protected ($code)"

# ===========================================================================
head_ "8. Wrong-role logins are rejected + cross-role pages blocked (seeded accounts)"
code=$(get /login); TOKEN=""
refresh_token /login
post /login -d "email=farmer@marketlink.com" -d "password=Farmer@123" >/dev/null
code=$(get /customer-dashboard)
assert_eq "farmer credentials do not open the client area" "$code" "302"
TOKEN=""; refresh_token /farmer-login
post /farmer-login -d "email=customer@marketlink.com" -d "password=Customer@123" >/dev/null
code=$(get /farmer-dashboard)
assert_eq "client credentials do not open the farmer area" "$code" "302"
login /login "customer@marketlink.com" "Customer@123"
code=$(get /farmer-dashboard)
assert_eq "logged-in client blocked from /farmer-dashboard" "$code" "302"
code=$(get /admin-dashboard)
assert_eq "logged-in client blocked from /admin-dashboard" "$code" "302"
login /farmer-login "farmer@marketlink.com" "Farmer@123"
code=$(get /customer-orders)
assert_eq "logged-in farmer blocked from /customer-orders" "$code" "302"
code=$(get /admin-dashboard)
assert_eq "logged-in farmer blocked from /admin-dashboard" "$code" "302"
login /admin-login "admin@marketlink.com" "Admin@123"
code=$(get /farmer-dashboard)
assert_eq "logged-in admin blocked from /farmer-dashboard" "$code" "302"
logout

# ===========================================================================
printf "\n\033[1mRESULT:\033[0m \033[32m%d passed\033[0m, " "$PASS"
[ "$FAIL" -eq 0 ] && printf "\033[32m0 failed\033[0m\n" || printf "\033[31m%d failed\033[0m\n" "$FAIL"
exit $((FAIL > 0))
