#!/usr/bin/env bash
# ============================================================================
#  MarketLink — "admin screens show real data" check
#
#  Compares what the admin pages RENDER against the actual SQLite rows:
#  stat cards, table row counts, market cards and the review list.
#
#  Usage:  bash scripts/verify-admin-views.sh [base-url]
# ============================================================================
set -uo pipefail

BASE="${1:-http://127.0.0.1:8000}"
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DB="$DIR/database/database.sqlite"
JAR="$(mktemp)"
PASS=0
FAIL=0

q() {
  DB_PATH="$DB" Q="$1" php -r 'try {
      $db = new PDO("sqlite:" . getenv("DB_PATH"));
      $stmt = $db->query(getenv("Q"));
      $v = $stmt ? $stmt->fetchColumn() : "";
      echo $v === false ? "" : $v;
    } catch (Throwable $e) { echo ""; }'
}

ok()  { printf "  \033[32m✓\033[0m %s\n" "$1"; PASS=$((PASS+1)); }
bad() { printf "  \033[31m✗\033[0m %s\n" "$1"; FAIL=$((FAIL+1)); }
cmp_num() { # cmp_num <label> <rendered> <db>
  if [ "$2" == "$3" ]; then ok "$1 → $3"; else bad "$1 → page shows '$2', database has '$3'"; fi
}

# ---- login through the real admin form ----
TOKEN="$(curl -s -c "$JAR" "$BASE/admin-login" | grep -o 'name="_token" value="[^"]*"' | head -1 | sed 's/.*value="//;s/"$//')"
curl -s -b "$JAR" -c "$JAR" -o /dev/null -X POST -H "X-CSRF-TOKEN: $TOKEN" -d "_token=$TOKEN" \
     -d "email=admin@marketlink.com" -d "password=Admin@123" "$BASE/admin-login"
curl -s -b "$JAR" -c "$JAR" -o /dev/null "$BASE/admin-dashboard"

fetch() { curl -s -b "$JAR" -c "$JAR" "$BASE$1"; }
# stat card value: <p>LABEL</p> ... <h3>VALUE</h3>
stat() { fetch "$1" | tr -d '\n' | grep -o "<p>$2</p>[^<]*<h3>[^<]*" | head -1 | sed 's/.*<h3>//' | tr -d ' '; }
# rows in the first tbody of a table with the given id
rows_in() { fetch "$1" | tr -d '\n' | python3 -c "
import sys, re
html = sys.stdin.read()
mid = re.search(r'id=\"$2\"(.*?)</table>', html, re.S)
body = mid.group(1) if mid else ''
tbody = re.search(r'<tbody[^>]*>(.*?)</tbody>', body, re.S)
body = tbody.group(1) if tbody else body
rows = [r for r in re.findall(r'<tr[^>]*>', body) if 'data-filter-empty' not in r]
print(len(rows))
"; }

echo
echo "== ADMIN DASHBOARD (stat cards vs database) =="
PAGE=/admin-dashboard
cmp_num "Total Farmers"  "$(stat $PAGE 'Total Farmers')"  "$(q "SELECT COUNT(*) FROM users WHERE role='farmer'")"
cmp_num "Total Customers" "$(stat $PAGE 'Total Customers')" "$(q "SELECT COUNT(*) FROM users WHERE role='customer'")"
cmp_num "Total Markets"  "$(stat $PAGE 'Total Markets')"  "$(q "SELECT COUNT(*) FROM markets WHERE is_active=1")"
cmp_num "Total Orders"   "$(stat $PAGE 'Total Orders')"   "$(q "SELECT COUNT(*) FROM orders")"
cmp_num "Collected Revenue" "$(stat $PAGE 'Collected Revenue' | tr -d 'PKR')" "$(q "SELECT COALESCE(SUM(subtotal),0) FROM orders WHERE status='completed'")"

echo
echo "== ADMIN TABLES (rendered rows vs database rows) =="
cmp_num "farmers table rows"   "$(rows_in /admin-farmers  adminFarmersTable)"   "$(q "SELECT COUNT(*) FROM users WHERE role='farmer'")"
cmp_num "customers table rows" "$(rows_in /admin-customers adminCustomersTable)" "$(q "SELECT COUNT(*) FROM users WHERE role='customer'")"
cmp_num "products table rows"  "$(rows_in /admin-products  adminProductsTable)"  "$(q 'SELECT COUNT(*) FROM products')"
cmp_num "orders table rows"    "$(rows_in /admin-orders    adminOrdersTable)"    "$(q 'SELECT COUNT(*) FROM orders')"

echo
echo "== ADMIN MARKETS + REVIEWS (cards vs database) =="
MARKET_CARDS="$(fetch /admin-markets | grep -c 'data-market=')"
cmp_num "market cards" "$MARKET_CARDS" "$(q 'SELECT COUNT(*) FROM markets')"
REVIEW_CARDS="$(fetch /admin-reviews | grep -c 'data-card-item')"
cmp_num "review cards" "$REVIEW_CARDS" "$(q 'SELECT COUNT(*) FROM reviews')"

echo
echo "== RENDERED CONTENT MATCHES REAL ROWS =="
check_text() { # check_text <page> <needle> <label>
  local body
  body="$(fetch "$1")"            # capture first: grep -q can SIGPIPE the curl
  if printf '%s' "$body" | grep -qF -- "$2"; then
    ok "$3"
  else
    bad "$3 — '$2' not found on $1"
  fi
}
check_text /admin-farmers  "$(q "SELECT COALESCE(stall_name,'') FROM farmers LIMIT 1")" "real stall name rendered on /admin-farmers"
check_text /admin-products "$(q 'SELECT name FROM products ORDER BY id LIMIT 1')" "real product name rendered on /admin-products"
check_text /admin-markets  "$(q 'SELECT name FROM markets ORDER BY id LIMIT 1')"  "real market name rendered on /admin-markets"
check_text /admin-dashboard "$(q "SELECT name FROM users WHERE role='customer' LIMIT 1")" "real client name rendered on /admin-dashboard"

echo
printf "\033[1mRESULT:\033[0m %d passed, " "$PASS"
[ "$FAIL" -eq 0 ] && printf "0 failed\n" || printf "%d failed\n" "$FAIL"
rm -f "$JAR"
exit $((FAIL > 0))
