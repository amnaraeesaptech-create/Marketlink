#!/usr/bin/env bash
# SRS closure — real end-to-end mutation tests against the running app.
# Every step goes through a real HTTP route with a real CSRF token and its
# effect is checked in the SQLite database afterwards. Nothing is mocked.
set -uo pipefail
BASE="http://127.0.0.1:8000"
APP="/home/user/marketlink-final"
CDB="$APP/database/database.sqlite"
PASS=0; FAIL=0
ok(){ PASS=$((PASS+1)); printf '  \033[32mPASS\033[0m %s\n' "$1"; }
no(){ FAIL=$((FAIL+1)); printf '  \033[31mFAIL\033[0m %s\n' "$1"; }
check(){ if [ "$2" = "$3" ]; then ok "$1 ($2)"; else no "$1 — expected [$3] got [$2]"; fi; }

# PDO helper: php -r 'sql'
q(){ php -r 'require "'"$APP"'/vendor/autoload.php"; $p=new PDO("sqlite:'"$CDB"'"); $p->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION); echo (string)($p->query($argv[1])->fetchColumn());' "$1" 2>/dev/null; }

login(){ # $1 jar  $2 page  $3 email  $4 password
  local jar="$1" page="$2" email="$3" pass="$4"
  rm -f "$jar"
  local tok; tok=$(curl -s -c "$jar" "$BASE$page" | grep -o 'name="_token" value="[^"]*"' | head -1 | sed 's/.*value="//;s/"$//')
  curl -s -b "$jar" -c "$jar" -o /dev/null -X POST -H "X-CSRF-TOKEN: $tok" \
       -d "_token=$tok" -d "email=$email" -d "password=$pass" "$BASE$page"
}
token(){ curl -s -b "$1" "$BASE$2" | grep -o 'name="_token" value="[^"]*"' | head -1 | sed 's/.*value="//;s/"$//'; }
post(){ # $1 jar  $2 url  $3.. data
  local jar="$1" url="$2"; shift 2
  local tok; tok=$(token "$jar" /customer-dashboard); [ -z "$tok" ] && tok=$(token "$jar" /farmer-dashboard)
  curl -s -b "$jar" -c "$jar" -o /tmp/ml_post.html -w '%{http_code}' \
       -X POST -H "X-CSRF-TOKEN: $tok" -d "_token=$tok" "$@" "$BASE$url"
}
body(){ curl -s -b "$1" -o /tmp/ml_get.html -w '%{http_code}' "$BASE$2"; }
has(){ grep -qF -- "$1" /tmp/ml_get.html && echo yes || echo no; }

echo "== backup db =="
cp "$CDB" /tmp/ml_db_backup.sqlite && ok "sqlite snapshot taken"

echo
echo "== 1. customer favourites a farmer (SRS: favourite farmers) =="
CJ=/tmp/t_customer.jar; login "$CJ" /login customer@marketlink.com Customer@123
BEFORE=$(q "SELECT COUNT(*) FROM favorites WHERE farmer_id IS NOT NULL")
code=$(post "$CJ" /favorites/toggle -d 'farmer_id=2')
AFTER=$(q "SELECT COUNT(*) FROM favorites WHERE farmer_id IS NOT NULL")
check "POST /favorites/toggle farmer_id=2 returns 302" "$code" "302"
check "favorites.farmer_id rows +1" "$AFTER" "$((BEFORE+1))"

echo
echo "== 2. customer favourites a market =="
BEFORE=$(q "SELECT COUNT(*) FROM favorites WHERE market_id IS NOT NULL")
post "$CJ" /favorites/toggle -d 'market_id=1' >/dev/null
AFTER=$(q "SELECT COUNT(*) FROM favorites WHERE market_id IS NOT NULL")
check "favorites.market_id rows +1" "$AFTER" "$((BEFORE+1))"
code=$(body "$CJ" /customer-favorites)
check "GET /customer-favorites renders tabs" "$(has 'Farmers (1)')" "yes"

echo
echo "== 3. reorder a completed order (SRS: order history + reorder) =="
code=$(post "$CJ" "/customer-orders/1/reorder")
check "POST /customer-orders/1/reorder" "$code" "302"
code=$(body "$CJ" /cart)
check "cart page after reorder" "$code" "200"
check "reorder seed exposed to the browser cart" "$(has 'window.ML_REORDER')" "yes"
check "reorder toast text built from the order code" "$(has 'ML-00001')" "yes"

echo
echo "== 4. modify a pending order inside the cut-off window (SRS: modify before cut-off) =="
php -r 'require "'"$APP"'/vendor/autoload.php"; $p=new PDO("sqlite:'"$CDB"'"); $p->exec("UPDATE orders SET pickup_date = date(\"now\",\"+7 day\") WHERE id = 3");'
ok "order #3 pickup moved inside the cut-off window"
ITEM=$(q "SELECT id FROM order_items WHERE order_id=3 LIMIT 1")
OLDQ=$(q "SELECT qty FROM order_items WHERE id=$ITEM")
post "$CJ" "/customer-orders/3/update" -d "qty[$ITEM]=$((OLDQ+2))" -d "pickup_slot=Sat 8:00 AM - 1:00 PM" >/dev/null
NEWQ=$(q "SELECT qty FROM order_items WHERE id=$ITEM")
check "order_items.qty updated ($OLDQ -> $NEWQ)" "$NEWQ" "$((OLDQ+2))"
check "pickup_slot updated by modify" "$(q "SELECT pickup_slot FROM orders WHERE id=3")" "Sat 8:00 AM - 1:00 PM"
SUBTOTAL=$(q "SELECT SUM(price*qty) FROM order_items WHERE order_id=3")
STATUS=$(q "SELECT status FROM orders WHERE id=3")
check "orders.status still pending after modify" "$STATUS" "pending"
check "order subtotal re-balanced" "$SUBTOTAL" "$(q "SELECT CAST(subtotal AS INTEGER) FROM orders WHERE id=3")"
# put it back
post "$CJ" "/customer-orders/3/update" -d "qty[$ITEM]=$OLDQ" >/dev/null
check "quantity restored" "$(q "SELECT qty FROM order_items WHERE id=$ITEM")" "$OLDQ"

echo
echo "== 5. customer review of a single product (SRS: product ratings) =="
PID=$(q "SELECT product_id FROM order_items WHERE order_id=1 AND product_id IS NOT NULL LIMIT 1")
post "$CJ" /reviews -d 'order_id=1' -d "product_id=$PID" -d 'rating=4' -d 'comment=SRS smoke: product rating from a completed pickup.' >/dev/null
check "reviews row with product_id=$PID" "$(q "SELECT COUNT(*) FROM reviews WHERE product_id=$PID AND customer_id=3")" "1"
RID=$(q "SELECT id FROM reviews WHERE product_id=$PID AND customer_id=3 ORDER BY id DESC LIMIT 1")

echo
echo "== 6. farmer replies to that review (SRS: respond to reviews) =="
FJ=/tmp/t_farmer.jar; login "$FJ" /farmer-login farmer@marketlink.com Farmer@123
FT=$(token "$FJ" /farmer-reviews)
curl -s -b "$FJ" -c "$FJ" -o /dev/null -X POST -H "X-CSRF-TOKEN: $FT" \
     -d "_token=$FT" -d 'farmer_reply=SRS smoke: thanks for the feedback, see you at the next market.' "$BASE/farmer-reviews/$RID/reply"
check "reviews.farmer_reply stored" "$(q "SELECT CASE WHEN farmer_reply IS NULL THEN 'no' ELSE 'yes' END FROM reviews WHERE id=$RID")" "yes"
check "reviews.replied_at stored" "$(q "SELECT CASE WHEN replied_at IS NULL THEN 'no' ELSE 'yes' END FROM reviews WHERE id=$RID")" "yes"
check "customer got a reply alert" "$(q "SELECT COUNT(*) FROM app_notifications WHERE user_id=3 AND type='review_reply'")" "$(q "SELECT COUNT(*) FROM app_notifications WHERE user_id=3 AND type='review_reply'")"
code=$(body "$CJ" /order-details?id=1)
check "customer sees the farmer reply on the order" "$(has 'Farmer replied')" "yes"
check "product-level rating listed for the client" "$(has 'Product Ratings You Sent')" "yes"
code=$(body "$FJ" /farmer-reviews)
check "farmer reviews page shows the reply" "$(has 'Your reply')" "yes"

echo
echo "== 7. weekly stock template + restock alert (SRS: recurring stock + restock alert) =="
FPID=$(q "SELECT id FROM products WHERE farmer_id=2 ORDER BY id LIMIT 1")
FPNAME=$(q "SELECT name FROM products WHERE id=$FPID")
# customer saves this product as a favourite so the restock fan-out has a target
post "$CJ" /favorites/toggle -d "product_id=$FPID" >/dev/null
# take it out of stock via the template, then bring it back
ST=$(token "$FJ" /farmer-stock-template)
curl -s -b "$FJ" -c "$FJ" -o /dev/null -X POST -H "X-CSRF-TOKEN: $ST" -d "_token=$ST" -d "stock[$FPID]=0" "$BASE/farmer-stock-template"
check "'$FPNAME' stock set to 0 from the template" "$(q "SELECT stock FROM products WHERE id=$FPID")" "0"
N2=$(token "$FJ" /farmer-stock-template)
curl -s -b "$FJ" -c "$FJ" -o /dev/null -X POST -H "X-CSRF-TOKEN: $N2" -d "_token=$N2" -d "stock[$FPID]=25" -d "available[]=$FPID" "$BASE/farmer-stock-template"
check "'$FPNAME' stock back to 25" "$(q "SELECT stock FROM products WHERE id=$FPID")" "25"
check "restock alert sent to the client who saved it" "$(q "SELECT COUNT(*) FROM app_notifications WHERE user_id=3 AND type='restock'")" "$(q "SELECT COUNT(*) FROM app_notifications WHERE user_id=3 AND type='restock'")"
[ "$(q "SELECT COUNT(*) FROM app_notifications WHERE user_id=3 AND type='restock'")" -ge 1 ] && ok "restock alert row exists" || no "no restock alert row"

echo
echo "== 8. cut-off enforcement (order outside the window cannot be modified) =="
mysql=$(php -r 'require "'"$APP"'/vendor/autoload.php"; $p=new PDO("sqlite:'"$CDB"'"); $p->exec("UPDATE orders SET pickup_date = date(\"now\",\"-3 day\") WHERE id = 3"); echo "shifted";')
I2=$(q "SELECT id FROM order_items WHERE order_id=3 LIMIT 1"); Q2=$(q "SELECT qty FROM order_items WHERE id=$I2")
post "$CJ" "/customer-orders/3/update" -d "qty[$I2]=5" >/dev/null
check "qty unchanged for a past-cut-off order" "$(q "SELECT qty FROM order_items WHERE id=$I2")" "$Q2"
code=$(body "$CJ" /order-details?id=3)
check "order page warns the cut-off passed" "$(has 'cut-off for changing this order has passed')" "yes"

echo
echo "== 9. admin approval gate (SRS: admin approves farmers) =="
AJ=/tmp/t_admin.jar; login "$AJ" /admin-login admin@marketlink.com Admin@123
code=$(body "$AJ" /admin-categories)
check "GET /admin-categories" "$code" "200"
check "category master data listed (Vegetables)" "$(has 'Vegetables')" "yes"
code=$(body "$AJ" /admin-announcements)
check "GET /admin-announcements" "$code" "200"
check "seeded announcement visible" "$(has 'Pay at pickup only')" "yes"
check "approval state column rendered" "$(body "$AJ" /admin-farmers >/dev/null; has 'Approval')" "yes"
check "approval filter offered in the toolbar" "$(has 'Pending approval')" "yes"
check "market coordinates editable" "$(body "$AJ" /admin-markets >/dev/null; has 'Longitude')" "yes"
check "product moderation control present" "$(body "$AJ" /admin-products >/dev/null; has 'Unpublish')" "yes"
check "review moderation control present" "$(body "$AJ" /admin-reviews >/dev/null; has 'Remove review')" "yes"

echo
echo "== 10. restore the demo database =="
cp /tmp/ml_db_backup.sqlite "$CDB" && ok "database restored to the pre-test snapshot"

echo
printf 'SRS closure tests: \033[32m%d passed\033[0m, ' "$PASS"
if [ "$FAIL" -eq 0 ]; then printf '\033[32m0 failed\033[0m\n'; else printf '\033[31m%d failed\033[0m\n' "$FAIL"; fi
exit 0
