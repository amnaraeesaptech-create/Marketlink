#!/usr/bin/env bash
# ============================================================================
#  MarketLink — authenticated page sweep
#
#  Logs in as each demo account through the real login forms (no bypass) and
#  requests every protected page, reporting HTTP status + <title>.
#
#  Usage:  bash scripts/smoke-authenticated-pages.sh [base-url]
# ============================================================================
set -u

BASE="${1:-http://127.0.0.1:8000}"
JAR="$(mktemp)"
FAIL=0

login() { # login <jar> <login-path> <email> <password>
  local jar="$1" url="$2" email="$3" pass="$4"
  rm -f "$jar"
  local t
  t=$(curl -s -c "$jar" "$BASE$url" | grep -o 'name="_token" value="[^"]*"' | head -1 | sed 's/.*value="//;s/"$//')
  local code
  code=$(curl -s -b "$jar" -c "$jar" -o /dev/null -w '%{http_code}' -X POST \
        -H "X-CSRF-TOKEN: $t" -d "_token=$t" -d "email=$email" -d "password=$pass" "$BASE$url")
  local loc
  loc=$(curl -s -b "$jar" -c "$jar" -o /dev/null -w '%{redirect_url}' "$BASE/customer-dashboard" >/dev/null; echo)
  printf '  login %-16s -> HTTP %s\n' "$url" "$code"
}

chk() { # chk <jar> <path>
  local jar="$1" p="$2"
  local out title
  out=$(curl -s -b "$jar" -c "$jar" -o /tmp/sw_page.html -w '%{http_code}' "$BASE$p")
  title=$(grep -o '<title>[^<]*' /tmp/sw_page.html | head -1 | sed 's/<title>//')
  if [ "$out" = "200" ]; then
    printf '  \033[32mOK \033[0m %-26s %s\n' "$p" "$title"
  else
    FAIL=$((FAIL+1))
    printf '  \033[31mBAD\033[0m %-26s HTTP %s\n' "$p" "$out"
  fi
}

echo "== PUBLIC =="
for p in / /about /contact /farmers /markets /products /cart /sitemap /ai-assistant \
         "/market-details?id=1" "/market-details?id=2" "/product-details?id=1" \
         "/farmer-profile?id=2" /login /register /farmer-login /farmer-register /admin-login /data-feed.js; do
  chk /dev/null "$p"
done

echo "== ADMIN =="
login "$JAR" /admin-login admin@marketlink.com 'Admin@123'
for p in /admin-dashboard /admin-markets /admin-reports /admin-farmers /admin-customers \
         /admin-products /admin-orders /admin-reviews /admin-categories /admin-announcements \
         /notifications; do chk "$JAR" "$p"; done

echo "== FARMER =="
login "$JAR" /farmer-login farmer@marketlink.com 'Farmer@123'
for p in /farmer-dashboard /farmer-products /farmer-add-product /farmer-orders \
         /farmer-reviews /farmer-stock-template /farmer-profile /farmer-profile/edit \
         /notifications "/order-details?id=1"; do chk "$JAR" "$p"; done

echo "== CLIENT =="
login "$JAR" /login customer@marketlink.com 'Customer@123'
for p in /customer-dashboard /customer-orders /customer-favorites /customer-reviews \
         /customer-profile /preorder /cart /notifications "/order-details?id=1" "/order-details?id=2"; do chk "$JAR" "$p"; done

rm -f "$JAR"
echo
if [ "$FAIL" -eq 0 ]; then
  echo "sweep clean: every page returned 200"
else
  echo "sweep found $FAIL non-200 page(s)"
fi
exit $((FAIL > 0))
