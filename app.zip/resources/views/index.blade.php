@extends('layouts.app')

@section('title', 'MarketLink — Fresh From Local Farmers to Your Table')

@section('content')
<main>
    <!-- HERO SECTION -->
        <!-- HERO SECTION -->
        <section class="ml-hero d-flex align-items-center" style="background: linear-gradient(rgba(24, 61, 38, 0.8), rgba(24, 61, 38, 0.8)), url('/images/img1.jpg') no-repeat center center/cover; min-height: 100vh;">
            <div class="container text-center text-white">
                <h1 class="display-3 fw-bold mb-4 ml-hero-title">Fresh From Local Farmers to Your Table</h1>
                <p class="lead mb-5 ml-hero-subtitle">Discover seasonal produce, support your local community, and eat healthier.</p>
                
                <div class="ml-search-widget bg-white p-3 rounded-4 shadow-lg mx-auto mb-5" style="max-width: 800px;">
                    <ul class="nav nav-pills mb-3 justify-content-center" id="search-tabs" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="products-tab" data-bs-toggle="pill" data-bs-target="#products" type="button" role="tab" aria-controls="products" aria-selected="true">Products</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="farmers-tab" data-bs-toggle="pill" data-bs-target="#farmers" type="button" role="tab" aria-controls="farmers" aria-selected="false">Farmers</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="markets-tab" data-bs-toggle="pill" data-bs-target="#markets" type="button" role="tab" aria-controls="markets" aria-selected="false">Markets</button>
                        </li>
                    </ul>
                    <div class="tab-content" id="search-tabs-content">
                        <div class="tab-pane fade show active" id="products" role="tabpanel" aria-labelledby="products-tab">
                            <form class="d-flex gap-2">
                                <input type="text" class="form-control form-control-lg" placeholder="Search for fresh tomatoes, honey..." aria-label="Search Products">
                                <button class="btn btn-lg ml-btn-primary" type="submit"><i class="fas fa-search"></i> Search</button>
                            </form>
                        </div>
                        <div class="tab-pane fade" id="farmers" role="tabpanel" aria-labelledby="farmers-tab">
                            <form class="d-flex gap-2">
                                <input type="text" class="form-control form-control-lg" placeholder="Search farmer name or specialty..." aria-label="Search Farmers">
                                <button class="btn btn-lg ml-btn-primary" type="submit"><i class="fas fa-search"></i> Search</button>
                            </form>
                        </div>
                        <div class="tab-pane fade" id="markets" role="tabpanel" aria-labelledby="markets-tab">
                            <form class="d-flex gap-2">
                                <input type="text" class="form-control form-control-lg" placeholder="Search market by city or zip..." aria-label="Search Markets">
                                <button class="btn btn-lg ml-btn-primary" type="submit"><i class="fas fa-search"></i> Search</button>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="d-flex justify-content-center gap-3 flex-wrap">
                    <a href="/markets" class="btn btn-lg ml-btn-primary px-4 py-3">Explore Markets</a>
                    <a href="/products" class="btn btn-lg ml-btn-outline-light px-4 py-3">Browse Products</a>
                </div>
            </div>
        </section>

        <!-- STATS BAR (live counts) -->
        <section class="ml-stats py-5 bg-light">
            <div class="container">
                <div class="row text-center g-4">
                    <div class="col-6 col-md-3">
                        <h2 class="display-5 fw-bold ml-text-green mb-0">{{ $stats['markets'] }}</h2>
                        <p class="text-muted fw-medium text-uppercase mb-0">Active Markets</p>
                    </div>
                    <div class="col-6 col-md-3">
                        <h2 class="display-5 fw-bold ml-text-green mb-0">{{ $stats['farmers'] }}</h2>
                        <p class="text-muted fw-medium text-uppercase mb-0">Local Farmers</p>
                    </div>
                    <div class="col-6 col-md-3">
                        <h2 class="display-5 fw-bold ml-text-green mb-0">{{ $stats['products'] }}</h2>
                        <p class="text-muted fw-medium text-uppercase mb-0">Fresh Products</p>
                    </div>
                    <div class="col-6 col-md-3">
                        <h2 class="display-5 fw-bold ml-text-green mb-0">{{ $stats['customers'] }}</h2>
                        <p class="text-muted fw-medium text-uppercase mb-0">Registered Clients</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- FEATURED MARKETS -->
        <section class="ml-featured-markets py-5">
            <div class="container py-4">
                <div class="d-flex justify-content-between align-items-end mb-5">
                    <div>
                        <h2 class="fw-bold mb-2">Featured Markets</h2>
                        <div class="ml-underline"></div>
                    </div>
                    <a href="/markets" class="btn ml-btn-outline-green d-none d-md-inline-block">View All Markets <i class="fas fa-arrow-right ms-1"></i></a>
                </div>

                <div class="row g-4">
                    @forelse($markets as $market)
                        <div class="col-md-6 col-lg-4">
                            <div class="card h-100 ml-market-card shadow-sm border-0 rounded-4 overflow-hidden">
                                <div class="position-relative">
                                    <img src="{{ $market->imageUrl() }}" class="card-img-top object-fit-cover" alt="{{ $market->name }}" height="250">
                                    @if(in_array(now()->format('l'), $market->days ?? [], true))
                                        <span class="badge bg-success position-absolute top-0 end-0 m-3 px-3 py-2 rounded-pill">Open Today</span>
                                    @else
                                        <span class="badge bg-secondary position-absolute top-0 end-0 m-3 px-3 py-2 rounded-pill">{{ $market->daysLabel() }}</span>
                                    @endif
                                </div>
                                <div class="card-body p-4">
                                    <h5 class="card-title fw-bold">{{ $market->name }}</h5>
                                    <p class="text-muted small mb-2"><i class="fas fa-map-marker-alt text-danger me-2"></i> {{ $market->address ?: 'Address not set' }}@if($market->city), {{ $market->city }}@endif</p>
                                    <p class="text-muted small mb-3"><i class="far fa-clock text-primary me-2"></i> {{ $market->daysLabel() }} &bull; {{ $market->hoursLabel() }}</p>
                                    <hr>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <span class="small fw-medium"><i class="fas fa-user-friends me-1"></i> {{ $market->farmers_count }} Farmer{{ $market->farmers_count === 1 ? '' : 's' }}</span>
                                        <a href="/market-details?id={{ $market->id }}" class="btn ml-btn-primary btn-sm px-3">View Market</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @empty
                        <div class="col-12 text-center text-muted py-4">No markets yet — an administrator can add them from the admin panel.</div>
                    @endforelse
                </div>
                <div class="text-center mt-4 d-md-none">
                    <a href="/markets" class="btn ml-btn-outline-green w-100">View All Markets</a>
                </div>
            </div>
        </section>

        <!-- HOW IT WORKS -->
        <section class="ml-how-it-works py-5 bg-light">
            <div class="container py-4">
                <div class="text-center mb-5">
                    <h2 class="fw-bold mb-2">How It Works</h2>
                    <div class="ml-underline mx-auto"></div>
                </div>
                
                <div class="row text-center position-relative g-4">
                    <!-- Dashed line connecting steps (hidden on mobile) -->
                    <div class="position-absolute top-50 start-50 translate-middle w-75 d-none d-lg-block" style="border-top: 2px dashed #a3b18a; z-index: 1;"></div>
                    
                    <div class="col-sm-6 col-lg-3 position-relative z-2">
                        <div class="bg-white rounded-circle shadow-sm d-inline-flex align-items-center justify-content-center mb-3 ml-step-icon" style="width: 80px; height: 80px; border: 4px solid #fff;">
                            <i class="fas fa-map-marker-alt fs-2 ml-text-green"></i>
                        </div>
                        <h5 class="fw-bold">1. Find a Market</h5>
                        <p class="text-muted small">Locate nearby farmers markets and check their operating hours.</p>
                    </div>
                    
                    <div class="col-sm-6 col-lg-3 position-relative z-2">
                        <div class="bg-white rounded-circle shadow-sm d-inline-flex align-items-center justify-content-center mb-3 ml-step-icon" style="width: 80px; height: 80px; border: 4px solid #fff;">
                            <i class="fas fa-shopping-basket fs-2 ml-text-green"></i>
                        </div>
                        <h5 class="fw-bold">2. Browse Products</h5>
                        <p class="text-muted small">Explore fresh, seasonal produce available from local farmers.</p>
                    </div>
                    
                    <div class="col-sm-6 col-lg-3 position-relative z-2">
                        <div class="bg-white rounded-circle shadow-sm d-inline-flex align-items-center justify-content-center mb-3 ml-step-icon" style="width: 80px; height: 80px; border: 4px solid #fff;">
                            <i class="fas fa-clipboard-list fs-2 ml-text-green"></i>
                        </div>
                        <h5 class="fw-bold">3. Pre-Order</h5>
                        <p class="text-muted small">Secure your favorites by ordering online before market day.</p>
                    </div>
                    
                    <div class="col-sm-6 col-lg-3 position-relative z-2">
                        <div class="bg-white rounded-circle shadow-sm d-inline-flex align-items-center justify-content-center mb-3 ml-step-icon" style="width: 80px; height: 80px; border: 4px solid #fff;">
                            <i class="fas fa-shopping-bag fs-2 ml-text-green"></i>
                        </div>
                        <h5 class="fw-bold">4. Pick Up</h5>
                        <p class="text-muted small">Visit the market and collect your fresh goods directly from the farmer.</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- FEATURED FARMERS -->
        <section class="ml-featured-farmers py-5">
            <div class="container py-4">
                <div class="text-center mb-5">
                    <h2 class="fw-bold mb-2">Meet Our Farmers</h2>
                    <div class="ml-underline mx-auto"></div>
                </div>
                
                <div class="row g-4">
                    @forelse(array_slice($farmers, 0, 4) as $farmer)
                        <div class="col-sm-6 col-lg-3">
                            <div class="card h-100 ml-farmer-card border-0 shadow-sm text-center p-4 rounded-4 position-relative">
                                <img src="{{ $farmer['image'] }}" class="rounded-circle mx-auto mb-3 object-fit-cover shadow-sm" alt="{{ $farmer['stallName'] }}" width="100" height="100">
                                <h5 class="fw-bold mb-1">{{ $farmer['stallName'] }}</h5>
                                <p class="text-muted small mb-2">{{ $farmer['name'] }}</p>
                                <div class="text-warning small mb-3">
                                    @php($stars = (int) round($farmer['rating']))
                                    @for($i = 1; $i <= 5; $i++)
                                        <i class="fa{{ $i <= $stars ? 's' : 'r' }} fa-star"></i>
                                    @endfor
                                    ({{ $farmer['rating'] ? number_format($farmer['rating'], 1) : 'New' }})
                                </div>
                                <div class="d-flex flex-wrap justify-content-center gap-1 mb-4">
                                    @foreach(array_slice($farmer['categories'], 0, 3) as $category)
                                        <span class="badge bg-light text-dark border">{{ $category }}</span>
                                    @endforeach
                                    <span class="badge bg-light text-dark border">{{ $farmer['productCount'] }} items</span>
                                </div>
                                <a href="/farmer-profile?id={{ $farmer['id'] }}" class="btn ml-btn-outline-green w-100 mt-auto">View Profile</a>
                            </div>
                        </div>
                    @empty
                        <div class="col-12 text-center text-muted py-4">No farmer stalls registered yet.</div>
                    @endforelse
                </div>
            </div>
        </section>

        <!-- POPULAR PRODUCTS -->
        <section class="ml-popular-products py-5 bg-light">
            <div class="container py-4">
                <div class="d-flex justify-content-between align-items-end mb-5">
                    <div>
                        <h2 class="fw-bold mb-2">Popular Products</h2>
                        <div class="ml-underline"></div>
                    </div>
                    <a href="/products" class="btn ml-btn-outline-green d-none d-md-inline-block">Shop All <i class="fas fa-arrow-right ms-1"></i></a>
                </div>

                <div class="row g-4">
                    @forelse($featuredProducts as $product)
                        <div class="col-6 col-lg-3">
                            <div class="card h-100 ml-product-card shadow-sm border-0 rounded-4 overflow-hidden">
                                <div class="position-relative">
                                    <a href="/product-details?id={{ $product->id }}">
                                        <img src="{{ $product->imageUrl() }}" class="card-img-top object-fit-cover" alt="{{ $product->name }}" height="200">
                                    </a>
                                    @if($product->stockState() === 'low')
                                        <span class="badge bg-warning text-dark position-absolute top-0 start-0 m-2">Only {{ $product->stock }} left</span>
                                    @endif
                                </div>
                                <div class="card-body p-3">
                                    <a href="/farmer-profile?id={{ $product->farmer_id }}" class="text-muted small text-decoration-none">{{ $product->farmer?->displayName() }}</a>
                                    <h6 class="card-title fw-bold mt-1 mb-2">
                                        <a href="/product-details?id={{ $product->id }}" class="text-dark text-decoration-none">{{ $product->name }}</a>
                                    </h6>
                                    <div class="d-flex justify-content-between align-items-center mt-3">
                                        <span class="fw-bold fs-5 ml-text-green">PKR {{ number_format((float) $product->price, 0) }} <small class="text-muted fs-6 fw-normal">/ {{ $product->unit }}</small></span>
                                        <button class="btn btn-sm ml-btn-primary rounded-circle shadow-sm add-to-cart-btn" aria-label="Add to Cart"
                                                data-id="{{ $product->id }}" data-name="{{ $product->name }}"
                                                data-price="{{ $product->price }}" data-image="{{ $product->imageUrl() }}"
                                                style="width:36px; height:36px;"><i class="fas fa-plus"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @empty
                        <div class="col-12 text-center text-muted py-4">No products in the catalogue yet.</div>
                    @endforelse
                </div>
                <div class="text-center mt-4 d-md-none">
                    <a href="/products" class="btn ml-btn-outline-green w-100">Shop All Products</a>
                </div>
            </div>
        </section>

        <!-- BENEFITS / TWO COLUMNS -->
        <section class="ml-benefits py-5">
            <div class="container py-4">
                <div class="row g-5 align-items-center">
                    <!-- Customer Benefits -->
                    <div class="col-lg-6">
                        <h2 class="fw-bold mb-4">Why Shop With MarketLink?</h2>
                        <div class="row g-4 mt-2">
                            <div class="col-12 d-flex align-items-start gap-3">
                                <div class="bg-success-subtle p-3 rounded-circle text-success fs-4">
                                    <i class="fas fa-truck-slash"></i>
                                </div>
                                <div>
                                    <h5 class="fw-bold">No Shipping Wait</h5>
                                    <p class="text-muted">Pick up directly from the market. No long delivery times or lost packages.</p>
                                </div>
                            </div>
                            <div class="col-12 d-flex align-items-start gap-3">
                                <div class="bg-success-subtle p-3 rounded-circle text-success fs-4">
                                    <i class="fas fa-leaf"></i>
                                </div>
                                <div>
                                    <h5 class="fw-bold">Fresh & Seasonal</h5>
                                    <p class="text-muted">Enjoy produce picked at peak ripeness, ensuring better taste and nutrition.</p>
                                </div>
                            </div>
                            <div class="col-12 d-flex align-items-start gap-3">
                                <div class="bg-success-subtle p-3 rounded-circle text-success fs-4">
                                    <i class="fas fa-hand-holding-heart"></i>
                                </div>
                                <div>
                                    <h5 class="fw-bold">Support Local</h5>
                                    <p class="text-muted">Keep your money in the community and support local agriculture directly.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Farmer Benefits -->
                    <div class="col-lg-6">
                        <div class="bg-light p-5 rounded-4 position-relative">
                            <div class="position-absolute top-0 end-0 p-3 text-success opacity-25">
                                <i class="fas fa-seedling fa-5x"></i>
                            </div>
                            <h2 class="fw-bold mb-4 position-relative z-1">Are You a Farmer?</h2>
                            <p class="mb-4 position-relative z-1 text-muted">Join our platform to expand your reach, manage pre-orders, and connect with more customers.</p>
                            <ul class="list-unstyled mb-4 position-relative z-1">
                                <li class="mb-2"><i class="fas fa-check-circle text-success me-2"></i> Reach thousands of local customers</li>
                                <li class="mb-2"><i class="fas fa-check-circle text-success me-2"></i> Reduce waste with pre-orders</li>
                                <li class="mb-2"><i class="fas fa-check-circle text-success me-2"></i> Easy inventory and sales management</li>
                                <li class="mb-2"><i class="fas fa-check-circle text-success me-2"></i> No online payment — clients pay you at pickup</li>
                            </ul>
                            <a href="/farmer-register" class="btn ml-btn-primary position-relative z-1 me-2">Register a Stall</a>
                            <a href="/farmer-login" class="btn ml-btn-outline-green position-relative z-1">Farmer Login</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- TESTIMONIALS -->
        <section class="ml-testimonials py-5 bg-light">
            <div class="container py-4">
                <div class="text-center mb-5">
                    <h2 class="fw-bold mb-2">What Our Community Says</h2>
                    <div class="ml-underline mx-auto"></div>
                </div>
                
                <div class="row g-4">
                    @forelse($testimonials as $review)
                        <div class="col-md-4">
                            <div class="card h-100 border-0 shadow-sm p-4 rounded-4">
                                <div class="text-warning mb-3">
                                    @for($i = 1; $i <= 5; $i++)
                                        <i class="fa{{ $i <= $review->rating ? 's' : 'r' }} fa-star"></i>
                                    @endfor
                                </div>
                                <p class="fst-italic text-muted mb-4">"{{ $review->comment }}"</p>
                                <div class="d-flex align-items-center gap-3 mt-auto">
                                    <img src="{{ $review->customer?->avatarUrl() }}" class="rounded-circle" alt="{{ $review->customer?->name }}" width="50" height="50">
                                    <div>
                                        <h6 class="fw-bold mb-0">{{ $review->customer?->name ?? 'Client' }}</h6>
                                        <small class="text-muted">Client &bull; about {{ $review->farmer?->displayName() ?? 'a stall' }}</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @empty
                        <div class="col-12 text-center text-muted py-4">No reviews have been written yet.</div>
                    @endforelse
                </div>
            </div>
        </section>

        <!-- MAP PREVIEW -->
        <section class="ml-map-preview py-5">
            <div class="container py-4 text-center">
                <h2 class="fw-bold mb-4">Explore Markets Near You</h2>
                <div class="rounded-4 overflow-hidden shadow-sm" style="height: 400px; background-color: #e5e3df; position: relative;">
                    <!-- Placeholder for Map -->
                    <div class="d-flex flex-column align-items-center justify-content-center h-100 w-100" style="background: linear-gradient(135deg, #2b5b3f 0%, #4a7c59 100%); position: relative;">
                        <div class="position-absolute top-0 start-0 w-100 h-100" style="background-color: rgba(43, 91, 63, 0.4);"></div>
                        <div class="position-relative z-1 text-white">
                            <i class="fas fa-map-marked-alt fa-4x mb-3"></i>
                            <h4 class="fw-bold">{{ $stats['markets'] }} market{{ $stats['markets'] === 1 ? '' : 's' }} on MarketLink</h4>
                            <p>Browse each market's stalls, opening days and pickup windows.</p>
                            <a href="/markets" class="btn ml-btn-primary mt-2">Open Map</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- NEWSLETTER -->
        <section class="ml-newsletter py-5 text-white" style="background: linear-gradient(135deg, #183d26 0%, #2b5b3f 100%);">
            <div class="container py-4">
                <div class="row align-items-center">
                    <div class="col-lg-6 mb-4 mb-lg-0 text-center text-lg-start">
                        <h3 class="fw-bold mb-2">Stay Fresh!</h3>
                        <p class="mb-0 text-white-50">Subscribe to our newsletter for seasonal updates, new farm alerts, and market events.</p>
                    </div>
                    <div class="col-lg-6">
                        <form class="ml-newsletter-form bg-white p-2 rounded-pill shadow-sm d-flex" action="/newsletter" method="POST">
                            @csrf
                            <input type="email" name="newsletter_email" class="form-control border-0 rounded-pill px-4 shadow-none" placeholder="Enter your email address" aria-label="Email Address" required>
                            <button type="submit" class="btn ml-btn-primary rounded-pill px-4">Subscribe</button>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </main>
@endsection
