@extends('layouts.dashboard')

@section('title', 'Notifications — MarketLink')

@section('content')
<div class="dashboard-layout">
    @auth
        @if(auth()->user()->isFarmer())
            @include('includes.sidebar-farmer', ['active' => 'notifications'])
        @elseif(auth()->user()->isCustomer())
            @include('includes.sidebar-customer', ['active' => 'notifications'])
        @else
            <aside class="ml-sidebar" id="sidebar">
                <div class="ml-sidebar-header">
                    <a href="/" class="ml-sidebar-brand"><i class="fas fa-seedling"></i> MarketLink</a>
                    <button class="ml-sidebar-close d-lg-none" id="sidebarClose"><i class="fas fa-times"></i></button>
                </div>
                <div class="ml-sidebar-user">
                    <img src="{{ auth()->user()->avatarUrl() }}" alt="Admin" class="ml-sidebar-avatar">
                    <div>
                        <div class="ml-sidebar-username">{{ auth()->user()->name }}</div>
                        <div class="ml-sidebar-role">Admin</div>
                    </div>
                </div>
                <nav class="ml-sidebar-nav">
                    <a href="/admin-dashboard" class="ml-sidebar-link"><i class="fas fa-th-large"></i> Dashboard</a>
                    <a href="/admin-farmers" class="ml-sidebar-link"><i class="fas fa-tractor"></i> Farmers</a>
                    <a href="/admin-products" class="ml-sidebar-link"><i class="fas fa-box"></i> Products</a>
                    <a href="/admin-reviews" class="ml-sidebar-link"><i class="fas fa-star"></i> Reviews</a>
                    <a href="/admin-categories" class="ml-sidebar-link"><i class="fas fa-tags"></i> Categories</a>
                    <a href="/admin-announcements" class="ml-sidebar-link"><i class="fas fa-bullhorn"></i> Announcements</a>
                    <a href="/notifications" class="ml-sidebar-link active"><i class="fas fa-bell"></i> Notifications</a>
                    <hr class="ml-sidebar-divider">
                    <form action="/logout" method="POST">
                        @csrf
                        <button type="submit" class="ml-sidebar-link ml-sidebar-logout w-100 border-0 bg-transparent text-start"><i class="fas fa-sign-out-alt"></i> Logout</button>
                    </form>
                </nav>
            </aside>
            <div class="ml-sidebar-overlay" id="sidebarOverlay"></div>
        @endif
    @endauth

    <div class="dashboard-main">
        <div class="dashboard-topbar">
            <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
            <h1 class="ml-topbar-title">Notifications</h1>
            <form action="/notifications/read-all" method="POST">
                @csrf
                <button class="btn btn-sm btn-outline-success" {{ $unread ? '' : 'disabled' }}>
                    <i class="fas fa-check-double me-1"></i>Mark all read
                </button>
            </form>
        </div>

        <div class="dashboard-content">
            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
                <h2 class="h5 mb-0 fw-bold">
                    Your alerts
                    @if($unread)<span class="badge bg-danger ms-1">{{ $unread }} unread</span>@endif
                </h2>
                <span class="text-muted small">Order updates, restock alerts and replies — all stored when they happen.</span>
            </div>

            @if($announcements->isNotEmpty())
                <div class="card border-0 shadow-sm rounded-3 mb-4">
                    <div class="card-header bg-white border-bottom p-3">
                        <h3 class="card-header-title mb-0"><i class="fas fa-bullhorn text-success me-2"></i>Platform announcements</h3>
                    </div>
                    <ul class="list-group list-group-flush">
                        @foreach($announcements as $a)
                            <li class="list-group-item py-3">
                                <div class="d-flex justify-content-between align-items-start gap-2">
                                    <div>
                                        <h6 class="mb-1 fw-bold">{{ $a->title }}</h6>
                                        <p class="mb-1 small text-muted">{{ $a->body }}</p>
                                        <small class="text-muted">{{ $a->published_at?->format('M j, Y g:i A') }}</small>
                                    </div>
                                    <span class="badge bg-success-subtle text-success">{{ $a->audienceLabel() }}</span>
                                </div>
                            </li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <div class="card border-0 shadow-sm rounded-3">
                <div class="card-body p-0">
                    <ul class="list-group list-group-flush">
                        @forelse($notifications as $n)
                            <li class="list-group-item py-3 {{ $n->isUnread() ? 'bg-success bg-opacity-10' : '' }}">
                                <div class="d-flex gap-3">
                                    <div class="stat-icon bg-success bg-opacity-10 text-success mb-0" style="width:38px;height:38px;font-size:.95rem;">
                                        <i class="fas {{ $n->icon() }}"></i>
                                    </div>
                                    <div class="flex-grow-1 min-w-0">
                                        <div class="d-flex justify-content-between gap-2 flex-wrap">
                                            <h6 class="mb-1 fw-semibold">{{ $n->title }}</h6>
                                            <small class="text-muted">{{ $n->created_at->diffForHumans() }}</small>
                                        </div>
                                        @if($n->body)<p class="mb-2 small text-muted">{{ $n->body }}</p>@endif
                                        <div class="d-flex gap-2">
                                            @if($n->url)
                                                <form action="/notifications/{{ $n->id }}/read" method="POST">
                                                    @csrf
                                                    <button class="btn btn-sm btn-success">Open</button>
                                                </form>
                                            @endif
                                            @if($n->isUnread())
                                                <form action="/notifications/{{ $n->id }}/read" method="POST">
                                                    @csrf
                                                    <button class="btn btn-sm btn-outline-secondary">Mark read</button>
                                                </form>
                                            @else
                                                <span class="badge bg-light text-muted align-self-center">Read</span>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                            </li>
                        @empty
                            <li class="list-group-item py-4 text-center text-muted">
                                No notifications yet. Placing a pre-order, a farmer accepting it, a restock or a review reply all show up here.
                            </li>
                        @endforelse
                    </ul>
                </div>
            </div>

            <div class="mt-3">{{ $notifications->links() }}</div>
        </div>
    </div>
</div>
@endsection
