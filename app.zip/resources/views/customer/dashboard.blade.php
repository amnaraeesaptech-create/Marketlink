@extends('layouts.dashboard')

@section('title', 'Client Dashboard - MarketLink')

@section('content')
<div class="ml-dashboard-wrapper d-flex">

  <aside class="ml-sidebar" id="sidebar">
    <div class="ml-sidebar-header">
      <a href="/" class="ml-sidebar-brand text-decoration-none"><i class="fas fa-seedling"></i> MarketLink</a>
      <button class="ml-sidebar-close d-lg-none" id="sidebarClose"><i class="fas fa-times"></i></button>
    </div>
    <div class="ml-sidebar-user">
      <img src="{{ $user->avatarUrl() }}" alt="User" class="ml-sidebar-avatar">
      <div>
        <div class="ml-sidebar-username">{{ $user->name }}</div>
        <div class="ml-sidebar-role">Client</div>
      </div>
    </div>
    <nav class="ml-sidebar-nav">
      <a href="/customer-dashboard" class="ml-sidebar-link active"><i class="fas fa-th-large"></i> Dashboard</a>
      <a href="/customer-orders" class="ml-sidebar-link"><i class="fas fa-shopping-bag"></i> My Orders</a>
      <a href="/customer-favorites" class="ml-sidebar-link"><i class="fas fa-heart"></i> Favorites</a>
      <a href="/customer-reviews" class="ml-sidebar-link"><i class="fas fa-star"></i> Reviews</a>
      <a href="/customer-profile" class="ml-sidebar-link"><i class="fas fa-user"></i> Profile</a>
      <hr class="ml-sidebar-divider">
      <form action="/logout" method="POST">
        @csrf
        <button type="submit" class="ml-sidebar-link ml-sidebar-logout w-100 border-0 bg-transparent text-start"><i class="fas fa-sign-out-alt"></i> Logout</button>
      </form>
    </nav>
  </aside>
  <div class="ml-sidebar-overlay" id="sidebarOverlay"></div>

  <main class="ml-dashboard-main flex-grow-1" style="height: 100vh; overflow-y: auto;">

    <div class="ml-topbar">
      <button class="ml-topbar-toggle d-lg-none btn btn-light" id="sidebarToggle"><i class="fas fa-bars"></i></button>
      <div class="ml-topbar-title fw-semibold">My Dashboard</div>
      <div class="ml-topbar-actions d-flex align-items-center gap-3">
        <a href="/products" class="btn btn-sm btn-success"><i class="fas fa-shopping-basket"></i> Shop</a>
        <img src="{{ $user->avatarUrl() }}" class="ml-topbar-avatar rounded-circle" alt="User">
      </div>
    </div>

    <div class="container-fluid py-4 ml-dashboard-content">

      <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h1 class="h3 mb-1 fw-bold">{{ now()->hour < 12 ? 'Good morning' : (now()->hour < 17 ? 'Good afternoon' : 'Good evening') }}, {{ $user->name }}! 🌱</h1>
          <p class="text-muted mb-0">
            Your live account: {{ $ordersCount }} pre-order{{ $ordersCount === 1 ? '' : 's' }} on record
            @if($pendingReviews) &bull; {{ $pendingReviews }} waiting for your review @endif
          </p>
        </div>
        <a href="/preorder" class="btn btn-success d-none d-md-inline-flex"><i class="fas fa-plus me-1"></i> New Pre-Order</a>
      </div>

      {{-- Live counters straight from the orders table --}}
      <div class="row g-4 mb-4">
        <div class="col-sm-6 col-xl-3">
          <div class="card border-0 shadow-sm h-100 border-start border-success border-4">
            <div class="card-body">
              <div class="d-flex align-items-center justify-content-between">
                <div>
                  <h6 class="text-muted mb-2">Total Orders</h6>
                  <h3 class="mb-0 fw-bold">{{ $ordersCount }}</h3>
                  <small class="text-muted">PKR {{ $spendFmt }} ordered</small>
                </div>
                <div class="bg-success bg-opacity-10 p-3 rounded text-success">
                  <i class="fas fa-shopping-bag fa-lg"></i>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-xl-3">
          <div class="card border-0 shadow-sm h-100 border-start border-warning border-4">
            <div class="card-body">
              <div class="d-flex align-items-center justify-content-between">
                <div>
                  <h6 class="text-muted mb-2">Pending Orders</h6>
                  <h3 class="mb-0 fw-bold">{{ $pendingOrders }}</h3>
                  <small class="text-muted">Awaiting farmer confirmation</small>
                </div>
                <div class="bg-warning bg-opacity-10 p-3 rounded text-warning">
                  <i class="fas fa-clock fa-lg"></i>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-xl-3">
          <div class="card border-0 shadow-sm h-100 border-start border-info border-4">
            <div class="card-body">
              <div class="d-flex align-items-center justify-content-between">
                <div>
                  <h6 class="text-muted mb-2">Ready for Pickup</h6>
                  <h3 class="mb-0 fw-bold">{{ $readyOrders }}</h3>
                  <small class="text-muted">Collect at the market</small>
                </div>
                <div class="bg-info bg-opacity-10 p-3 rounded text-info">
                  <i class="fas fa-store fa-lg"></i>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-xl-3">
          <div class="card border-0 shadow-sm h-100 border-start border-success border-4">
            <div class="card-body">
              <div class="d-flex align-items-center justify-content-between">
                <div>
                  <h6 class="text-muted mb-2">Completed</h6>
                  <h3 class="mb-0 fw-bold">{{ $completedOrders }}</h3>
                  <small class="text-muted">{{ $reviewsCount }} review{{ $reviewsCount === 1 ? '' : 's' }} given</small>
                </div>
                <div class="bg-success bg-opacity-10 p-3 rounded text-success">
                  <i class="fas fa-check fa-lg"></i>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="mb-4 d-flex gap-3 flex-wrap">
        <a href="/products" class="btn btn-outline-success"><i class="fas fa-search"></i> Browse Products</a>
        <a href="/markets" class="btn btn-outline-success"><i class="fas fa-map-marker-alt"></i> Find Markets</a>
        <a href="/customer-orders" class="btn btn-outline-success"><i class="fas fa-list"></i> View Orders</a>
      </div>

      <div class="row g-4 mb-4">
        <div class="col-lg-8">
          <div class="card border-0 shadow-sm h-100">
            <div class="card-header bg-white border-0 pt-4 pb-0 d-flex justify-content-between align-items-center">
              <h5 class="mb-0 fw-bold">Recent Orders</h5>
              <a href="/customer-orders" class="text-decoration-none small text-success">View All</a>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-hover align-middle">
                  <thead>
                    <tr class="text-secondary">
                      <th>Order ID</th>
                      <th>Farmer</th>
                      <th>Products</th>
                      <th>Pickup Date</th>
                      <th>Status</th>
                      <th>Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($recentOrders as $order)
                      <tr>
                        <td class="fw-medium">{{ $order->code() }}</td>
                        <td>{{ $order->farmer?->displayName() ?? '—' }}</td>
                        <td class="text-truncate" style="max-width: 180px;">{{ $order->itemsSummary() ?: '—' }}</td>
                        <td>{{ $order->pickup_date?->format('M d, Y') }}</td>
                        <td><span class="badge bg-{{ $order->statusBadge() }}">{{ $order->statusLabel() }}</span></td>
                        <td><a href="/order-details?id={{ $order->id }}" class="btn btn-sm btn-outline-secondary">View</a></td>
                      </tr>
                    @empty
                      <tr>
                        <td colspan="6" class="text-center text-muted py-4">
                          No pre-orders yet. <a href="/products" class="text-success text-decoration-none fw-semibold">Browse the catalogue</a> to place your first one.
                        </td>
                      </tr>
                    @endforelse
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

        <div class="col-lg-4">
          <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white border-0 pt-4 pb-0">
              <h5 class="mb-0 fw-bold">Upcoming Pickups</h5>
            </div>
            <div class="card-body">
              @forelse($upcomingPickups as $pickup)
                <div class="d-flex {{ $loop->last ? '' : 'mb-3' }} border-start border-success border-3 ps-3">
                  <div class="me-3 text-center" style="min-width: 45px;">
                    <div class="h5 mb-0 text-success fw-bold">{{ $pickup->pickup_date?->format('d') }}</div>
                    <small class="text-muted fw-semibold">{{ strtoupper($pickup->pickup_date?->format('M') ?? '') }}</small>
                  </div>
                  <div>
                    <h6 class="mb-1 fw-bold">{{ $pickup->market ?: 'Market not set' }}</h6>
                    <small class="text-muted d-block"><i class="fas fa-clock me-1"></i> {{ $pickup->pickup_slot ?: 'Slot not set' }}</small>
                    <small class="text-muted"><i class="fas fa-store me-1"></i> {{ $pickup->farmer?->displayName() ?? '—' }}</small>
                    <div class="mt-1"><span class="badge bg-{{ $pickup->statusBadge() }}">{{ $pickup->statusLabel() }}</span></div>
                  </div>
                </div>
              @empty
                <p class="text-muted mb-0">Nothing scheduled. Upcoming pickups from your orders appear here.</p>
              @endforelse
            </div>
          </div>

          <div class="card border-0 shadow-sm">
            <div class="card-header bg-white border-0 pt-4 pb-0">
              <h5 class="mb-0 fw-bold">Order Activity</h5>
            </div>
            <div class="card-body">
              @forelse($recentOrders as $activity)
                <div class="d-flex {{ $loop->last ? '' : 'mb-3' }}">
                  <div class="bg-success bg-opacity-10 text-success rounded-circle p-2 me-3 d-flex align-items-center justify-content-center" style="width: 32px; height: 32px;">
                    <i class="fas fa-bell small"></i>
                  </div>
                  <div>
                    <p class="mb-1 small">Order <strong class="text-dark">{{ $activity->code() }}</strong> is <strong class="text-dark">{{ strtolower($activity->statusLabel()) }}</strong>@if($activity->market) &mdash; {{ $activity->market }}@endif.</p>
                    <small class="text-muted">{{ $activity->updated_at?->diffForHumans() }}</small>
                  </div>
                </div>
              @empty
                <p class="text-muted mb-0">No activity yet.</p>
              @endforelse
            </div>
          </div>
        </div>
      </div>

      <div class="mb-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
          <h5 class="mb-0 fw-bold">Favourite Farmers</h5>
          <a href="/customer-favorites" class="text-decoration-none small text-success">View All @if(($unreadAlerts ?? 0) > 0)&bull; {{ $unreadAlerts }} new alert{{ $unreadAlerts === 1 ? '' : 's' }}@endif</a>
        </div>
        <div class="d-flex gap-3 overflow-auto pb-2" style="white-space: nowrap;">
          @forelse($favoriteFarmers as $favFarmer)
            <div class="card border-0 shadow-sm d-inline-block" style="min-width: 250px;">
              <div class="card-body d-flex align-items-center">
                <img src="{{ $favFarmer->avatarUrl() }}" class="rounded-circle me-3" width="50" height="50" alt="{{ $favFarmer->displayName() }}">
                <div>
                  <h6 class="mb-0 fw-bold">{{ $favFarmer->displayName() }}</h6>
                  <small class="text-muted">{{ implode(', ', array_slice($favFarmer->marketNames(), 0, 2)) ?: 'No market set' }}</small>
                </div>
              </div>
            </div>
          @empty
            <p class="text-muted mb-0">No favourite farmers yet — open a stall and tap the heart to save it.</p>
          @endforelse
        </div>
      </div>

      <div class="mb-4">
        <div class="d-flex justify-content-between align-items-center mb-3">
          <h5 class="mb-0 fw-bold">Favourite Products</h5>
          <a href="/customer-favorites" class="text-decoration-none small text-success">View All</a>
        </div>
        <div class="d-flex gap-3 overflow-auto pb-2" style="white-space: nowrap;">
          @forelse($favorites as $favorite)
            @php($fp = $favorite->product)
            @if($fp)
              <div class="card border-0 shadow-sm d-inline-block" style="min-width: 200px;">
                <img src="{{ $fp->imageUrl() }}" class="card-img-top object-fit-cover" style="height:120px" alt="{{ $fp->name }}">
                <div class="card-body p-3">
                  <h6 class="mb-1 text-truncate fw-bold">
                    <a href="/product-details?id={{ $fp->id }}" class="text-dark text-decoration-none">{{ $fp->name }}</a>
                  </h6>
                  <div class="text-success fw-bold">PKR {{ number_format((float) $fp->price, 0) }}/{{ $fp->unit }}</div>
                  <small class="text-muted">{{ $fp->farmer?->displayName() }}</small>
                </div>
              </div>
            @endif
          @empty
            <p class="text-muted mb-0">No favorite products yet.</p>
          @endforelse
        </div>
      </div>

    </div>
  </main>
</div>
@endsection

@push('scripts')
<script>
  document.getElementById('sidebarToggle').addEventListener('click', () => {
    document.getElementById('sidebar').classList.add('show');
    document.getElementById('sidebarOverlay').classList.add('show');
  });
  document.getElementById('sidebarClose').addEventListener('click', () => {
    document.getElementById('sidebar').classList.remove('show');
    document.getElementById('sidebarOverlay').classList.remove('show');
  });
  document.getElementById('sidebarOverlay').addEventListener('click', () => {
    document.getElementById('sidebar').classList.remove('show');
    document.getElementById('sidebarOverlay').classList.remove('show');
  });
</script>
@endpush
