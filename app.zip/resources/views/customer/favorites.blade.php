@extends('layouts.dashboard')

@section('title', 'MarketLink - My Favorites')

@section('content')
<div class="dashboard-layout">
    <!-- Sidebar -->
    <aside class="ml-sidebar ml-sidebar-customer" id="sidebar">
      <div class="ml-sidebar-header">
        <a href="/" class="ml-sidebar-brand"><i class="fas fa-seedling"></i> MarketLink</a>
        <button class="ml-sidebar-close d-lg-none" id="sidebarClose"><i class="fas fa-times"></i></button>
      </div>
      <div class="ml-sidebar-user">
        <img src="{{ auth()->user()->avatarUrl() }}" alt="Customer" class="ml-sidebar-avatar">
        <div>
          <div class="ml-sidebar-username">{{ auth()->user()->displayName() }}</div>
          <div class="ml-sidebar-role">Customer</div>
        </div>
      </div>
      <nav class="ml-sidebar-nav">
        <a href="/customer-dashboard" class="ml-sidebar-link"><i class="fas fa-chart-pie"></i> Dashboard</a>
        <a href="/customer-profile" class="ml-sidebar-link"><i class="fas fa-user-edit"></i> My Profile</a>
        <a href="/customer-orders" class="ml-sidebar-link"><i class="fas fa-shopping-bag"></i> My Orders</a>
        <a href="/products" class="ml-sidebar-link"><i class="fas fa-store"></i> Browse Products</a>
        <a href="/customer-favorites" class="ml-sidebar-link active"><i class="fas fa-heart"></i> Favorites</a>
        <a href="/customer-reviews" class="ml-sidebar-link"><i class="fas fa-star"></i> My Reviews</a>
        <a href="/customer-profile" class="ml-sidebar-link"><i class="fas fa-cog"></i> Settings</a>
        <hr class="ml-sidebar-divider">
        <form action="/logout" method="POST">
            @csrf
            <button type="submit" class="ml-sidebar-link ml-sidebar-logout w-100 border-0 bg-transparent text-start"><i class="fas fa-sign-out-alt"></i> Logout</button>
        </form>
      </nav>
    </aside>

    <!-- Main Content -->
    <div class="dashboard-main">
      <div class="dashboard-topbar">
        <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
        <div class="d-flex align-items-center gap-3">
          <a href="/cart" class="btn btn-light position-relative"><i class="fas fa-shopping-cart"></i></a>
          <img src="{{ auth()->user()->avatarUrl() }}" alt="User" class="rounded-circle border" width="40" height="40">
        </div>
      </div>

      <div class="dashboard-content">
        <div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-3">
          <div>
            <h2 class="h4 fw-bold mb-0">My Favorites</h2>
            <p class="text-muted mb-0 small">Saved products, farmers and markets. Products you save send you a restock alert when stock returns.</p>
          </div>
          <div class="d-flex gap-2">
            <a href="/products" class="btn btn-success"><i class="fas fa-store"></i> Browse Products</a>
            <a href="/farmers" class="btn btn-outline-success"><i class="fas fa-tractor"></i> Browse Farmers</a>
          </div>
        </div>

        <ul class="nav nav-pills flex-wrap gap-2 mb-4" role="tablist">
          <li class="nav-item"><button class="nav-link active" data-bs-toggle="pill" data-bs-target="#tab-products" type="button"><i class="fas fa-box me-1"></i>Products ({{ ($favorites ?? collect())->count() }})</button></li>
          <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#tab-farmers" type="button"><i class="fas fa-tractor me-1"></i>Farmers ({{ ($farmerFavorites ?? collect())->count() }})</button></li>
          <li class="nav-item"><button class="nav-link" data-bs-toggle="pill" data-bs-target="#tab-markets" type="button"><i class="fas fa-store me-1"></i>Markets ({{ ($marketFavorites ?? collect())->count() }})</button></li>
        </ul>

        <div class="tab-content">
        <div class="tab-pane fade show active" id="tab-products" role="tabpanel">
        <div class="row g-4">
          @forelse($favorites ?? [] as $fav)
            @if($fav->product)
            <div class="col-md-6 col-xl-4">
              <div class="card border-0 shadow-sm rounded-3 h-100 overflow-hidden">
                <div class="position-relative">
                  <img src="{{ $fav->product->imageUrl() }}" class="card-img-top" alt="Product" style="height: 180px; object-fit: cover;">
                  <span class="badge bg-success position-absolute top-0 start-0 m-2">{{ $fav->product->category }}</span>
                </div>
                <div class="card-body">
                  <h6 class="fw-bold mb-1">{{ $fav->product->name }}</h6>
                  <div class="small text-muted mb-2">
                    <i class="fas fa-store me-1"></i>{{ $fav->product->farmer ? $fav->product->farmer->displayName() : 'Farmer' }}
                  </div>
                  <div class="d-flex justify-content-between align-items-center mb-3">
                    <span class="fw-bold text-success">PKR {{ number_format($fav->product->price, 0) }} <small class="text-muted fw-normal">/ {{ $fav->product->unit }}</small></span>
                    @if($fav->product->stock > 0 && $fav->product->is_available)
                      <span class="badge bg-success">In Stock</span>
                    @else
                      <span class="badge bg-secondary">Unavailable</span>
                    @endif
                  </div>
                  <div class="d-flex gap-2">
                    <a href="/product-details?id={{ $fav->product->id }}" class="btn btn-outline-success btn-sm flex-grow-1"><i class="fas fa-eye me-1"></i> View</a>
                    <form action="/favorites/toggle" method="POST" class="flex-grow-1 d-grid">
                      @csrf
                      <input type="hidden" name="product_id" value="{{ $fav->product->id }}">
                      <button type="submit" class="btn btn-outline-danger btn-sm"><i class="fas fa-heart-broken me-1"></i> Remove</button>
                    </form>
                  </div>
                </div>
              </div>
            </div>
            @endif
          @empty
            <div class="col-12">
              <div class="card border-0 shadow-sm rounded-3">
                <div class="card-body text-center py-5 text-muted">
                  <i class="fas fa-heart fa-2x mb-3 d-block"></i>
                  No favorites yet. Tap the <i class="fas fa-heart text-danger"></i> on any product to save it here.
                  <div class="mt-3"><a href="/products" class="btn btn-success">Browse Products</a></div>
                </div>
              </div>
            </div>
          @endforelse
        </div>
        </div><!-- /tab-products -->

        <div class="tab-pane fade" id="tab-farmers" role="tabpanel">
          <div class="row g-4">
            @forelse($farmerFavorites ?? [] as $fav)
              @if($fav->farmer)
              <div class="col-md-6 col-xl-4">
                <div class="card border-0 shadow-sm rounded-3 h-100">
                  <div class="card-body text-center">
                    <img src="{{ $fav->farmer->avatarUrl() }}" class="rounded-circle border mb-2" width="72" height="72" alt="Farmer" style="object-fit: cover;">
                    <h6 class="fw-bold mb-0">{{ $fav->farmer->displayName() }}</h6>
                    <div class="small text-muted">{{ $fav->farmer->marketNames() ? implode(', ', $fav->farmer->marketNames()) : 'Local farmer' }}</div>
                    @if($fav->farmer->farmer?->operating_days)
                      <div class="small text-muted mt-1"><i class="fas fa-calendar-day me-1"></i>{{ implode(', ', $fav->farmer->farmer->operating_days) }}</div>
                    @endif
                    <div class="d-flex gap-2 mt-3">
                      <a href="/farmer-profile?id={{ $fav->farmer->id }}" class="btn btn-outline-success btn-sm flex-grow-1"><i class="fas fa-eye me-1"></i>Profile</a>
                      <form action="/favorites/toggle" method="POST" class="flex-grow-1 d-grid">
                        @csrf
                        <input type="hidden" name="farmer_id" value="{{ $fav->farmer->id }}">
                        <button type="submit" class="btn btn-outline-danger btn-sm"><i class="fas fa-heart-broken me-1"></i>Remove</button>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
              @endif
            @empty
              <div class="col-12"><div class="card border-0 shadow-sm rounded-3"><div class="card-body text-center py-5 text-muted">
                <i class="fas fa-tractor fa-2x mb-3 d-block"></i>No favourite farmers yet — open a farmer profile and tap the heart.
                <div class="mt-3"><a href="/farmers" class="btn btn-success">Browse Farmers</a></div>
              </div></div></div>
            @endforelse
          </div>
        </div><!-- /tab-farmers -->

        <div class="tab-pane fade" id="tab-markets" role="tabpanel">
          <div class="row g-4">
            @forelse($marketFavorites ?? [] as $fav)
              @if($fav->market)
              <div class="col-md-6 col-xl-4">
                <div class="card border-0 shadow-sm rounded-3 h-100">
                  <img src="{{ $fav->market->imageUrl() }}" class="card-img-top" alt="Market" style="height:150px;object-fit:cover;">
                  <div class="card-body">
                    <h6 class="fw-bold mb-1">{{ $fav->market->name }}</h6>
                    <div class="small text-muted mb-1"><i class="fas fa-map-marker-alt me-1"></i>{{ $fav->market->address ?: $fav->market->city }}</div>
                    <div class="small text-muted mb-3"><i class="fas fa-clock me-1"></i>{{ $fav->market->daysLabel() }}{{ $fav->market->hoursLabel() ? ' · ' . $fav->market->hoursLabel() : '' }}</div>
                    <div class="d-flex gap-2">
                      <a href="/market-details?id={{ $fav->market->id }}" class="btn btn-outline-success btn-sm flex-grow-1"><i class="fas fa-eye me-1"></i>View</a>
                      <form action="/favorites/toggle" method="POST" class="flex-grow-1 d-grid">
                        @csrf
                        <input type="hidden" name="market_id" value="{{ $fav->market->id }}">
                        <button type="submit" class="btn btn-outline-danger btn-sm"><i class="fas fa-heart-broken me-1"></i>Remove</button>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
              @endif
            @empty
              <div class="col-12"><div class="card border-0 shadow-sm rounded-3"><div class="card-body text-center py-5 text-muted">
                <i class="fas fa-store fa-2x mb-3 d-block"></i>No favourite markets yet — save a market from its details page.
                <div class="mt-3"><a href="/markets" class="btn btn-success">Browse Markets</a></div>
              </div></div></div>
            @endforelse
          </div>
        </div><!-- /tab-markets -->
        </div><!-- /tab-content -->

      </div>
    </div>
  </div>
@endsection

@push('scripts')
<script>
    document.addEventListener('DOMContentLoaded', () => {
      const sidebar = document.getElementById('sidebar');
      const sidebarToggle = document.getElementById('sidebarToggle');
      const sidebarClose = document.getElementById('sidebarClose');
      if (sidebarToggle) sidebarToggle.addEventListener('click', () => sidebar.classList.add('show'));
      if (sidebarClose) sidebarClose.addEventListener('click', () => sidebar.classList.remove('show'));
    });
  </script>
@endpush
