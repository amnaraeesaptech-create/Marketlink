@extends('layouts.dashboard')

@section('title', 'Edit Stall Profile — MarketLink')

@section('content')
<div class="dashboard-layout">
    @include('includes.sidebar-farmer', ['active' => 'profile'])

    <div class="dashboard-main">
        <div class="dashboard-topbar">
            <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
            <h1 class="ml-topbar-title">Edit Stall Profile</h1>
            <div class="d-flex align-items-center gap-2">
                <a href="/farmer-profile" class="btn btn-sm btn-outline-success"><i class="fas fa-eye me-1"></i>View Public Profile</a>
            </div>
        </div>

        <div class="dashboard-content">
            <form action="/farmer-profile" method="POST" enctype="multipart/form-data">
                @csrf
                @method('PUT')

                <!-- Business info -->
                <div class="card border-0 shadow-sm rounded-4 mb-4">
                    <div class="card-body p-4">
                        <h5 class="fw-bold mb-3"><i class="fas fa-store me-2 text-success"></i>Business Information</h5>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label fw-medium small" for="stall_name">Stall / Business Name *</label>
                                <input type="text" name="stall_name" id="stall_name" value="{{ old('stall_name', $user->farmer->stall_name ?? $user->name) }}" class="form-control @error('stall_name') is-invalid @enderror" required>
                                @error('stall_name')<div class="text-danger small mt-1">{{ $message }}</div>@enderror
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-medium small" for="contact_person">Contact Person *</label>
                                <input type="text" name="contact_person" id="contact_person" value="{{ old('contact_person', $user->farmer->contact_person ?? $user->name) }}" class="form-control @error('contact_person') is-invalid @enderror" required>
                                @error('contact_person')<div class="text-danger small mt-1">{{ $message }}</div>@enderror
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-medium small" for="phone">Contact Number *</label>
                                <input type="text" name="phone" id="phone" value="{{ old('phone', $user->phone) }}" class="form-control @error('phone') is-invalid @enderror" required>
                                @error('phone')<div class="text-danger small mt-1">{{ $message }}</div>@enderror
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-medium small" for="email">Email Address *</label>
                                <input type="email" name="email" id="email" value="{{ old('email', $user->email) }}" class="form-control @error('email') is-invalid @enderror" required>
                                @error('email')<div class="text-danger small mt-1">{{ $message }}</div>@enderror
                            </div>
                            <div class="col-12">
                                <label class="form-label fw-medium small" for="address">Farm / Business Address *</label>
                                <input type="text" name="address" id="address" value="{{ old('address', $user->address) }}" class="form-control @error('address') is-invalid @enderror" required>
                                @error('address')<div class="text-danger small mt-1">{{ $message }}</div>@enderror
                            </div>
                            <div class="col-12">
                                <label class="form-label fw-medium small" for="description">About the Farm</label>
                                <textarea name="description" id="description" rows="3" class="form-control @error('description') is-invalid @enderror" placeholder="Tell customers about your farm, practices and specialties...">{{ old('description', $user->farmer->description ?? '') }}</textarea>
                                @error('description')<div class="text-danger small mt-1">{{ $message }}</div>@enderror
                            </div>
                            <div class="col-12">
                                <label class="form-label fw-medium small" for="avatar">Stall / Profile Photo</label>
                                <input type="file" name="avatar" id="avatar" accept="image/*" class="form-control @error('avatar') is-invalid @enderror">
                                @error('avatar')<div class="text-danger small mt-1">{{ $message }}</div>@enderror
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Markets + days + categories -->
                <div class="card border-0 shadow-sm rounded-4 mb-4">
                    <div class="card-body p-4">
                        <h5 class="fw-bold mb-3"><i class="fas fa-map-marked-alt me-2 text-success"></i>Markets & Schedule</h5>
                        @php
                            $myMarkets = old('markets', $selectedMarkets ?? $user->marketNames());
                            $myDays = old('operating_days', $user->farmer->operating_days ?? []);
                            $myCats = old('categories', $user->farmer->categories ?? []);
                            $allDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
                            $allCats = \App\Models\Category::names();
                        @endphp
                        <label class="form-label fw-medium small">Markets you sell at</label>
                        <div class="row g-2 mb-4">
                            @forelse($allMarkets as $market)
                                <div class="col-md-6">
                                    <div class="form-check border rounded p-2">
                                        <input class="form-check-input ms-1" type="checkbox" name="markets[]" value="{{ $market->name }}" id="mkt-{{ $market->id }}" {{ in_array($market->name, $myMarkets) ? 'checked' : '' }}>
                                        <label class="form-check-label ms-2" for="mkt-{{ $market->id }}">{{ $market->name }}<span class="text-muted small"> — {{ $market->city }}</span></label>
                                    </div>
                                </div>
                            @empty
                                <div class="col-12 text-muted small">No markets are open yet — an admin adds them from the Markets page.</div>
                            @endforelse
                        </div>

                        <label class="form-label fw-medium small">Operating days</label>
                        <div class="d-flex flex-wrap gap-2 mb-4">
                            @foreach($allDays as $day)
                                <div class="m-0">
                                    <input class="btn-check" type="checkbox" name="operating_days[]" value="{{ $day }}" id="day-{{ $day }}" autocomplete="off" {{ in_array($day, $myDays) ? 'checked' : '' }}>
                                    <label class="btn btn-outline-success btn-sm" for="day-{{ $day }}">{{ $day }}</label>
                                </div>
                            @endforeach
                        </div>

                        <label class="form-label fw-medium small">Product categories</label>
                        <div class="d-flex flex-wrap gap-3">
                            @foreach($allCats as $cat)
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="categories[]" value="{{ $cat }}" id="cat-{{ $loop->index }}" {{ in_array($cat, $myCats) ? 'checked' : '' }}>
                                    <label class="form-check-label" for="cat-{{ $loop->index }}">{{ $cat }}</label>
                                </div>
                            @endforeach
                        </div>
                    </div>
                </div>

                <!-- Pickup windows -->
                <div class="card border-0 shadow-sm rounded-4 mb-4">
                    <div class="card-body p-4">
                        <h5 class="fw-bold mb-1"><i class="fas fa-clock me-2 text-success"></i>Pickup Time Windows</h5>
                        <p class="text-muted small mb-3">Set the days and times customers can pick up their orders. Only slots matching the selected pickup date will appear at checkout.</p>

                        {{-- column headers --}}
                        <div class="row g-2 mb-1 d-none d-md-flex">
                            <div class="col-md-3"><span class="form-label fw-medium small mb-0">Day</span></div>
                            <div class="col-md-3"><span class="form-label fw-medium small mb-0">From</span></div>
                            <div class="col-md-3"><span class="form-label fw-medium small mb-0">To</span></div>
                            <div class="col-md-3"></div>
                        </div>

                        <div id="pickupWindows">
                        @php
                            $existingWindows = old('pickup_windows', $user->farmer->pickup_windows ?? []);
                            // Ensure at least one row
                            if (empty($existingWindows)) $existingWindows = [['day'=>'Sat','start'=>'08:00','end'=>'12:00','label'=>'']];
                        @endphp
                        @foreach($existingWindows as $i => $w)
                        @php
                            $wDay   = is_array($w) ? ($w['day']   ?? 'Sat') : 'Sat';
                            $wStart = is_array($w) ? ($w['start'] ?? '')    : '';
                            $wEnd   = is_array($w) ? ($w['end']   ?? '')    : '';
                            // Legacy string: try to parse day
                            if (!is_array($w) && is_string($w) && trim($w)) {
                                foreach (['Mon','Tue','Wed','Thu','Fri','Sat','Sun'] as $d) {
                                    if (stripos(trim($w), $d) === 0) { $wDay = $d; break; }
                                }
                            }
                        @endphp
                        <div class="pickup-row row g-2 mb-2 align-items-center">
                            <div class="col-md-3">
                                <select name="pickup_windows[{{ $i }}][day]" class="form-select form-select-sm">
                                    @foreach(['Mon','Tue','Wed','Thu','Fri','Sat','Sun'] as $d)
                                        <option value="{{ $d }}" {{ $wDay === $d ? 'selected' : '' }}>{{ $d }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-md-3">
                                <input type="time" name="pickup_windows[{{ $i }}][start]"
                                       value="{{ $wStart }}"
                                       class="form-control form-control-sm"
                                       placeholder="08:00">
                            </div>
                            <div class="col-1 text-center text-muted d-none d-md-block small pt-1">to</div>
                            <div class="col-md-3">
                                <input type="time" name="pickup_windows[{{ $i }}][end]"
                                       value="{{ $wEnd }}"
                                       class="form-control form-control-sm"
                                       placeholder="12:00">
                            </div>
                            <div class="col-md-2">
                                <button type="button" class="btn btn-outline-danger btn-sm remove-window w-100">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                        </div>
                        @endforeach
                        </div>

                        <button type="button" class="btn btn-sm btn-outline-success mt-1" id="addWindow">
                            <i class="fas fa-plus me-1"></i>Add Window
                        </button>
                    </div>
                </div>

                <!-- Order cut-off -->
                <div class="card border-0 shadow-sm rounded-4 mb-4">
                    <div class="card-body p-4">
                        <h5 class="fw-bold mb-1"><i class="fas fa-hourglass-half me-2 text-success"></i>Order Cut-off</h5>
                        <p class="text-muted small mb-3">Customers can place, change or cancel a pre-order only until this many hours before pickup. After that the order is locked so you can harvest and pack.</p>
                        <div class="row g-3 align-items-end">
                            <div class="col-md-4">
                                <label class="form-label fw-medium small" for="cutoff_hours">Cut-off hours</label>
                                <input type="number" min="1" max="168" name="cutoff_hours" id="cutoff_hours"
                                       value="{{ old('cutoff_hours', $user->farmer->cutoff_hours ?? 12) }}"
                                       class="form-control @error('cutoff_hours') is-invalid @enderror">
                                @error('cutoff_hours')<div class="text-danger small mt-1">{{ $message }}</div>@enderror
                            </div>
                            <div class="col-md-8">
                                <div class="alert alert-light border small mb-0">
                                    <i class="fas fa-circle-info text-success me-1"></i>
                                    Current setting: <strong>{{ (int) ($user->farmer->cutoff_hours ?? 12) }} hours</strong> before the pickup slot.
                                    Typical values: 12h (same-day market), 24h (next-morning orders), 48h (weekend market).
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Map pin -->
                <div class="card border-0 shadow-sm rounded-4 mb-4">
                    <div class="card-body p-4">
                        <h5 class="fw-bold mb-1"><i class="fas fa-map-pin me-2 text-success"></i>Stall Location (OpenStreetMap)</h5>
                        <p class="text-muted small mb-3">Click the map to pin your stall, or drag the marker to adjust. Customers see this pin and get directions to you.</p>
                        @include('includes.location-picker', [
                            'latId'  => 'latitude',
                            'lngId'  => 'longitude',
                            'latVal' => old('latitude', $user->farmer->latitude ?? ''),
                            'lngVal' => old('longitude', $user->farmer->longitude ?? ''),
                        ])
                    </div>
                </div>

                <div class="d-flex gap-2 mb-5">
                    <button type="submit" class="btn ml-btn-primary"><i class="fas fa-save me-2"></i>Save Profile</button>
                    <a href="/farmer-profile" class="btn btn-outline-secondary">Cancel</a>
                </div>
            </form>

            <!-- Password -->
            <div class="card border-0 shadow-sm rounded-4 mb-5">
                <div class="card-body p-4">
                    <h5 class="fw-bold mb-3"><i class="fas fa-key me-2 text-success"></i>Change Password</h5>
                    <form action="/farmer-password" method="POST">
                        @csrf
                        @method('PUT')
                        <div class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label fw-medium small" for="current_password">Current Password</label>
                                <input type="password" name="current_password" id="current_password" class="form-control" required>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-medium small" for="password">New Password</label>
                                <input type="password" name="password" id="password" class="form-control" required>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-medium small" for="password_confirmation">Confirm New</label>
                                <input type="password" name="password_confirmation" id="password_confirmation" class="form-control" required>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-outline-success mt-3">Update Password</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    document.getElementById('addWindow')?.addEventListener('click', function () {
        const wrap = document.getElementById('pickupWindows');
        const idx  = wrap.querySelectorAll('.pickup-row').length;
        const days = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
        const opts = days.map(d => `<option value="${d}"${d==='Sat'?' selected':''}>${d}</option>`).join('');
        const row  = document.createElement('div');
        row.className = 'pickup-row row g-2 mb-2 align-items-center';
        row.innerHTML =
            `<div class="col-md-3"><select name="pickup_windows[${idx}][day]" class="form-select form-select-sm">${opts}</select></div>` +
            `<div class="col-md-3"><input type="time" name="pickup_windows[${idx}][start]" class="form-control form-control-sm" placeholder="08:00"></div>` +
            `<div class="col-1 text-center text-muted d-none d-md-block small pt-1">to</div>` +
            `<div class="col-md-3"><input type="time" name="pickup_windows[${idx}][end]" class="form-control form-control-sm" placeholder="12:00"></div>` +
            `<div class="col-md-2"><button type="button" class="btn btn-outline-danger btn-sm remove-window w-100"><i class="fas fa-times"></i></button></div>`;
        wrap.appendChild(row);
    });
    document.getElementById('pickupWindows')?.addEventListener('click', function (e) {
        const btn = e.target.closest('.remove-window');
        if (btn && this.querySelectorAll('.pickup-row').length > 1) {
            btn.closest('.pickup-row').remove();
        }
    });
</script>
@endpush
