@extends('layouts.app')

@section('title', ($farmerUser->displayName() ?? 'Stall') . ' — MarketLink')

@section('content')
@php
    $firstMarket = $farmerUser->markets()->first();
    $mapLat = ($farmer?->latitude ?? null) ?: ($firstMarket->latitude ?? null);
    $mapLng = ($farmer?->longitude ?? null) ?: ($firstMarket->longitude ?? null);
    $mapLabel = ($farmer?->latitude ?? null) ? 'Stall pin' : 'Market pin';
@endphp
<!-- Profile Header -->
    <section class="profile-header" style="background-image: url('{{ $farmerUser->farmer?->avatar ? (str_starts_with($farmerUser->farmer->avatar, 'http') ? $farmerUser->farmer->avatar : '/storage/' . $farmerUser->farmer->avatar) : \App\Support\Placeholder::cover($farmerUser->displayName(), 'farmer-' . $farmerUser->id, 1600, 400) }}'); background-size: cover; background-position: center;">
        <div class="profile-overlay">
            <div class="container">
                <div class="row align-items-end">
                    <div class="col-md-auto text-center text-md-start mb-3 mb-md-0">
                        <img src="{{ $farmerUser->avatarUrl() }}" alt="{{ $farmerUser->displayName() }}" class="profile-avatar shadow">
                    </div>
                    <div class="col-md">
                        <h1 class="fw-bold mb-1">{{ $farmerUser->displayName() }}</h1>
                        <p class="fs-5 text-light mb-2">
                            {{ $farmerUser->name }}
                            @if($farmer?->address) &bull; <i class="fa-solid fa-location-dot ms-1"></i> {{ $farmer->address }}@endif
                        </p>
                        <div class="d-flex align-items-center mb-0 gap-3 flex-wrap">
                            <span class="text-warning">
                                @php($stars = (int) round($avgRating ?? 0))
                                @for($i = 1; $i <= 5; $i++)
                                    <i class="fa-solid fa-star{{ $i <= $stars ? '' : '-o' }}"></i>
                                @endfor
                                <span class="text-light ms-1">
                                    {{ $avgRating ? number_format($avgRating, 1) : 'New' }} ({{ $reviewCount }} review{{ $reviewCount === 1 ? '' : 's' }})
                                </span>
                            </span>
                            @foreach(array_slice($farmer?->categories ?? [], 0, 2) as $category)
                                <span class="badge bg-success">{{ $category }}</span>
                            @endforeach
                        </div>
                    </div>
                    <div class="col-md-auto mt-3 mt-md-0 d-flex gap-2 justify-content-center">
                        @if($isOwner)
                            <a href="/farmer-profile/edit" class="btn btn-warning"><i class="fas fa-pen me-2"></i>Edit Profile</a>
                            <a href="/farmer-dashboard" class="btn btn-outline-light"><i class="fas fa-chart-pie me-2"></i>Dashboard</a>
                        @else
                            <a href="/products" class="btn btn-success"><i class="fa-solid fa-basket-shopping me-2"></i>Pre-Order Products</a>
                            @auth
                              @if(auth()->user()->isCustomer())
                                @php($isFavFarmer = auth()->user()->favorites()->where('farmer_id', $farmerUser->id)->exists())
                                <form action="/favorites/toggle" method="POST" class="d-inline">
                                  @csrf
                                  <input type="hidden" name="farmer_id" value="{{ $farmerUser->id }}">
                                  <button type="submit" class="btn {{ $isFavFarmer ? 'btn-danger' : 'btn-outline-light' }}">
                                    <i class="fa{{ $isFavFarmer ? 's' : 'r' }} fa-heart me-2"></i>{{ $isFavFarmer ? 'Saved' : 'Favourite' }}
                                  </button>
                                </form>
                              @endif
                            @endauth
                            <a href="/farmers" class="btn btn-outline-light"><i class="fa-solid fa-arrow-left me-2"></i>All Farmers</a>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Breadcrumb -->
    <div class="bg-light py-2 border-bottom">
        <div class="container">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="/" class="text-success text-decoration-none">Home</a></li>
                    <li class="breadcrumb-item"><a href="/farmers" class="text-success text-decoration-none">Farmers</a></li>
                    <li class="breadcrumb-item active" aria-current="page">{{ $farmerUser->displayName() }}</li>
                </ol>
            </nav>
        </div>
    </div>

    <!-- Main Content -->
    <div class="container my-5">
        <div class="row g-5">
            <!-- Left Column -->
            <div class="col-lg-8">
                <div class="card border-0 shadow-sm mb-5">
                    <div class="card-body p-4">
                        <h3 class="fw-bold mb-3">About the Farm</h3>
                        <p class="text-muted">
                            {{ $farmer?->description ?: 'This farmer has not written a farm description yet.' }}
                        </p>
                        <h6 class="fw-bold mb-2">Specialties</h6>
                        @forelse($farmer?->categories ?? [] as $category)
                            <span class="badge bg-light text-dark border me-1">{{ $category }}</span>
                        @empty
                            <span class="text-muted small">No categories selected yet.</span>
                        @endforelse
                    </div>
                </div>

                <h3 class="fw-bold mb-4">Available Products ({{ $products->count() }})</h3>
                <div class="row g-4 mb-5">
                    @forelse($products as $product)
                        <div class="col-sm-6">
                            <div class="card border-0 shadow-sm h-100">
                                <img src="{{ $product->imageUrl() }}" class="card-img-top" style="height:180px;object-fit:cover" alt="{{ $product->name }}">
                                <div class="card-body">
                                    <h5 class="fw-bold mb-1">
                                        <a href="/product-details?id={{ $product->id }}" class="text-dark text-decoration-none">{{ $product->name }}</a>
                                    </h5>
                                    <p class="text-muted small mb-2">{{ $product->category }}</p>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <span class="fw-bold text-success">PKR {{ number_format((float) $product->price, 0) }} / {{ $product->unit }}</span>
                                        <span class="badge bg-light text-dark">{{ $product->stock }} in stock</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @empty
                        <div class="col-12 text-muted">This stall has no products listed for sale right now.</div>
                    @endforelse
                </div>

                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h3 class="fw-bold mb-0">Customer Reviews</h3>
                    <span class="text-muted small">{{ $reviewCount }} total &bull; average {{ $avgRating ? number_format($avgRating, 1) : '—' }}/5</span>
                </div>
                @forelse($reviews as $review)
                    <div class="card border-0 shadow-sm mb-3">
                        <div class="card-body">
                            <div class="d-flex align-items-center gap-3 mb-2">
                                <img src="{{ $review->customer?->avatarUrl() }}" class="rounded-circle" width="44" height="44" alt="{{ $review->customer?->name }}">
                                <div>
                                    <h6 class="fw-bold mb-0">{{ $review->customer?->name ?? 'Client' }}</h6>
                                    <small class="text-muted">{{ $review->created_at?->format('M d, Y') }}</small>
                                </div>
                                <div class="ms-auto text-warning">
                                    @for($i = 1; $i <= 5; $i++)
                                        <i class="fa{{ $i <= $review->rating ? 's' : 'r' }} fa-star"></i>
                                    @endfor
                                </div>
                            </div>
                            <p class="text-muted mb-0">{{ $review->comment ?: 'No comment left.' }}</p>
                        </div>
                    </div>
                @empty
                    <p class="text-muted">No reviews written for this stall yet.</p>
                @endforelse
            </div>

            <!-- Right Column -->
            <div class="col-lg-4">
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-body">
                        <h5 class="card-title fw-bold mb-3"><i class="fa-solid fa-store text-success me-2"></i>Where to find us</h5>
                        @forelse($farmerUser->markets()->get() as $market)
                            <div class="mb-3">
                                <a href="/market-details?id={{ $market->id }}" class="fw-semibold text-success text-decoration-none">{{ $market->name }}</a>
                                <div class="small text-muted">{{ $market->daysLabel() }} &bull; {{ $market->hoursLabel() }}</div>
                            </div>
                        @empty
                            <p class="text-muted small mb-0">No market linked yet.</p>
                        @endforelse
                    </div>
                </div>

                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-body">
                        <h5 class="card-title fw-bold mb-3"><i class="fa-solid fa-box-open text-success me-2"></i>Pickup Windows</h5>
                        @forelse($farmer?->pickup_windows ?? [] as $window)
                            <span class="badge bg-light text-dark border mb-1">{{ $window }}</span>
                        @empty
                            <p class="text-muted small mb-0">Not set yet.</p>
                        @endforelse
                        @if($farmer?->operating_days)
                            <hr>
                            <div class="small text-muted mb-0">Operating days: {{ implode(', ', $farmer->operating_days) }}</div>
                        @endif
                    </div>
                </div>

                @if($mapLat && $mapLng)
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-body">
                        <h5 class="card-title fw-bold mb-3"><i class="fa-solid fa-map-location-dot text-success me-2"></i>Pickup Location</h5>
                        <div class="rounded-3 overflow-hidden border" style="height:220px;">
                            <iframe title="Map — {{ $farmerUser->displayName() }}" width="100%" height="220" style="border:0;display:block"
                                    loading="lazy" referrerpolicy="no-referrer-when-downgrade" src="https://www.openstreetmap.org/export/embed.html?bbox={{ (float) $mapLng - 0.01 }}%2C{{ (float) $mapLat - 0.01 }}%2C{{ (float) $mapLng + 0.01 }}%2C{{ (float) $mapLat + 0.01 }}&amp;layer=mapnik&amp;marker={{ (float) $mapLat }}%2C{{ (float) $mapLng }}"></iframe>
                        </div>
                        <div class="small text-muted mt-2">{{ $mapLabel }}: {{ number_format((float) $mapLat, 5) }}, {{ number_format((float) $mapLng, 5) }}</div>
                        <div class="d-grid gap-2 mt-2">
                          <a class="btn btn-outline-success btn-sm" target="_blank" rel="noopener"
                             href="https://www.openstreetmap.org/directions?to={{ (float) $mapLat }}%2C{{ (float) $mapLng }}">
                            <i class="fa-solid fa-diamond-turn-right me-1"></i>Directions to pickup
                          </a>
                          <a class="btn btn-outline-secondary btn-sm" target="_blank" rel="noopener"
                             href="https://www.openstreetmap.org/?mlat={{ (float) $mapLat }}&amp;mlon={{ (float) $mapLng }}#map=16/{{ (float) $mapLat }}/{{ (float) $mapLng }}">
                            <i class="fa-solid fa-up-right-from-square me-1"></i>Open larger map
                          </a>
                        </div>
                    </div>
                </div>
                @endif

                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-body">
                        <h5 class="card-title fw-bold mb-3"><i class="fa-solid fa-address-card text-success me-2"></i>Contact</h5>
                        <p class="small mb-1"><i class="fa-solid fa-user text-muted me-2"></i>{{ $farmerUser->name }}</p>
                        <p class="small mb-1"><i class="fa-solid fa-phone text-muted me-2"></i>{{ $farmerUser->phone ?: '—' }}</p>
                        <p class="small mb-0"><i class="fa-solid fa-envelope text-muted me-2"></i>{{ $farmerUser->email }}</p>
                    </div>
                </div>

                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title fw-bold mb-3"><i class="fa-solid fa-chart-simple text-success me-2"></i>Stall Stats</h5>
                        <div class="d-flex justify-content-between mb-2"><span class="text-muted">Products (total)</span><span class="fw-bold">{{ $productCount }}</span></div>
                        <div class="d-flex justify-content-between mb-2"><span class="text-muted">On sale now</span><span class="fw-bold">{{ $products->count() }}</span></div>
                        <div class="d-flex justify-content-between mb-0"><span class="text-muted">Reviews</span><span class="fw-bold">{{ $reviewCount }}</span></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
