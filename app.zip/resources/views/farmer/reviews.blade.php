@extends('layouts.dashboard')

@section('title', 'MarketLink - Farmer Reviews')

@section('content')
<div class="dashboard-layout">
    <!-- Sidebar -->
    <aside class="ml-sidebar ml-sidebar-farmer" id="sidebar">
      <div class="ml-sidebar-header">
        <a href="/" class="ml-sidebar-brand"><i class="fas fa-seedling"></i> MarketLink</a>
        <button class="ml-sidebar-close d-lg-none" id="sidebarClose"><i class="fas fa-times"></i></button>
      </div>
      <div class="ml-sidebar-user">
        <img src="{{ auth()->user()->avatarUrl() }}" alt="Farmer" class="ml-sidebar-avatar">
        <div>
          <div class="ml-sidebar-username">{{ auth()->user()->displayName() }}</div>
          <div class="ml-sidebar-role">Farmer</div>
        </div>
      </div>
      <nav class="ml-sidebar-nav">
        <a href="/farmer-dashboard" class="ml-sidebar-link"><i class="fas fa-chart-pie"></i> Dashboard</a>
        <a href="/farmer-profile" class="ml-sidebar-link"><i class="fas fa-user-edit"></i> My Profile</a>
        <a href="/farmer-products" class="ml-sidebar-link"><i class="fas fa-box"></i> Products</a>
        <a href="/farmer-add-product" class="ml-sidebar-link"><i class="fas fa-plus-circle"></i> Add Product</a>
        <a href="/farmer-products" class="ml-sidebar-link"><i class="fas fa-warehouse"></i> Inventory</a>
        <a href="/farmer-orders" class="ml-sidebar-link"><i class="fas fa-shopping-bag"></i> Orders</a>
        <a href="/farmer-profile/edit" class="ml-sidebar-link"><i class="fas fa-clock"></i> Pickup Slots</a>
        <a href="/farmer-reviews" class="ml-sidebar-link active"><i class="fas fa-star"></i> Reviews</a>
        <a href="/farmer-stock-template" class="ml-sidebar-link"><i class="fas fa-layer-group"></i> Weekly Stock</a>
        <a href="/notifications" class="ml-sidebar-link"><i class="fas fa-bell"></i> Notifications</a>
        <a href="/farmer-orders" class="ml-sidebar-link"><i class="fas fa-chart-bar"></i> Sales History</a>
        <hr class="ml-sidebar-divider">
        <form action="/logout" method="POST">
            @csrf
            <button type="submit" class="ml-sidebar-link ml-sidebar-logout w-100 border-0 bg-transparent text-start"><i class="fas fa-sign-out-alt"></i> Logout</button>
        </form>
      </nav>
    </aside>

    <!-- Main Content -->
    <div class="dashboard-main">
      <div class="dashboard-topbar">
        <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
        <div class="d-flex align-items-center gap-3">
          <button class="btn btn-light position-relative" type="button">
            <i class="fas fa-bell"></i>
          </button>
          <img src="{{ auth()->user()->avatarUrl() }}" alt="User" class="rounded-circle border" width="40" height="40" style="object-fit: cover;">
        </div>
      </div>

      <div class="dashboard-content">

        <div class="review-header mb-4">
          <h2 class="h4 fw-bold mb-0">Customer Reviews</h2>
          <p class="text-muted mb-0">Reviews on your stall and on individual products from completed orders — reply to keep buyers informed.</p>
          <div class="d-flex gap-2 mt-3 flex-wrap">
            <span class="badge bg-success">{{ $repliedCount }} replied</span>
            <span class="badge {{ $awaitingReply ? 'bg-warning text-dark' : 'bg-light text-muted' }}">{{ $awaitingReply }} awaiting reply</span>
          </div>
        </div>

        <!-- Stats Overview -->
        <div class="row g-4 mb-4">
          <div class="col-md-4">
            <div class="card border-0 shadow-sm rounded-3 h-100 text-center p-4 review-overall-card">
              <div class="overall-score display-4 fw-bold">{{ $avgFmt }}</div>
              <div class="overall-stars my-2 fs-5 js-stars" data-rating="{{ $avgFmt }}"></div>
              <div class="text-muted small">Based on {{ $total }} review(s)</div>
            </div>
          </div>

          <div class="col-md-8">
            <div class="card border-0 shadow-sm rounded-3 h-100 p-4 rating-dist-card">
              <h6 class="fw-bold mb-3">Rating Breakdown</h6>
              <div class="d-flex align-items-center gap-3 mb-2">
                  <span class="small fw-medium" style="width: 45px;">5 ★</span>
                  <div class="progress flex-grow-1" style="height: 8px;">
                    <div class="progress-bar bg-warning" role="progressbar" style="width: {{ $pct5 }}%"></div>
                  </div>
                  <span class="small text-muted" style="width: 40px;">{{ $n5 }}</span>
                </div>
              <div class="d-flex align-items-center gap-3 mb-2">
                  <span class="small fw-medium" style="width: 45px;">4 ★</span>
                  <div class="progress flex-grow-1" style="height: 8px;">
                    <div class="progress-bar bg-warning" role="progressbar" style="width: {{ $pct4 }}%"></div>
                  </div>
                  <span class="small text-muted" style="width: 40px;">{{ $n4 }}</span>
                </div>
              <div class="d-flex align-items-center gap-3 mb-2">
                  <span class="small fw-medium" style="width: 45px;">3 ★</span>
                  <div class="progress flex-grow-1" style="height: 8px;">
                    <div class="progress-bar bg-warning" role="progressbar" style="width: {{ $pct3 }}%"></div>
                  </div>
                  <span class="small text-muted" style="width: 40px;">{{ $n3 }}</span>
                </div>
              <div class="d-flex align-items-center gap-3 mb-2">
                  <span class="small fw-medium" style="width: 45px;">2 ★</span>
                  <div class="progress flex-grow-1" style="height: 8px;">
                    <div class="progress-bar bg-warning" role="progressbar" style="width: {{ $pct2 }}%"></div>
                  </div>
                  <span class="small text-muted" style="width: 40px;">{{ $n2 }}</span>
                </div>
              <div class="d-flex align-items-center gap-3 mb-2">
                  <span class="small fw-medium" style="width: 45px;">1 ★</span>
                  <div class="progress flex-grow-1" style="height: 8px;">
                    <div class="progress-bar bg-warning" role="progressbar" style="width: {{ $pct1 }}%"></div>
                  </div>
                  <span class="small text-muted" style="width: 40px;">{{ $n1 }}</span>
                </div>
            </div>
          </div>
        </div>

        <!-- Reviews List -->
        @forelse($reviews ?? [] as $r)
          <div class="card border-0 shadow-sm rounded-3 mb-3 p-4 review-card">
            <div class="d-flex gap-3">
              <img src="{{ $r->customer->avatarUrl() }}" class="rounded-circle flex-shrink-0" width="50" height="50" alt="C" style="object-fit: cover;">
              <div class="flex-grow-1">
                <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
                  <div>
                    <div class="fw-bold">{{ $r->customer->name }}</div>
                    <div class="small text-muted">{{ $r->created_at->diffForHumans() }}</div>
                  </div>
                  <div class="text-warning">
                    @for($i = 1; $i <= 5; $i++)
                      <i class="fas fa-star {{ $i <= $r->rating ? '' : 'text-muted opacity-25' }}"></i>
                    @endfor
                  </div>
                </div>
                @if($r->product)
                  <span class="badge bg-light text-dark border"><i class="fas fa-box me-1"></i>Product: {{ $r->product->name }}</span>
                @else
                  <span class="badge bg-light text-dark border"><i class="fas fa-store me-1"></i>Stall review</span>
                @endif
                @if($r->comment)
                  <p class="mt-2 mb-1">{{ $r->comment }}</p>
                @endif
                @if($r->order)
                  <div class="small text-muted">Order {{ $r->order->code() }} &bull; {{ $r->order->itemsSummary() }}</div>
                @endif

                @if($r->hasReply())
                  <div class="mt-3 p-3 bg-light rounded-3">
                    <div class="small fw-bold mb-1"><i class="fas fa-reply text-success me-1"></i>Your reply
                      <span class="text-muted fw-normal">{{ $r->replied_at?->diffForHumans() }}</span>
                    </div>
                    <div class="small mb-0">{{ $r->farmer_reply }}</div>
                  </div>
                  <button class="btn btn-sm btn-outline-secondary mt-2" type="button" data-bs-toggle="collapse" data-bs-target="#reply-{{ $r->id }}">
                    <i class="fas fa-pen me-1"></i>Edit reply
                  </button>
                @else
                  <button class="btn btn-sm btn-success mt-3" type="button" data-bs-toggle="collapse" data-bs-target="#reply-{{ $r->id }}">
                    <i class="fas fa-reply me-1"></i>Reply to this customer
                  </button>
                @endif

                <div class="collapse mt-3 {{ $r->hasReply() ? '' : '' }}" id="reply-{{ $r->id }}">
                  <form action="/farmer-reviews/{{ $r->id }}/reply" method="POST" class="border rounded-3 p-3 bg-white">
                    @csrf
                    <label class="form-label small fw-medium" for="reply-text-{{ $r->id }}">Your reply to {{ $r->customer->name }}</label>
                    <textarea class="form-control mb-2" id="reply-text-{{ $r->id }}" name="farmer_reply" rows="2" required
                              placeholder="Thanks for the feedback — e.g. the next harvest is on Saturday.">{{ $r->farmer_reply }}</textarea>
                    <button type="submit" class="btn btn-success btn-sm"><i class="fas fa-paper-plane me-1"></i>Send Reply</button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        @empty
          <div class="card border-0 shadow-sm rounded-3 mb-3 p-5 text-center text-muted">
            <i class="fas fa-star fa-2x mb-3 d-block"></i>
            No reviews yet. Reviews from completed orders will appear here.
          </div>
        @endforelse

        <!-- Insights Box -->
        <div class="card border-0 shadow-sm rounded-3 p-4 insights-box">
          <h6 class="fw-bold mb-3"><i class="fas fa-lightbulb me-2 text-warning"></i>Insights</h6>
          <div class="row g-3 text-center">
            <div class="col-md-6">
              <div class="p-3 bg-light rounded-3">
                <div class="fw-bold fs-5">{{ $total }}</div>
                <small class="text-muted">Total Reviews</small>
              </div>
            </div>
            <div class="col-md-6">
              <div class="p-3 bg-light rounded-3">
                <div class="fw-bold fs-5">{{ $posPct }}%</div>
                <small class="text-muted">Positive (4★ &amp; 5★)</small>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  </div>
@endsection

@push('scripts')
<script>
    document.addEventListener('DOMContentLoaded', () => {
      const sidebar = document.getElementById('sidebar');
      const sidebarToggle = document.getElementById('sidebarToggle');
      const sidebarClose = document.getElementById('sidebarClose');
      if (sidebarToggle) sidebarToggle.addEventListener('click', () => sidebar.classList.add('show'));
      if (sidebarClose) sidebarClose.addEventListener('click', () => sidebar.classList.remove('show'));
      document.querySelectorAll('.js-stars').forEach(function (el) {
        var r = Math.round(parseFloat(el.getAttribute('data-rating')) || 0), out = '';
        for (var i = 1; i <= 5; i++) out += '<i class="fas fa-star ' + (i <= r ? 'text-warning' : 'text-muted opacity-25') + '"></i>';
        el.innerHTML = out;
      });
    });
  </script>
@endpush
