@extends('layouts.app')

@section('title', 'MarketLink - Farmer Login')

@section('content')
<div class="split-layout">
    <div class="split-left">
      <div class="mb-auto">
        <h2 class="fw-bold"><i class="fas fa-seedling"></i> MarketLink</h2>
        <span class="badge bg-light text-success mb-3 fs-6">Farmer Portal</span>
      </div>
      <div>
        <h1 class="display-5 fw-bold mb-3">Manage your stall, products, and orders</h1>
        <p class="lead mb-4">Join hundreds of local farmers connecting directly with customers.</p>
        <ul class="feature-list">
          <li><i class="fas fa-check-circle"></i> Reach more local customers</li>
          <li><i class="fas fa-check-circle"></i> Manage inventory easily</li>
          <li><i class="fas fa-check-circle"></i> Streamline your pickup orders</li>
          <li><i class="fas fa-check-circle"></i> Track sales and grow your business</li>
        </ul>
      </div>
      <div class="mt-auto pt-5">
        <p class="mb-0 text-white-50">&copy; 2026 MarketLink. All rights reserved.</p>
      </div>
    </div>
    
    <div class="split-right">
      <div class="auth-form-container">
        <div class="text-center mb-4 d-md-none">
          <h2 class="fw-bold text-success"><i class="fas fa-seedling"></i> MarketLink</h2>
          <span class="badge bg-success mb-3">Farmer Portal</span>
        </div>
        
        <h3 class="fw-bold mb-1">Farmer Login</h3>
        <p class="text-muted mb-4">Sign in to manage your stall, products and pickup orders.</p>
        
        <form action="/farmer-login" method="POST">
          @csrf
          <div class="mb-3">
            <label for="email" class="form-label">Email Address</label>
            <input type="email" name="email" value="{{ old('email') }}" class="form-control @error('email') is-invalid @enderror" id="email" placeholder="farmer@example.com" required>
            @error('email')
              <div class="text-danger small mt-1">{{ $message }}</div>
            @enderror
          </div>
          <div class="mb-3">
            <div class="d-flex justify-content-between">
              <label for="password" class="form-label">Password</label>
            </div>
            <input type="password" name="password" class="form-control @error('password') is-invalid @enderror" id="password" placeholder="••••••••" required>
            @error('password')
              <div class="text-danger small mt-1">{{ $message }}</div>
            @enderror
          </div>
          <div class="mb-4 form-check">
            <input type="checkbox" name="remember" value="1" class="form-check-input" id="rememberMe" {{ old('remember') ? 'checked' : '' }}>
            <label class="form-check-label text-muted" for="rememberMe">Remember me for 30 days</label>
          </div>
          <button type="submit" class="btn btn-farmer w-100 py-2 mb-3 fw-semibold">Login to Farmer Dashboard</button>
          
          <p class="text-center text-muted mb-0">
            Don't have a farmer account? <a href="/farmer-register" class="text-success text-decoration-none fw-semibold">Register as Farmer</a>
          </p>
          <p class="text-center text-muted mt-3 mb-0 border-top pt-3 small">
            <a href="/login" class="text-secondary text-decoration-none"><i class="fas fa-user me-1"></i>Client login</a>
          </p>
        </form>
      </div>
    </div>
  </div>
@endsection
