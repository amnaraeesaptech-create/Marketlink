@extends('layouts.dashboard')

@section('title', 'MarketLink - Farmer Dashboard')

@section('content')
<div class="dashboard-layout">
  <!-- Sidebar -->
  <aside class="ml-sidebar ml-sidebar-farmer" id="sidebar">
    <div class="ml-sidebar-header">
      <a href="/" class="ml-sidebar-brand"><i class="fas fa-seedling"></i> MarketLink</a>
      <button class="ml-sidebar-close d-lg-none" id="sidebarClose"><i class="fas fa-times"></i></button>
    </div>
    <div class="ml-sidebar-user">
      <img src="{{ $user->avatarUrl() }}" alt="Farmer" class="ml-sidebar-avatar">
      <div>
        <div class="ml-sidebar-username">{{ $user->displayName() }}</div>
        <div class="ml-sidebar-role">Farmer</div>
      </div>
    </div>
    <nav class="ml-sidebar-nav">
      <a href="/farmer-dashboard" class="ml-sidebar-link active"><i class="fas fa-chart-pie"></i> Dashboard</a>
      <a href="/farmer-profile" class="ml-sidebar-link"><i class="fas fa-user-edit"></i> My Profile</a>
      <a href="/farmer-products" class="ml-sidebar-link"><i class="fas fa-box"></i> Products</a>
      <a href="/farmer-add-product" class="ml-sidebar-link"><i class="fas fa-plus-circle"></i> Add Product</a>
      <a href="/farmer-products" class="ml-sidebar-link"><i class="fas fa-warehouse"></i> Inventory</a>
      <a href="/farmer-orders" class="ml-sidebar-link"><i class="fas fa-shopping-bag"></i> Orders</a>
      <a href="/farmer-reviews" class="ml-sidebar-link"><i class="fas fa-star"></i> Reviews</a>
      <a href="/farmer-stock-template" class="ml-sidebar-link"><i class="fas fa-layer-group"></i> Weekly Stock</a>
      <a href="/notifications" class="ml-sidebar-link"><i class="fas fa-bell"></i> Notifications</a>
      <hr class="ml-sidebar-divider">
      <form action="/logout" method="POST">
        @csrf
        <button type="submit" class="ml-sidebar-link ml-sidebar-logout w-100 border-0 bg-transparent text-start"><i class="fas fa-sign-out-alt"></i> Logout</button>
      </form>
    </nav>
  </aside>

  <!-- Main Content -->
  <div class="dashboard-main">
    <div class="dashboard-topbar">
      <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
      <h1 class="ml-topbar-title">Dashboard</h1>
      <div class="d-flex align-items-center gap-3">
        <a href="/farmer-profile" class="btn btn-light d-none d-sm-inline-flex"><i class="fas fa-store me-1"></i> My Stall</a>
        <a href="/farmer-add-product" class="btn btn-success"><i class="fas fa-plus"></i> <span class="d-none d-sm-inline">Add Product</span></a>
      </div>
    </div>

    <div class="dashboard-content">
      <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap gap-2">
        <div>
          <h2 class="h4 mb-1 fw-bold">{{ $user->displayName() }}</h2>
          <p class="text-muted mb-0 small">
            {{ $marketNames ? implode(' • ', $marketNames) : 'No market linked yet — add one in My Profile' }}
          </p>
        </div>
        <span class="text-muted text-sm">
          @if($avgRating) Rating {{ number_format($avgRating, 1) }}/5 ({{ $reviewCount }} review{{ $reviewCount === 1 ? '' : 's' }})
          @else No reviews yet @endif
        </span>
      </div>

      <!-- Stat Cards (live) -->
      <div class="row g-4 mb-4">
        <div class="col-12 col-sm-6 col-xl-3">
          <div class="stat-card">
            <div class="stat-icon bg-primary bg-opacity-10 text-primary"><i class="fas fa-shopping-basket"></i></div>
            <div class="stat-title">Total Orders</div>
            <div class="stat-value">{{ $totalOrders }}</div>
            <small class="text-muted">{{ $monthOrders }} this month &bull; {{ $customersServed }} customer{{ $customersServed === 1 ? '' : 's' }}</small>
          </div>
        </div>
        <div class="col-12 col-sm-6 col-xl-3">
          <div class="stat-card">
            <div class="stat-icon bg-warning bg-opacity-10 text-warning"><i class="fas fa-clock"></i></div>
            <div class="stat-title">Pending Orders</div>
            <div class="stat-value">{{ $pendingOrders }}</div>
            <small class="text-muted">{{ $confirmedOrders }} accepted &amp; awaiting prep</small>
          </div>
        </div>
        <div class="col-12 col-sm-6 col-xl-3">
          <div class="stat-card">
            <div class="stat-icon bg-info bg-opacity-10 text-info"><i class="fas fa-box-open"></i></div>
            <div class="stat-title">Ready for Pickup</div>
            <div class="stat-value">{{ $readyOrders }}</div>
            <small class="text-muted">{{ $completedOrders }} completed so far</small>
          </div>
        </div>
        <div class="col-12 col-sm-6 col-xl-3">
          <div class="stat-card">
            <div class="stat-icon bg-success bg-opacity-10 text-success"><i class="fas fa-wallet"></i></div>
            <div class="stat-title">Revenue (completed orders)</div>
            <div class="stat-value">PKR {{ $revenueFmt }}</div>
            <small class="text-muted">{{ $activeProducts }} of {{ $productsCount }} products live</small>
          </div>
        </div>
      </div>

      <div class="row g-4 mb-4">
        <!-- Main Area (Chart & Orders) -->
        <div class="col-lg-8">
          <!-- Weekly order value, computed from this farmer's orders -->
          <div class="chart-container">
            <div class="d-flex justify-content-between align-items-center mb-4">
              <h3 class="card-header-title">Order Value — Last 7 Days (PKR)</h3>
              <span class="text-muted small">
                {{ \Illuminate\Support\Carbon::parse($weekly[0]['date'])->format('M j') }} – {{ \Illuminate\Support\Carbon::parse(end($weekly)['date'])->format('M j') }}
              </span>
            </div>
            <div class="css-chart">
              @foreach($weekly as $day)
                <div class="css-bar-container">
                  <div class="css-bar" style="height: {{ max(2, round($day['value'] / $weeklyMax * 100)) }}%;">
                    <div class="css-bar-tooltip">{{ number_format($day['value'], 0) }}</div>
                  </div>
                  <div class="css-bar-label">{{ $day['label'] }}</div>
                </div>
              @endforeach
            </div>
          </div>

          <!-- Recent Orders (real rows + working status buttons) -->
          <div class="card border-0 shadow-sm rounded-3">
            <div class="card-header bg-white border-bottom p-3 d-flex justify-content-between align-items-center">
              <h3 class="card-header-title">Recent Orders</h3>
              <a href="/farmer-orders" class="btn btn-sm btn-outline-success">View All</a>
            </div>
            <div class="table-responsive">
              <table class="table table-hover mb-0">
                <thead class="table-light">
                  <tr>
                    <th>Order ID</th>
                    <th>Customer</th>
                    <th>Products</th>
                    <th>Pickup</th>
                    <th>Status</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  @forelse($recentOrders as $order)
                    <tr>
                      <td><span class="fw-medium">{{ $order->code() }}</span></td>
                      <td>{{ $order->customer?->name ?? '—' }}</td>
                      <td class="text-truncate" style="max-width: 200px;">{{ $order->itemsSummary() ?: '—' }}</td>
                      <td>
                        {{ $order->pickup_date?->format('M d') }}
                        @if($order->pickup_slot)<br><small class="text-muted">{{ $order->pickup_slot }}</small>@endif
                      </td>
                      <td><span class="badge bg-{{ $order->statusBadge() }}">{{ $order->statusLabel() }}</span></td>
                      <td>
                        @if(in_array($order->status, [\App\Models\Order::ST_PENDING, \App\Models\Order::ST_CONFIRMED], true))
                          <form action="/farmer-orders/{{ $order->id }}/status" method="POST" class="d-inline">
                            @csrf
                            <input type="hidden" name="status" value="{{ $order->status === \App\Models\Order::ST_PENDING ? \App\Models\Order::ST_CONFIRMED : \App\Models\Order::ST_READY }}">
                            <button class="btn btn-sm btn-success" title="{{ $order->status === \App\Models\Order::ST_PENDING ? 'Confirm order' : 'Mark ready' }}">
                              <i class="fas fa-check me-1"></i>{{ $order->status === \App\Models\Order::ST_PENDING ? 'Confirm' : 'Ready' }}
                            </button>
                          </form>
                        @elseif($order->status === \App\Models\Order::ST_READY)
                          <form action="/farmer-orders/{{ $order->id }}/status" method="POST" class="d-inline">
                            @csrf
                            <input type="hidden" name="status" value="{{ \App\Models\Order::ST_COMPLETED }}">
                            <button class="btn btn-sm btn-outline-success" title="Mark collected"><i class="fas fa-flag-checkered me-1"></i>Collected</button>
                          </form>
                        @endif
                        <a href="/order-details?id={{ $order->id }}" class="btn btn-sm btn-light border" title="View"><i class="fas fa-eye"></i></a>
                      </td>
                    </tr>
                  @empty
                    <tr><td colspan="6" class="text-center text-muted py-4">No orders yet. New pre-orders from clients will appear here.</td></tr>
                  @endforelse
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <!-- Right Sidebar -->
        <div class="col-lg-4">

          <!-- Quick Actions -->
          <div class="card border-0 shadow-sm rounded-3 mb-4">
            <div class="card-header bg-white border-bottom p-3">
              <h3 class="card-header-title">Quick Actions</h3>
            </div>
            <div class="card-body p-0">
              <div class="list-group list-group-flush rounded-bottom">
                <a href="/farmer-add-product" class="list-group-item list-group-item-action d-flex align-items-center py-3">
                  <div class="bg-success bg-opacity-10 text-success rounded-circle p-2 me-3"><i class="fas fa-plus"></i></div>
                  <div>
                    <h6 class="mb-0 fw-semibold">Add New Product</h6>
                    <small class="text-muted">List a new item for sale</small>
                  </div>
                  <i class="fas fa-chevron-right ms-auto text-muted small"></i>
                </a>
                <a href="/farmer-orders" class="list-group-item list-group-item-action d-flex align-items-center py-3">
                  <div class="bg-primary bg-opacity-10 text-primary rounded-circle p-2 me-3"><i class="fas fa-clipboard-list"></i></div>
                  <div>
                    <h6 class="mb-0 fw-semibold">Manage Orders</h6>
                    <small class="text-muted">{{ $pendingOrders }} pending right now</small>
                  </div>
                  <i class="fas fa-chevron-right ms-auto text-muted small"></i>
                </a>
                <a href="/farmer-products" class="list-group-item list-group-item-action d-flex align-items-center py-3">
                  <div class="bg-warning bg-opacity-10 text-warning rounded-circle p-2 me-3"><i class="fas fa-boxes"></i></div>
                  <div>
                    <h6 class="mb-0 fw-semibold">Update Inventory</h6>
                    <small class="text-muted">Adjust stock levels and prices</small>
                  </div>
                  <i class="fas fa-chevron-right ms-auto text-muted small"></i>
                </a>
              </div>
            </div>
          </div>

          <!-- Stock Alerts (real low/out of stock rows) -->
          <div class="card border-0 shadow-sm rounded-3 mb-4">
            <div class="card-header bg-white border-bottom p-3 d-flex justify-content-between align-items-center">
              <h3 class="card-header-title">Stock Alerts</h3>
              <span class="badge bg-danger rounded-pill">{{ $lowStock->count() + $outOfStock->count() }}</span>
            </div>
            <div class="card-body p-0">
              <ul class="list-group list-group-flush rounded-bottom">
                @foreach($lowStock as $p)
                  <li class="list-group-item d-flex justify-content-between align-items-center py-3">
                    <div class="d-flex align-items-center gap-3">
                      <img src="{{ $p->imageUrl() }}" class="product-img-sm" alt="{{ $p->name }}">
                      <div>
                        <h6 class="mb-0">{{ $p->name }}</h6>
                        <small class="text-muted">Only {{ $p->stock }} {{ $p->unit }} left</small>
                      </div>
                    </div>
                    <span class="badge bg-warning text-dark">Low Stock</span>
                  </li>
                @endforeach
                @foreach($outOfStock as $p)
                  <li class="list-group-item d-flex justify-content-between align-items-center py-3">
                    <div class="d-flex align-items-center gap-3">
                      <img src="{{ $p->imageUrl() }}" class="product-img-sm" alt="{{ $p->name }}">
                      <div>
                        <h6 class="mb-0">{{ $p->name }}</h6>
                        <small class="text-muted">{{ $p->stock }} {{ $p->unit }} left &bull; {{ $p->is_available ? 'hidden' : 'unavailable' }}</small>
                      </div>
                    </div>
                    <span class="badge bg-danger">Out of Stock</span>
                  </li>
                @endforeach
                @if($lowStock->isEmpty() && $outOfStock->isEmpty())
                  <li class="list-group-item py-3 text-muted small">All products are well stocked.</li>
                @endif
                <li class="list-group-item py-2 text-center bg-light">
                  <a href="/farmer-products" class="text-decoration-none text-success small fw-semibold">Manage Inventory</a>
                </li>
              </ul>
            </div>
          </div>

          <!-- Top products, aggregated from real order lines -->
          <div class="card border-0 shadow-sm rounded-3">
            <div class="card-header bg-white border-bottom p-3">
              <h3 class="card-header-title">Top Products (by units sold)</h3>
            </div>
            <div class="card-body p-0">
              <ul class="list-group list-group-flush rounded-bottom">
                @forelse($topProducts as $tp)
                  <li class="list-group-item d-flex justify-content-between align-items-center py-3">
                    <div class="d-flex align-items-center gap-3">
                      <div class="fw-bold text-muted">{{ $loop->iteration }}</div>
                      <div>
                        <h6 class="mb-0">{{ $tp->name }}</h6>
                        <small class="text-success">PKR {{ number_format((float) $tp->money, 0) }} total</small>
                      </div>
                    </div>
                    <div class="text-end">
                      <span class="fw-bold d-block">{{ (int) $tp->qty_sold }}</span>
                      <small class="text-muted">sold</small>
                    </div>
                  </li>
                @empty
                  <li class="list-group-item py-3 text-muted small">No sales recorded yet.</li>
                @endforelse
              </ul>
            </div>
          </div>

        </div>
      </div>

    </div>
  </div>
</div>
@endsection

@push('scripts')
<script>
  document.addEventListener('DOMContentLoaded', () => {
    const sidebar = document.getElementById('sidebar');
    const sidebarToggle = document.getElementById('sidebarToggle');
    const sidebarClose = document.getElementById('sidebarClose');

    sidebarToggle.addEventListener('click', () => sidebar.classList.add('show'));
    sidebarClose.addEventListener('click', () => sidebar.classList.remove('show'));
  });
</script>
@endpush
