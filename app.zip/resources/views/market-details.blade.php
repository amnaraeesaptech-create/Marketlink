@extends('layouts.app')

@section('title', $market->name . ' — MarketLink')

@section('content')
<!-- Market Hero -->
    <section class="market-hero" style="background-image: url('{{ $market->imageUrl() }}'); background-size: cover; background-position: center;">
        <div class="market-hero-overlay text-white">
            <div class="container">
                <div class="d-flex flex-wrap justify-content-between align-items-end">
                    <div>
                        @if(in_array(now()->format('l'), $market->days ?? [], true))
                            <div class="badge bg-success mb-2">Open Today</div>
                        @else
                            <div class="badge bg-secondary mb-2">{{ $market->daysLabel() }}</div>
                        @endif
                        <h1 class="display-4 fw-bold mb-2">{{ $market->name }}</h1>
                        <p class="fs-5 mb-0">
                            <i class="fa-solid fa-location-dot me-2"></i>{{ $market->address ?: 'Address not set' }}@if($market->city), {{ $market->city }}@endif
                            &nbsp;&bull;&nbsp; <i class="fa-regular fa-clock me-2"></i>{{ $market->hoursLabel() }}
                        </p>
                    </div>
                    <div class="text-end mt-3 mt-md-0">
                        <div class="bg-white text-dark rounded px-3 py-2 d-inline-block">
                            <span class="fw-bold">{{ $market->farmers_count }}</span> registered stall{{ $market->farmers_count === 1 ? '' : 's' }}<br>
                            <small class="text-muted">{{ $products->count() }} product{{ $products->count() === 1 ? '' : 's' }} available</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Breadcrumb -->
    <div class="bg-light py-2 mb-4 border-bottom">
        <div class="container">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="/" class="text-success text-decoration-none">Home</a></li>
                    <li class="breadcrumb-item"><a href="/markets" class="text-success text-decoration-none">Markets</a></li>
                    <li class="breadcrumb-item active" aria-current="page">{{ $market->name }}</li>
                </ol>
            </nav>
        </div>
    </div>

    <!-- Main Content -->
    <div class="container my-5">
        <div class="row g-5">
            <!-- Left Column (Tabs Content) -->
            <div class="col-lg-8">
                <!-- Tabs Nav -->
                <ul class="nav nav-tabs mb-4 border-bottom-0 shadow-sm rounded-top" id="marketTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="overview-tab" data-bs-toggle="tab" data-bs-target="#overview" type="button" role="tab">Overview</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="farmers-tab" data-bs-toggle="tab" data-bs-target="#farmers" type="button" role="tab">Farmers ({{ $farmers->count() }})</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="products-tab" data-bs-toggle="tab" data-bs-target="#products" type="button" role="tab">Products ({{ $products->count() }})</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="location-tab" data-bs-toggle="tab" data-bs-target="#location" type="button" role="tab">Location</button>
                    </li>
                </ul>

                <!-- Tabs Content -->
                <div class="tab-content" id="marketTabsContent">

                    <!-- Overview Tab -->
                    <div class="tab-pane fade show active" id="overview" role="tabpanel">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h3 class="fw-bold mb-0">About This Market</h3>
                            <a href="/products" class="btn btn-success"><i class="fa-solid fa-basket-shopping me-2"></i>Shop Products</a>
                        </div>
                        <p class="lead text-muted mb-4">
                            {{ $market->description ?: 'This market has no description yet — an administrator can add one from the admin panel.' }}
                        </p>

                        <div class="info-grid mb-5">
                            <div class="info-item">
                                <i class="fa-solid fa-map-location-dot"></i>
                                <h5 class="fw-bold">Address</h5>
                                <p class="mb-0 text-muted">{{ $market->address ?: 'Not set' }}<br>{{ $market->city ?: '—' }}</p>
                            </div>
                            <div class="info-item">
                                <i class="fa-regular fa-clock"></i>
                                <h5 class="fw-bold">Hours</h5>
                                <p class="mb-0 text-muted">{{ $market->daysLabel() }}<br>{{ $market->hoursLabel() }}</p>
                            </div>
                            <div class="info-item">
                                <i class="fa-solid fa-tractor"></i>
                                <h5 class="fw-bold">Stalls</h5>
                                <p class="mb-0 text-muted">{{ $market->farmers_count }} farmer{{ $market->farmers_count === 1 ? '' : 's' }}<br>{{ $products->count() }} live product{{ $products->count() === 1 ? '' : 's' }}</p>
                            </div>
                            @if($market->latitude && $market->longitude)
                            <div class="info-item">
                                <i class="fa-solid fa-diamond-turn-right"></i>
                                <h5 class="fw-bold">Directions</h5>
                                <p class="mb-0 text-muted">
                                    <a href="https://www.openstreetmap.org/directions?to={{ (float) $market->latitude }}%2C{{ (float) $market->longitude }}"
                                       target="_blank" rel="noopener" class="text-success text-decoration-none">Navigate with OpenStreetMap &rarr;</a><br>
                                    {{ number_format((float) $market->latitude, 4) }}, {{ number_format((float) $market->longitude, 4) }}
                                </p>
                            </div>
                            @endif
                            <div class="info-item">
                                <i class="fa-solid fa-clipboard-list"></i>
                                <h5 class="fw-bold">Pre-Orders</h5>
                                <p class="mb-0 text-muted">{{ $ordersCount }} order{{ $ordersCount === 1 ? '' : 's' }} with this pickup market</p>
                            </div>
                        </div>

                        <h4 class="fw-bold mb-3">Upcoming Pickups Here</h4>
                        @if($upcoming->isEmpty())
                            <p class="text-muted">No upcoming pickups scheduled at this market.</p>
                        @else
                            <ul class="list-group mb-4">
                                @foreach($upcoming as $order)
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        <span>{{ $order->code() }} &bull; {{ $order->farmer?->displayName() ?? '—' }}</span>
                                        <span class="text-muted small">{{ $order->pickup_date?->format('M d, Y') }} {{ $order->pickup_slot }}</span>
                                    </li>
                                @endforeach
                            </ul>
                        @endif
                    </div>

                    <!-- Farmers Tab -->
                    <div class="tab-pane fade" id="farmers" role="tabpanel">
                        <h3 class="fw-bold mb-4">Meet the Farmers</h3>
                        <div class="row g-3">
                            @forelse($farmers as $stall)
                                <div class="col-md-6">
                                    <div class="card border-0 shadow-sm h-100">
                                        <div class="card-body d-flex align-items-center">
                                            <img src="{{ $stall->avatarUrl() }}" class="rounded-circle me-3" width="56" height="56" alt="{{ $stall->displayName() }}">
                                            <div>
                                                <h6 class="mb-1 fw-bold">
                                                    <a href="/farmer-profile?id={{ $stall->id }}" class="text-dark text-decoration-none">{{ $stall->displayName() }}</a>
                                                </h6>
                                                <small class="text-muted d-block">{{ $stall->products_count }} product{{ $stall->products_count === 1 ? '' : 's' }}
                                                    @if($stall->averageRating()) &bull; {{ number_format($stall->averageRating(), 1) }}/5 @endif
                                                </small>
                                                <small class="text-muted">{{ $stall->phone }}</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @empty
                                <div class="col-12 text-muted">No stalls are linked to this market yet.</div>
                            @endforelse
                        </div>
                    </div>

                    <!-- Products Tab -->
                    <div class="tab-pane fade" id="products" role="tabpanel">
                        <h3 class="fw-bold mb-4">Products at This Market</h3>
                        <div class="row g-3">
                            @forelse($products as $product)
                                <div class="col-md-6 col-lg-4">
                                    <div class="card border-0 shadow-sm h-100">
                                        <img src="{{ $product->imageUrl() }}" class="card-img-top" style="height:150px;object-fit:cover" alt="{{ $product->name }}">
                                        <div class="card-body">
                                            <h6 class="fw-bold mb-1">
                                                <a href="/product-details?id={{ $product->id }}" class="text-dark text-decoration-none">{{ $product->name }}</a>
                                            </h6>
                                            <p class="text-muted small mb-1">{{ $product->farmer?->displayName() }}</p>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <span class="text-success fw-bold">PKR {{ number_format((float) $product->price, 0) }}/{{ $product->unit }}</span>
                                                <span class="badge bg-light text-dark">{{ $product->stock }} left</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            @empty
                                <div class="col-12 text-muted">No products listed by this market's stalls right now.</div>
                            @endforelse
                        </div>
                    </div>

                    <!-- Location Tab -->
                    <div class="tab-pane fade" id="location" role="tabpanel">
                        <h3 class="fw-bold mb-4">Location</h3>
                        <div class="card border-0 shadow-sm">
                            <div class="card-body">
                                <p class="mb-2"><i class="fa-solid fa-location-dot text-success me-2"></i>{{ $market->address ?: 'Address not set' }}@if($market->city), {{ $market->city }}@endif</p>
                                <p class="mb-3"><i class="fa-regular fa-clock text-success me-2"></i>{{ $market->daysLabel() }} &bull; {{ $market->hoursLabel() }}</p>
                                @if($market->latitude && $market->longitude)
                                    <div class="rounded-3 overflow-hidden border mb-3" style="height:300px;">
                                        <iframe title="Map of {{ $market->name }}" width="100%" height="300" style="border:0;display:block" loading="lazy"
                                                referrerpolicy="no-referrer-when-downgrade"
                                                src="https://www.openstreetmap.org/export/embed.html?bbox={{ (float) $market->longitude - 0.012 }}%2C{{ (float) $market->latitude - 0.012 }}%2C{{ (float) $market->longitude + 0.012 }}%2C{{ (float) $market->latitude + 0.012 }}&amp;layer=mapnik&amp;marker={{ (float) $market->latitude }}%2C{{ (float) $market->longitude }}"></iframe>
                                    </div>
                                    <p class="text-muted small">Pin: {{ number_format((float) $market->latitude, 5) }}, {{ number_format((float) $market->longitude, 5) }}</p>
                                @else
                                    <p class="text-muted small">No map coordinates saved for this market yet — an administrator can add latitude/longitude from the admin panel.</p>
                                @endif
                                <div class="d-flex flex-wrap gap-2">
                                    @if($market->latitude && $market->longitude)
                                      <a href="https://www.openstreetmap.org/directions?to={{ (float) $market->latitude }}%2C{{ (float) $market->longitude }}" target="_blank" rel="noopener" class="btn btn-success">
                                          <i class="fa-solid fa-diamond-turn-right me-2"></i>Directions to this market
                                      </a>
                                    @endif
                                    @if($market->google_maps_url)
                                        <a href="{{ $market->google_maps_url }}" target="_blank" rel="noopener" class="btn btn-outline-success">
                                            <i class="fa-solid fa-map-location-dot me-2"></i>Open in Google Maps
                                        </a>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right Column (Sidebar) -->
            <div class="col-lg-4">
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-body">
                        <h5 class="fw-bold mb-3">Quick Facts</h5>
                        <ul class="list-unstyled mb-0 text-muted">
                            <li class="mb-2"><i class="fa-solid fa-users text-success me-2"></i>{{ $market->farmers_count }} stall{{ $market->farmers_count === 1 ? '' : 's' }} registered</li>
                            <li class="mb-2"><i class="fa-solid fa-box text-success me-2"></i>{{ $products->count() }} product{{ $products->count() === 1 ? '' : 's' }} available</li>
                            <li class="mb-2"><i class="fa-solid fa-calendar-days text-success me-2"></i>{{ $market->daysLabel() }}</li>
                            <li><i class="fa-solid fa-clock text-success me-2"></i>{{ $market->hoursLabel() }}</li>
                        </ul>
                    </div>
                </div>

                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <h5 class="fw-bold mb-3">Browse Other Markets</h5>
                        <a href="/markets" class="btn btn-outline-success w-100"><i class="fa-solid fa-arrow-left me-2"></i>All Markets</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
