@extends('layouts.app')

@section('title', 'Local Markets — MarketLink')

@section('content')
<!-- Page Hero -->
    <section class="hero-section">
        <div class="container">
            <h1>Discover Local Markets</h1>
            <p class="lead mb-4">Find the freshest produce and support local farmers near you.</p>
            <div class="search-wrapper">
                <div class="input-group input-group-lg">
                    <span class="input-group-text bg-white border-end-0"><i class="fa-solid fa-search text-muted"></i></span>
                    <input type="text" id="heroSearch" class="form-control border-start-0" placeholder="Search markets by name or city...">
                    <button class="btn btn-dark px-4" type="button" onclick="document.getElementById('searchInput').value = document.getElementById('heroSearch').value; document.getElementById('searchInput').dispatchEvent(new Event('input'));">Search</button>
                </div>
            </div>
        </div>
    </section>

    <!-- Main Content -->
    <div class="container my-5">
        <div class="row g-4">
            <!-- Left Sidebar (Filters) -->
            <div class="col-lg-3">
                <div class="card border-0 shadow-sm sticky-top" style="top: 100px; z-index: 10;">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h5 class="card-title mb-0 fw-bold">Filters</h5>
                            <button class="btn btn-sm btn-link text-muted text-decoration-none p-0" id="clearFiltersBtn">Clear all</button>
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label fw-semibold">Search</label>
                            <input type="text" class="form-control form-control-sm" id="searchInput" placeholder="Search by name...">
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label fw-semibold">Location</label>
                            <select class="form-select form-select-sm" id="locationFilter">
                                <option value="all">All Locations</option>
                                @foreach($markets->pluck('city')->filter()->unique()->sort() as $city)
                                    <option value="{{ $city }}">{{ $city }}</option>
                                @endforeach
                            </select>
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label fw-semibold">Operating Days</label>
                            @foreach(\App\Models\Market::DAYS as $day)
                                <div class="form-check mb-2">
                                    <input class="form-check-input day-filter" type="checkbox" value="{{ $day }}" id="day{{ substr($day, 0, 3) }}">
                                    <label class="form-check-label" for="day{{ substr($day, 0, 3) }}">{{ $day }}</label>
                                </div>
                            @endforeach
                        </div>
                        
                        <button class="btn btn-success w-100" id="applyFiltersBtn">Apply Filters</button>
                    </div>
                </div>
            </div>
            
            <!-- Right Content (Market Cards) -->
            <div class="col-lg-9">
                <div class="d-flex justify-content-between align-items-center mb-4 pb-2 border-bottom">
                    <h6 class="mb-0 text-muted" id="resultsCount">Showing {{ $markets->count() }} markets</h6>
                    <div class="d-flex align-items-center gap-2">
                        <button id="nearMeBtn" class="btn btn-sm btn-outline-success" title="Sort by distance from your location">
                            <i class="fas fa-location-arrow me-1"></i>Near Me
                        </button>
                        <span class="me-2 text-muted small">Sort by:</span>
                        <select id="marketSort" class="form-select form-select-sm border-0 bg-light" style="width: auto;">
                            <option value="nearest">Nearest</option>
                            <option value="az">A-Z</option>
                            <option value="farmers">Most Farmers</option>
                        </select>
                    </div>
                </div>
                
                <div class="row g-4" id="marketsGrid">
                    @forelse($markets as $market)
                        <div class="col-md-6 market-item"
                             data-name="{{ $market->name }}"
                             data-location="{{ $market->city }}"
                             data-days="{{ implode(',', $market->days ?? []) }}"
                             data-farmers="{{ $market->farmers_count }}"
                             data-lat="{{ $market->latitude ?? '' }}"
                             data-lng="{{ $market->longitude ?? '' }}">
                            <div class="market-card">
                                <img src="{{ $market->imageUrl() }}" alt="{{ $market->name }}">
                                <div class="market-card-body">
                                    <h3 class="market-title">
                                        {{ $market->name }}
                                        @if($market->latitude && $market->longitude)
                                        <span class="ml-dist-badge" style="display:none;"></span>
                                        @endif
                                    </h3>
                                    <div class="market-meta">
                                        <div class="mb-1"><i class="fa-solid fa-location-dot"></i> {{ $market->address ?: 'Address not set' }}@if($market->city), {{ $market->city }}@endif</div>
                                        <div class="mb-1"><i class="fa-regular fa-clock"></i> {{ $market->hoursLabel() }}</div>
                                        <div><i class="fa-solid fa-users"></i> {{ $market->farmers_count }} Farmer{{ $market->farmers_count === 1 ? '' : 's' }}</div>
                                    </div>
                                    <div class="mb-3">
                                        @foreach($market->days ?? [] as $day)
                                            <span class="chip">{{ $day }}</span>
                                        @endforeach
                                    </div>
                                    <div class="mt-auto">
                                        <a href="/market-details?id={{ $market->id }}" class="btn btn-outline-success w-100">View Market</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @empty
                        <div class="col-12 text-center text-muted py-5">
                            <i class="fa-solid fa-store fa-2x mb-3 d-block text-success"></i>
                            No markets have been added yet.
                        </div>
                    @endforelse
                </div>


            </div>
        </div>
    </div>

    <!-- Map Section — Real OSM embeds per market -->
    <section class="py-5 bg-light">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="fw-bold">Markets on the Map</h2>
                <p class="text-muted">Find a market conveniently located near you.</p>
            </div>
            @php $mappable = $markets->filter(fn($m) => $m->latitude && $m->longitude); @endphp
            @if($mappable->count())
                <div class="row g-4">
                    @foreach($mappable as $market)
                    <div class="col-md-6 col-lg-4">
                        <div class="card border-0 shadow-sm rounded-3 overflow-hidden h-100">
                            <iframe
                                title="Map of {{ $market->name }}"
                                width="100%"
                                height="190"
                                style="border:0; display:block;"
                                loading="lazy"
                                referrerpolicy="no-referrer-when-downgrade"
                                src="https://www.openstreetmap.org/export/embed.html?bbox={{ (float)$market->longitude - 0.012 }}%2C{{ (float)$market->latitude - 0.012 }}%2C{{ (float)$market->longitude + 0.012 }}%2C{{ (float)$market->latitude + 0.012 }}&amp;layer=mapnik&amp;marker={{ (float)$market->latitude }}%2C{{ (float)$market->longitude }}">
                            </iframe>
                            <div class="p-3 d-flex justify-content-between align-items-center">
                                <div>
                                    <div class="fw-bold small">{{ $market->name }}</div>
                                    <div class="text-muted small"><i class="fa-solid fa-location-dot me-1 text-success"></i>{{ $market->city ?: $market->address }}</div>
                                </div>
                                <div class="d-flex flex-column gap-1">
                                    <a href="/market-details?id={{ $market->id }}" class="btn btn-sm btn-success">View</a>
                                    <a href="https://www.openstreetmap.org/directions?to={{ (float)$market->latitude }}%2C{{ (float)$market->longitude }}"
                                       target="_blank" rel="noopener" class="btn btn-sm btn-outline-success">
                                        <i class="fa-solid fa-diamond-turn-right"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    @endforeach
                </div>
                <p class="text-center text-muted small mt-4">
                    {{ $markets->count() - $mappable->count() > 0 ? ($markets->count() - $mappable->count()) . ' market(s) have no coordinates yet — admin can add them from the admin panel.' : '' }}
                </p>
            @else
                {{-- No coordinates in DB yet — show a single country-level OSM overview --}}
                <div class="rounded-4 overflow-hidden shadow-sm border">
                    <iframe
                        title="Pakistan — MarketLink markets overview"
                        width="100%"
                        height="420"
                        style="border:0; display:block;"
                        loading="lazy"
                        referrerpolicy="no-referrer-when-downgrade"
                        src="https://www.openstreetmap.org/export/embed.html?bbox=60.8%2C23.6%2C77.8%2C37.1&amp;layer=mapnik">
                    </iframe>
                </div>
                <p class="text-center text-muted small mt-3">
                    <i class="fas fa-info-circle me-1"></i>
                    Map pins appear once an admin adds latitude/longitude to each market.
                    {{ $markets->count() }} market{{ $markets->count() === 1 ? '' : 's' }} registered.
                </p>
            @endif
        </div>
    </section>
    </section>
@endsection

@push('scripts')
<script>
(function () {
    var grid   = document.getElementById('marketsGrid');
    var sortEl = document.getElementById('marketSort');
    var nearBtn= document.getElementById('nearMeBtn');
    var geoActive = false;

    /* ---- existing filter logic (search, location, days) ---- */
    function getVisible() {
        return Array.from(document.querySelectorAll('.market-item'));
    }

    function applyFilters() {
        var search = (document.getElementById('searchInput')?.value || '').toLowerCase();
        var loc    = document.getElementById('locationFilter')?.value || 'all';
        var days   = Array.from(document.querySelectorAll('.day-filter:checked')).map(c => c.value);
        var count  = 0;
        getVisible().forEach(function (el) {
            var name    = (el.dataset.name || '').toLowerCase();
            var elLoc   = el.dataset.location || '';
            var elDays  = (el.dataset.days || '').split(',');
            var matchS  = !search || name.includes(search);
            var matchL  = loc === 'all' || elLoc === loc;
            var matchD  = !days.length || days.some(d => elDays.includes(d));
            var show    = matchS && matchL && matchD;
            el.style.display = show ? '' : 'none';
            if (show) count++;
        });
        var rc = document.getElementById('resultsCount');
        if (rc) rc.textContent = 'Showing ' + count + ' markets';
    }

    /* ---- sort ---- */
    function doSort(mode) {
        if (!grid) return;
        var items = Array.from(grid.children);
        items.sort(function (a, b) {
            if (mode === 'nearest') {
                var da = parseFloat(a.dataset.dist), db = parseFloat(b.dataset.dist);
                var ha = !isNaN(da), hb = !isNaN(db);
                if (ha && hb) return da - db;
                if (ha) return -1; if (hb) return 1; return 0;
            }
            if (mode === 'az') return (a.dataset.name || '').localeCompare(b.dataset.name || '');
            if (mode === 'farmers') return parseInt(b.dataset.farmers||0) - parseInt(a.dataset.farmers||0);
            return 0;
        });
        items.forEach(function (c) { grid.appendChild(c); });
    }

    /* ---- geo: attach badges + sort nearest ---- */
    function activateGeo(lat, lng) {
        geoActive = true;
        if (nearBtn) {
            nearBtn.classList.remove('btn-outline-success');
            nearBtn.classList.add('btn-success');
            nearBtn.innerHTML = '<i class="fas fa-location-arrow me-1"></i>Near Me';
        }
        window.MLGeo.attachDistanceBadges(lat, lng, {
            items: document.querySelectorAll('.market-item'),
            getLat: function (el) { return el.dataset.lat; },
            getLng: function (el) { return el.dataset.lng; },
            badgeClass: 'ml-dist-badge',
            insertInto: function (el, badge) {
                badge.classList.add('ms-2', 'd-inline-block');
                badge.style.display = '';
                var title = el.querySelector('.market-title');
                if (title) title.appendChild(badge);
            }
        });
        if (sortEl) sortEl.value = 'nearest';
        doSort('nearest');
    }

    /* ---- wire up Near Me button ---- */
    if (nearBtn) {
        nearBtn.addEventListener('click', function () {
            nearBtn.disabled = true;
            nearBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>Locating…';
            window.MLGeo.getLocation(
                function (lat, lng) {
                    nearBtn.disabled = false;
                    activateGeo(lat, lng);
                },
                function (code) {
                    nearBtn.disabled = false;
                    nearBtn.innerHTML = '<i class="fas fa-location-arrow me-1"></i>Near Me';
                    if (code === 1) alert('Location permission denied. Please allow location access in your browser.');
                    else alert('Could not get your location. Try again.');
                }
            );
        });
    }

    /* ---- wire sort dropdown ---- */
    if (sortEl) {
        sortEl.addEventListener('change', function () { doSort(sortEl.value); });
    }

    /* ---- wire existing filter controls ---- */
    document.getElementById('searchInput')?.addEventListener('input', applyFilters);
    document.getElementById('locationFilter')?.addEventListener('change', applyFilters);
    document.querySelectorAll('.day-filter').forEach(function (cb) {
        cb.addEventListener('change', applyFilters);
    });
    document.getElementById('applyFiltersBtn')?.addEventListener('click', applyFilters);
    document.getElementById('clearFiltersBtn')?.addEventListener('click', function (e) {
        e.preventDefault();
        var si = document.getElementById('searchInput'); if (si) si.value = '';
        var lf = document.getElementById('locationFilter'); if (lf) lf.value = 'all';
        document.querySelectorAll('.day-filter').forEach(cb => cb.checked = false);
        applyFilters();
    });

    /* Auto-activate geo on load — use cache on return visits, silently request on first visit */
    (function () {
        var cached = null;
        try { cached = JSON.parse(sessionStorage.getItem('ml_user_loc')); } catch (e) {}
        if (cached && cached.lat && cached.lng) {
            activateGeo(cached.lat, cached.lng);
        } else {
            window.MLGeo.getLocation(
                function (lat, lng) { activateGeo(lat, lng); },
                function () { /* denied or unavailable — user can click Near Me */ }
            );
        }
    })();
})();
</script>
@endpush
