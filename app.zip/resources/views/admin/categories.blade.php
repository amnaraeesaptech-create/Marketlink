@extends('layouts.dashboard')

@section('title', 'Categories — Admin')

@section('content')
<div class="ml-admin-layout">
  <aside class="ml-admin-sidebar" id="adminSidebar">
    <div class="ml-admin-sidebar-header">
      <a href="/" class="ml-admin-brand"><i class="fas fa-seedling"></i> MarketLink</a>
      <span class="ml-admin-badge">Admin</span>
    </div>
    <div class="ml-admin-sidebar-user">
      <img src="{{ auth()->user()->avatarUrl() }}" alt="{{ auth()->user()->name }}">
      <div>
        <div>{{ auth()->user()->name }}</div>
        <div>{{ auth()->user()->email }}</div>
      </div>
    </div>
    <nav class="ml-admin-nav">
      <a href="/admin-dashboard" class="ml-admin-nav-link"><i class="fas fa-th-large"></i> Dashboard</a>
      <a href="/admin-farmers" class="ml-admin-nav-link"><i class="fas fa-tractor"></i> Farmers</a>
      <a href="/admin-customers" class="ml-admin-nav-link"><i class="fas fa-users"></i> Customers</a>
      <a href="/admin-markets" class="ml-admin-nav-link"><i class="fas fa-store"></i> Markets</a>
      <a href="/admin-products" class="ml-admin-nav-link"><i class="fas fa-box"></i> Products</a>
      <a href="/admin-orders" class="ml-admin-nav-link"><i class="fas fa-shopping-bag"></i> Orders</a>
      <a href="/admin-reviews" class="ml-admin-nav-link"><i class="fas fa-star"></i> Reviews</a>
      <a href="/admin-reports" class="ml-admin-nav-link"><i class="fas fa-chart-bar"></i> Reports</a>

      <a href="/admin-categories" class="ml-admin-nav-link active"><i class="fas fa-tags"></i> Categories</a>
      <a href="/admin-announcements" class="ml-admin-nav-link"><i class="fas fa-bullhorn"></i> Announcements</a>
      <a href="/notifications" class="ml-admin-nav-link"><i class="fas fa-bell"></i> Notifications</a>
      <hr>
      <form action="/logout" method="POST">
        @csrf
        <button type="submit" class="ml-admin-nav-link ml-admin-logout w-100 border-0 bg-transparent text-start"><i class="fas fa-sign-out-alt"></i> Logout</button>
      </form>
    </nav>
  </aside>
  <div class="ml-admin-backdrop" id="adminBackdrop"></div>

  <main class="ml-admin-main">
    <div class="ml-admin-topbar">
      <div class="ml-admin-topbar-left">
        <button class="ml-admin-toggle" type="button" data-admin-menu aria-controls="adminSidebar" aria-expanded="false" aria-label="Toggle navigation"><i class="fas fa-bars"></i></button>
        <div>
          <h4 class="m-0 fw-bold">Product Categories</h4>
          <small class="text-muted">Master data: these drive product forms, storefront filters and the category chart.</small>
        </div>
      </div>
    </div>

    <div class="ml-admin-content">
      <div class="row g-4 mb-4">
        <div class="col-6 col-lg-3">
          <div class="admin-stat-card">
            <div class="admin-stat-icon icon-blue"><i class="fas fa-tags"></i></div>
            <div class="admin-stat-info"><p>Categories</p><h3>{{ $categories->count() }}</h3></div>
          </div>
        </div>
        <div class="col-6 col-lg-3">
          <div class="admin-stat-card">
            <div class="admin-stat-icon icon-green"><i class="fas fa-check-circle"></i></div>
            <div class="admin-stat-info"><p>Active</p><h3>{{ $categories->where('is_active', true)->count() }}</h3></div>
          </div>
        </div>
        <div class="col-6 col-lg-3">
          <div class="admin-stat-card">
            <div class="admin-stat-icon icon-amber"><i class="fas fa-box"></i></div>
            <div class="admin-stat-info"><p>Listed Products</p><h3>{{ \App\Models\Product::count() }}</h3></div>
          </div>
        </div>
        <div class="col-6 col-lg-3">
          <div class="admin-stat-card">
            <div class="admin-stat-icon icon-purple"><i class="fas fa-triangle-exclamation"></i></div>
            <div class="admin-stat-info"><p>Unlisted Labels</p><h3>{{ $unlisted->count() }}</h3></div>
          </div>
        </div>
      </div>

      @if($unlisted->isNotEmpty())
        <div class="alert alert-warning">
          <strong>Products using a label that is not a category:</strong>
          {{ $unlisted->implode(', ') }} —
          add them below (or edit the product) so filters and reports stay consistent.
        </div>
      @endif

      <div class="admin-card">
        <div class="admin-card-header">
          <h5>All categories</h5>
          <button class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#categoryModal" onclick="resetCategoryForm()">
            <i class="fas fa-plus"></i> Add Category
          </button>
        </div>
        <div class="table-responsive">
          <table class="table admin-table table-hover mb-0" id="adminCategoriesTable" data-filterable>
            <thead>
              <tr>
                <th>#</th><th>Category</th><th>Description</th><th>Products</th><th>Order</th><th>Status</th><th>Actions</th>
              </tr>
            </thead>
            <tbody>
              @forelse($categories as $category)
                <tr>
                  <td>{{ $loop->iteration }}</td>
                  <td><strong>{{ $category->name }}</strong></td>
                  <td class="text-muted">{{ $category->description ?: '—' }}</td>
                  <td>{{ $category->productCount() }}</td>
                  <td>{{ $category->sort_order }}</td>
                  <td>
                    <span class="badge {{ $category->is_active ? 'badge-active' : 'badge-inactive' }}">
                      {{ $category->is_active ? 'Active' : 'Hidden' }}
                    </span>
                  </td>
                  <td class="text-nowrap">
                    <button class="btn btn-sm btn-light" data-bs-toggle="modal" data-bs-target="#categoryModal"
                            data-category="{{ json_encode([
                                'id' => $category->id, 'name' => $category->name,
                                'description' => $category->description, 'sort_order' => $category->sort_order,
                                'is_active' => $category->is_active,
                            ], JSON_HEX_APOS | JSON_HEX_QUOT) }}" onclick="fillCategoryForm(this)"><i class="fas fa-pen"></i></button>
                    <form action="/admin-categories/{{ $category->id }}" method="POST" class="d-inline" onsubmit="return confirm('Remove category {{ $category->name }}?');">
                      @csrf @method('DELETE')
                      <button class="btn btn-sm btn-light text-danger" title="Remove"><i class="fas fa-trash"></i></button>
                    </form>
                  </td>
                </tr>
              @empty
                <tr data-filter-empty="1">
                  <td colspan="7" class="text-center text-muted py-4">
                    No categories yet — add the first one above; it shows up in product forms immediately.
                  </td>
                </tr>
              @endforelse
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </main>
</div>

<div class="modal fade" id="categoryModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <form action="/admin-categories" method="POST" id="categoryForm">
        @csrf
        <input type="hidden" name="_method" id="categoryMethod" value="POST">
        <div class="modal-header">
          <h5 class="modal-title" id="categoryModalTitle">Add Category</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label class="form-label" for="catName">Name *</label>
            <input type="text" class="form-control" name="name" id="catName" value="{{ old('name') }}" required placeholder="e.g. Vegetables">
            <div class="form-text">Renaming a category moves every product listed under it.</div>
          </div>
          <div class="mb-3">
            <label class="form-label" for="catDescription">Description</label>
            <input type="text" class="form-control" name="description" id="catDescription" value="{{ old('description') }}" placeholder="Short note for the admin team">
          </div>
          <div class="row g-3">
            <div class="col-6">
              <label class="form-label" for="catSort">Sort order</label>
              <input type="number" class="form-control" name="sort_order" id="catSort" min="0" max="999" value="{{ old('sort_order', 0) }}">
            </div>
            <div class="col-6 d-flex align-items-end">
              <div class="form-check">
                <input class="form-check-input" type="checkbox" name="is_active" value="1" id="catActive" checked>
                <label class="form-check-label" for="catActive">Show in forms &amp; filters</label>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-success" id="categorySubmit">Save Category</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
  function resetCategoryForm() {
    document.getElementById('categoryModalTitle').textContent = 'Add Category';
    document.getElementById('categorySubmit').textContent = 'Save Category';
    document.getElementById('categoryForm').action = '/admin-categories';
    document.getElementById('categoryMethod').value = 'POST';
    document.getElementById('catName').value = '';
    document.getElementById('catDescription').value = '';
    document.getElementById('catSort').value = 0;
    document.getElementById('catActive').checked = true;
  }
  function fillCategoryForm(btn) {
    var d = JSON.parse(btn.dataset.category);
    document.getElementById('categoryModalTitle').textContent = 'Edit ' + d.name;
    document.getElementById('categorySubmit').textContent = 'Update Category';
    document.getElementById('categoryForm').action = '/admin-categories/' + d.id;
    document.getElementById('categoryMethod').value = 'PUT';
    document.getElementById('catName').value = d.name || '';
    document.getElementById('catDescription').value = d.description || '';
    document.getElementById('catSort').value = d.sort_order || 0;
    document.getElementById('catActive').checked = !!d.is_active;
  }
</script>
@endsection
