@extends('layouts.dashboard')

@section('title', 'Admin Dashboard - MarketLink')

@section('content')
<div class="ml-admin-layout">
    <!-- Sidebar -->
    <aside class="ml-admin-sidebar" id="adminSidebar">
      <div class="ml-admin-sidebar-header">
        <a href="/" class="ml-admin-brand"><i class="fas fa-seedling"></i> MarketLink</a>
        <span class="ml-admin-badge">Admin</span>
      </div>
      <div class="ml-admin-sidebar-user">
        <img src="{{ auth()->user()->avatarUrl() }}" alt="{{ auth()->user()->name }}">
        <div>
          <div>{{ auth()->user()->name }}</div>
          <div>{{ auth()->user()->email }}</div>
        </div>
      </div>
      <nav class="ml-admin-nav">
        <a href="/admin-dashboard" class="ml-admin-nav-link active"><i class="fas fa-th-large"></i> Dashboard</a>
        <a href="/admin-farmers" class="ml-admin-nav-link"><i class="fas fa-tractor"></i> Farmers</a>
        <a href="/admin-customers" class="ml-admin-nav-link"><i class="fas fa-users"></i> Customers</a>
        <a href="/admin-markets" class="ml-admin-nav-link"><i class="fas fa-store"></i> Markets</a>
        <a href="/admin-products" class="ml-admin-nav-link"><i class="fas fa-box"></i> Products</a>
        <a href="/admin-orders" class="ml-admin-nav-link"><i class="fas fa-shopping-bag"></i> Orders</a>
        <a href="/admin-reviews" class="ml-admin-nav-link"><i class="fas fa-star"></i> Reviews</a>
        <a href="/admin-reports" class="ml-admin-nav-link"><i class="fas fa-chart-bar"></i> Reports</a>

        <a href="/admin-categories" class="ml-admin-nav-link"><i class="fas fa-tags"></i> Categories</a>
        <a href="/admin-announcements" class="ml-admin-nav-link"><i class="fas fa-bullhorn"></i> Announcements</a>
        <a href="/notifications" class="ml-admin-nav-link"><i class="fas fa-bell"></i> Notifications</a>
        <hr>
        <form action="/logout" method="POST">
          @csrf
          <button type="submit" class="ml-admin-nav-link ml-admin-logout w-100 border-0 bg-transparent text-start"><i class="fas fa-sign-out-alt"></i> Logout</button>
        </form>
      </nav>
    </aside>

    <!-- Main Content -->
    <div class="ml-admin-backdrop" id="adminBackdrop"></div>

    <main class="ml-admin-main">
      <div class="ml-admin-topbar">
        <div class="ml-admin-topbar-left">
          <button class="ml-admin-toggle" type="button" data-admin-menu aria-controls="adminSidebar" aria-expanded="false" aria-label="Toggle navigation"><i class="fas fa-bars"></i></button>
          
          <h4 class="m-0 fw-bold">Dashboard Overview</h4>
        </div>
        <div class="d-flex align-items-center gap-3">
          <span class="text-muted"><i class="far fa-calendar-alt"></i> {{ now()->format('M d, Y') }}</span>
          <a href="/admin-reports" class="btn btn-outline-success btn-sm"><i class="fas fa-chart-bar"></i> Reports</a>
        </div>
      </div>

      <div class="ml-admin-content">
        <!-- Stats Row -->
        <div class="row g-4 mb-4">
          <div class="col-md-4 col-lg">
            <div class="admin-stat-card">
              <div class="admin-stat-icon icon-green"><i class="fas fa-tractor"></i></div>
              <div class="admin-stat-info">
                <p>Total Farmers</p>
                <h3>{{ $totalFarmers }}</h3>
                <small class="text-muted">{{ $pendingFarmers }} suspended</small>
              </div>
            </div>
          </div>
          <div class="col-md-4 col-lg">
            <div class="admin-stat-card">
              <div class="admin-stat-icon icon-blue"><i class="fas fa-users"></i></div>
              <div class="admin-stat-info">
                <p>Total Customers</p>
                <h3>{{ $totalCustomers }}</h3>
                <small class="text-muted">client accounts</small>
              </div>
            </div>
          </div>
          <div class="col-md-4 col-lg">
            <div class="admin-stat-card">
              <div class="admin-stat-icon icon-amber"><i class="fas fa-store"></i></div>
              <div class="admin-stat-info">
                <p>Total Markets</p>
                <h3>{{ $totalMarkets }}</h3>
                <small class="text-muted">active market{{ $totalMarkets === 1 ? '' : 's' }}</small>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-lg">
            <div class="admin-stat-card">
              <div class="admin-stat-icon icon-purple"><i class="fas fa-shopping-bag"></i></div>
              <div class="admin-stat-info">
                <p>Total Orders</p>
                <h3>{{ $totalOrders }}</h3>
                <small class="text-muted">{{ $pendingOrders }} pending</small>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-lg">
            <div class="admin-stat-card">
              <div class="admin-stat-icon icon-gradient"><i class="fas fa-chart-line"></i></div>
              <div class="admin-stat-info">
                <p>Collected Revenue</p>
                <h3>PKR {{ $revenueFmt }}</h3>
                <small class="text-muted">Avg rating {{ $avgRating }}</small>
              </div>
            </div>
          </div>
        </div>

        <!-- Charts Row -->
        <div class="row g-4 mb-4">
          <div class="col-lg-8">
            <div class="admin-card h-100">
              <div class="admin-card-header">
                <h5>Orders — Last 14 Days</h5>
              </div>
              <div class="admin-card-body">
                <div class="simple-bar-chart">
                  @php($maxDay = max(1, $salesTrend->groupBy(fn ($o) => $o->created_at->toDateString())->map->count()->max()))
                  @for($i = 13; $i >= 0; $i--)
                    @php($day = now()->subDays($i)->toDateString())
                    @php($count = $salesTrend->filter(fn ($o) => $o->created_at->toDateString() === $day)->count())
                    <div class="bar-col">
                      <div class="bar" style="height: {{ max(3, round($count / $maxDay * 100)) }}%;" title="{{ $count }} order(s) on {{ \Illuminate\Support\Carbon::parse($day)->format('M j') }}"></div>
                      <div class="bar-label">{{ \Illuminate\Support\Carbon::parse($day)->format('j') }}</div>
                    </div>
                  @endfor
                </div></div>
                </div>
              </div>
          <div class="col-lg-4">
            <div class="admin-card h-100">
              <div class="admin-card-header">
                <h5>Products by Category</h5>
              </div>
              <div class="admin-card-body text-center">
                <div class="pie-chart"></div>
                <div class="pie-legend text-start d-inline-block mt-4">
                  @php($catCounts = \App\Models\Product::selectRaw('category, COUNT(*) as c')->groupBy('category')->pluck('c', 'category'))
                  @foreach(\App\Models\Category::names() as $i => $cat)
                    <div class="pie-legend-item"><div class="pie-color" style="background:#4CAF50"></div> {{ $cat }} ({{ $catCounts[$cat] ?? 0 }})</div>
                  @endforeach
                </div>
                </div>
              </div>
            </div>
          </div>

        <!-- Tables Row -->
        <div class="row g-4 mb-4">
          <div class="col-lg-6">
            <div class="admin-card h-100">
              <div class="admin-card-header">
                <h5>Recent Registrations</h5>
                <a href="/admin-farmers" class="btn btn-sm btn-light">View All</a>
              </div>
              <div class="table-responsive">
                <table class="table admin-table table-hover">
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Type</th>
                      <th>Date</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($recentUsers as $u)
                      <tr>
                        <td>{{ $u->name }}</td>
                        <td>
                          @if($u->isFarmer())
                            <span class="text-success"><i class="fas fa-tractor"></i> Farmer</span>
                          @elseif($u->isCustomer())
                            <span class="text-primary"><i class="fas fa-user"></i> Customer</span>
                          @else
                            <span class="text-dark"><i class="fas fa-shield-alt"></i> Admin</span>
                          @endif
                        </td>
                        <td>{{ $u->created_at?->format('M d, Y') }}</td>
                        <td>
                          <span class="badge {{ $u->is_active ? 'badge-active' : 'badge-pending' }}">{{ $u->is_active ? 'Active' : 'Suspended' }}</span>
                        </td>
                      </tr>
                    @empty
                      <tr><td colspan="4" class="text-center text-muted py-3">No registrations yet.</td></tr>
                    @endforelse
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          <div class="col-lg-6">
            <div class="admin-card h-100">
              <div class="admin-card-header">
                <h5>Recent Orders</h5>
                <a href="/admin-orders" class="btn btn-sm btn-light">View All</a>
              </div>
              <div class="table-responsive">
                <table class="table admin-table table-hover">
                  <thead>
                    <tr>
                      <th>Order ID</th>
                      <th>Customer</th>
                      <th>Total</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    @forelse($recentOrders as $order)
                      <tr>
                        <td>{{ $order->code() }}</td>
                        <td>{{ $order->customer?->name ?? '—' }}</td>
                        <td>PKR {{ number_format((float) $order->subtotal, 0) }}</td>
                        <td><span class="badge bg-{{ $order->statusBadge() }}">{{ $order->statusLabel() }}</span></td>
                      </tr>
                    @empty
                      <tr><td colspan="4" class="text-center text-muted py-3">No orders yet.</td></tr>
                    @endforelse
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

        <!-- Active Farmers -->
        <h5 class="mb-3 fw-bold">Top Performing Farmers</h5>
        <div class="row g-4">
          @forelse($topFarmers as $farmer)
            <div class="col-md-3">
              <div class="mini-farmer-card">
                <img src="{{ $farmer->avatarUrl() }}" alt="{{ $farmer->displayName() }}">
                <h6>{{ $farmer->displayName() }}</h6>
                <div class="rating">
                  <i class="fas fa-star"></i>
                  {{ $farmer->averageRating() ? number_format($farmer->averageRating(), 1) : 'New' }}
                  ({{ $farmer->reviewsReceived()->count() }})
                </div>
                <p>PKR {{ number_format($farmer->completedRevenue(), 0) }} earned &bull; {{ $farmer->products_count }} products</p>
              </div>
            </div>
          @empty
            <div class="col-12 text-muted">No farmer stalls yet.</div>
          @endforelse
        </div>

      </div>
    </main>
  </div>
@endsection
