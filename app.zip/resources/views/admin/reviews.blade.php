@extends('layouts.dashboard')

@section('title', 'Admin Reviews - MarketLink')

@section('content')
<div class="ml-admin-layout">
    <aside class="ml-admin-sidebar" id="adminSidebar">
      <div class="ml-admin-sidebar-header">
        <a href="/" class="ml-admin-brand"><i class="fas fa-seedling"></i> MarketLink</a>
        <span class="ml-admin-badge">Admin</span>
      </div>
      <div class="ml-admin-sidebar-user">
        <img src="{{ auth()->user()->avatarUrl() }}" alt="{{ auth()->user()->name }}">
        <div>
          <div>{{ auth()->user()->name }}</div>
          <div>{{ auth()->user()->email }}</div>
        </div>
      </div>
      <nav class="ml-admin-nav">
        <a href="/admin-dashboard" class="ml-admin-nav-link"><i class="fas fa-th-large"></i> Dashboard</a>
        <a href="/admin-farmers" class="ml-admin-nav-link"><i class="fas fa-tractor"></i> Farmers</a>
        <a href="/admin-customers" class="ml-admin-nav-link"><i class="fas fa-users"></i> Customers</a>
        <a href="/admin-markets" class="ml-admin-nav-link"><i class="fas fa-store"></i> Markets</a>
        <a href="/admin-products" class="ml-admin-nav-link"><i class="fas fa-box"></i> Products</a>
        <a href="/admin-orders" class="ml-admin-nav-link"><i class="fas fa-shopping-bag"></i> Orders</a>
        <a href="/admin-reviews" class="ml-admin-nav-link active"><i class="fas fa-star"></i> Reviews</a>
        <a href="/admin-reports" class="ml-admin-nav-link"><i class="fas fa-chart-bar"></i> Reports</a>

        <a href="/admin-categories" class="ml-admin-nav-link"><i class="fas fa-tags"></i> Categories</a>
        <a href="/admin-announcements" class="ml-admin-nav-link"><i class="fas fa-bullhorn"></i> Announcements</a>
        <a href="/notifications" class="ml-admin-nav-link"><i class="fas fa-bell"></i> Notifications</a>
        <hr>
        <form action="/logout" method="POST">
          @csrf
          <button type="submit" class="ml-admin-nav-link ml-admin-logout w-100 border-0 bg-transparent text-start"><i class="fas fa-sign-out-alt"></i> Logout</button>
        </form>
      </nav>
    </aside>
    <div class="ml-admin-backdrop" id="adminBackdrop"></div>

    <main class="ml-admin-main">
      <div class="ml-admin-topbar">
        <div class="ml-admin-topbar-left">
          <button class="ml-admin-toggle" type="button" data-admin-menu aria-controls="adminSidebar" aria-expanded="false" aria-label="Toggle navigation"><i class="fas fa-bars"></i></button>
          
          <h4 class="m-0 fw-bold">Review Moderation</h4>
        </div>
      </div>

      <div class="ml-admin-content">
        
        <div class="admin-card mb-4">
          <div class="admin-card-body d-flex gap-3">
            <select class="form-select w-auto" data-card-select>
              <option value="">All Ratings</option>
              <option value="5">5 ★</option>
              <option value="4">4 ★</option>
              <option value="3">3 ★</option>
              <option value="2">2 ★</option>
              <option value="1">1 ★</option>
            </select>
            <input type="text" class="form-control" data-card-search placeholder="Search by client, farmer or comment..." style="max-width: 320px;">
            <span class="text-muted small align-self-center" data-card-count></span>
          </div>
        </div>

        <div class="row g-4">
          @forelse($reviews ?? [] as $r)
          <div class="col-md-6 col-xl-4" data-card-item data-rating="{{ (int) $r->rating }}" data-search="{{ strtolower(($r->customer->name ?? '') . ' ' . ($r->farmer->displayName() ?? '') . ' ' . ($r->comment ?? '')) }}">
            <div class="admin-card h-100 p-3">
              <div class="d-flex justify-content-between align-items-start mb-3">
                <div class="d-flex gap-2 align-items-center">
                  <img src="{{ $r->customer ? $r->customer->avatarUrl() : \App\Support\Placeholder::initials('Customer') }}" class="rounded-circle" style="width:40px;height:40px;object-fit:cover;">
                  <div>
                    <strong>{{ $r->customer ? $r->customer->name : 'Customer' }}</strong><br>
                    <small class="text-muted">Reviewed: {{ $r->farmer ? $r->farmer->displayName() : 'Farmer' }}</small>
                  </div>
                </div>
              </div>
              <div class="d-flex justify-content-between align-items-center mb-2">
                <div class="text-warning">
                  @for($i = 1; $i <= 5; $i++)
                    <i class="{{ $i <= $r->rating ? 'fas' : 'far' }} fa-star"></i>
                  @endfor
                </div>
                <span class="badge bg-light text-dark border">
                  @if($r->product)
                    <i class="fas fa-box me-1"></i>{{ $r->product->name }}
                  @else
                    <i class="fas fa-store me-1"></i>Stall review
                  @endif
                </span>
              </div>
              <p class="mb-3 text-muted">&quot;{{ $r->comment ?? 'No comment.' }}&quot;</p>
              @if($r->hasReply())
                <div class="p-2 bg-light rounded-3 mb-2">
                  <small class="fw-bold d-block"><i class="fas fa-reply text-success me-1"></i>Farmer reply</small>
                  <small class="text-muted">{{ \Illuminate\Support\Str::limit($r->farmer_reply, 120) }}</small>
                </div>
              @endif
              <small class="text-muted d-block mb-1">{{ $r->created_at->format('M d, Y') }}</small>
              @if($r->order)<small class="text-muted d-block mb-2">Order {{ $r->order->code() }}</small>@endif
              <div class="d-flex gap-2 mt-2">
                <a href="/farmer-profile?id={{ $r->farmer_id }}" class="btn btn-sm btn-light"><i class="fas fa-tractor me-1"></i>Stall</a>
                <form action="/admin-reviews/{{ $r->id }}" method="POST" onsubmit="return confirm('Remove this review permanently? (SRS content moderation)')">
                  @csrf
                  @method('DELETE')
                  <button class="btn btn-sm btn-outline-danger"><i class="fas fa-trash me-1"></i>Remove review</button>
                </form>
              </div>
            </div>
          </div>
          @empty
          <div class="col-12">
            <div class="admin-card p-4 text-center text-muted" data-card-noresult>
              No reviews yet. Reviews are written by clients after a completed pickup, and appear here instantly.
            </div>
          </div>
          @endforelse
        </div>

      </div>
    </main>
  </div>
@endsection
