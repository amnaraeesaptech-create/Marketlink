@extends('layouts.dashboard')

@section('title', 'Admin Customers - MarketLink')

@section('content')
<div class="ml-admin-layout">
    <aside class="ml-admin-sidebar" id="adminSidebar">
      <div class="ml-admin-sidebar-header">
        <a href="/" class="ml-admin-brand"><i class="fas fa-seedling"></i> MarketLink</a>
        <span class="ml-admin-badge">Admin</span>
      </div>
      <div class="ml-admin-sidebar-user">
        <img src="{{ auth()->user()->avatarUrl() }}" alt="{{ auth()->user()->name }}">
        <div>
          <div>{{ auth()->user()->name }}</div>
          <div>{{ auth()->user()->email }}</div>
        </div>
      </div>
      <nav class="ml-admin-nav">
        <a href="/admin-dashboard" class="ml-admin-nav-link"><i class="fas fa-th-large"></i> Dashboard</a>
        <a href="/admin-farmers" class="ml-admin-nav-link"><i class="fas fa-tractor"></i> Farmers</a>
        <a href="/admin-customers" class="ml-admin-nav-link active"><i class="fas fa-users"></i> Customers</a>
        <a href="/admin-markets" class="ml-admin-nav-link"><i class="fas fa-store"></i> Markets</a>
        <a href="/admin-products" class="ml-admin-nav-link"><i class="fas fa-box"></i> Products</a>
        <a href="/admin-orders" class="ml-admin-nav-link"><i class="fas fa-shopping-bag"></i> Orders</a>
        <a href="/admin-reviews" class="ml-admin-nav-link"><i class="fas fa-star"></i> Reviews</a>
        <a href="/admin-reports" class="ml-admin-nav-link"><i class="fas fa-chart-bar"></i> Reports</a>

        <a href="/admin-categories" class="ml-admin-nav-link"><i class="fas fa-tags"></i> Categories</a>
        <a href="/admin-announcements" class="ml-admin-nav-link"><i class="fas fa-bullhorn"></i> Announcements</a>
        <a href="/notifications" class="ml-admin-nav-link"><i class="fas fa-bell"></i> Notifications</a>
        <hr>
        <form action="/logout" method="POST">
          @csrf
          <button type="submit" class="ml-admin-nav-link ml-admin-logout w-100 border-0 bg-transparent text-start"><i class="fas fa-sign-out-alt"></i> Logout</button>
        </form>
      </nav>
    </aside>
    <div class="ml-admin-backdrop" id="adminBackdrop"></div>

    <main class="ml-admin-main">
      <div class="ml-admin-topbar">
        <div class="ml-admin-topbar-left">
          <button class="ml-admin-toggle" type="button" data-admin-menu aria-controls="adminSidebar" aria-expanded="false" aria-label="Toggle navigation"><i class="fas fa-bars"></i></button>
          
          <h4 class="m-0 fw-bold">Manage Customers</h4>
        </div>
      </div>

      <div class="ml-admin-content">
        <!-- Stats -->
        <div class="row g-4 mb-4">
          <div class="col-md-4">
            <div class="admin-stat-card">
              <div class="admin-stat-icon icon-blue"><i class="fas fa-users"></i></div>
              <div class="admin-stat-info">
                <p>Total Customers</p>
                <h3>{{ $statTotal }}</h3>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="admin-stat-card">
              <div class="admin-stat-icon icon-green"><i class="fas fa-user-check"></i></div>
              <div class="admin-stat-info">
                <p>Active Customers</p>
                <h3>{{ $statActive }}</h3>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="admin-stat-card">
              <div class="admin-stat-icon icon-gray"><i class="fas fa-user-slash"></i></div>
              <div class="admin-stat-info">
                <p>Inactive Customers</p>
                <h3>{{ $statInactive }}</h3>
              </div>
            </div>
          </div>
        </div>

        <div class="admin-card mb-4">
          <div class="admin-card-body d-flex gap-3">
            <input type="text" class="form-control" data-table-filter="#adminCustomersTable" placeholder="Search customers by name, email, or phone..." style="max-width: 400px;">
            <select class="form-select w-auto" data-table-select="#adminCustomersTable" data-col="7">
              <option value="">All Statuses</option>
              <option value="active">Active</option>
              <option value="inactive">Inactive</option>
            </select>
            <span class="text-muted small align-self-center" data-table-count="#adminCustomersTable"></span>
            <button class="btn btn-outline-secondary btn-sm ms-auto" type="button" data-export-table="#adminCustomersTable" data-export-name="marketlink-customers"><i class="fas fa-file-export"></i> Export CSV</button>
          </div>
        </div>

        <div class="admin-card">
          <div class="table-responsive">
            <table class="table admin-table table-hover mb-0" id="adminCustomersTable" data-filterable>
              <thead>
                <tr>
                  <th>#</th>
                  <th>Customer</th>
                  <th>Email</th>
                  <th>Phone</th>
                  <th>Location</th>
                  <th>Joined</th>
                  <th>Orders</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                @forelse($customers ?? [] as $c)
                <tr>
                  <td>{{ $loop->iteration }}</td>
                  <td>
                    <div class="farmer-avatar-name">
                      <img src="{{ $c->avatarUrl() }}" alt="Avatar">
                      <strong>{{ $c->name }}</strong>
                    </div>
                  </td>
                  <td>{{ $c->email }}</td>
                  <td>{{ $c->phone ?? '—' }}</td>
                  <td>{{ $c->customer->city ?? '—' }}</td>
                  <td>{{ $c->created_at->format('M d, Y') }}</td>
                  <td>{{ $c->customer_orders_count }}</td>
                  <td><span class="badge {{ $c->is_active ? 'badge-active' : 'badge-suspended' }}">{{ $c->is_active ? 'Active' : 'Inactive' }}</span></td>
                  <td class="text-nowrap">
                    <form action="/admin-customers/{{ $c->id }}/toggle" method="POST" class="d-inline">
                      @csrf
                      <button class="btn btn-sm btn-light {{ $c->is_active ? 'text-warning' : 'text-success' }}" title="{{ $c->is_active ? 'Deactivate' : 'Activate' }}"><i class="fas fa-power-off"></i></button>
                    </form>
                    <form action="/admin-customers/{{ $c->id }}" method="POST" class="d-inline" onsubmit="return confirm('Delete this customer and ALL their orders, favorites and reviews? This cannot be undone.')">
                      @csrf
                      @method('DELETE')
                      <button class="btn btn-sm btn-light text-danger" title="Delete"><i class="fas fa-trash"></i></button>
                    </form>
                  </td>
                </tr>
                @empty
                <tr data-filter-empty="1">
                  <td colspan="9" class="text-center text-muted py-4">
                    No clients registered yet. Accounts appear here as soon as someone signs up at
                    <a href="/register" class="text-success text-decoration-none">/register</a>.
                  </td>
                </tr>
                @endforelse
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </main>
  </div>
@endsection
