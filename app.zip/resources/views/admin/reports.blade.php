@extends('layouts.dashboard')

@section('title', 'Admin Reports - MarketLink')

@section('content')
<div class="ml-admin-layout">
    <aside class="ml-admin-sidebar" id="adminSidebar">
      <div class="ml-admin-sidebar-header">
        <a href="/" class="ml-admin-brand"><i class="fas fa-seedling"></i> MarketLink</a>
        <span class="ml-admin-badge">Admin</span>
      </div>
      <div class="ml-admin-sidebar-user">
        <img src="{{ auth()->user()->avatarUrl() }}" alt="{{ auth()->user()->name }}">
        <div>
          <div>{{ auth()->user()->name }}</div>
          <div>{{ auth()->user()->email }}</div>
        </div>
      </div>
      <nav class="ml-admin-nav">
        <a href="/admin-dashboard" class="ml-admin-nav-link"><i class="fas fa-th-large"></i> Dashboard</a>
        <a href="/admin-farmers" class="ml-admin-nav-link"><i class="fas fa-tractor"></i> Farmers</a>
        <a href="/admin-customers" class="ml-admin-nav-link"><i class="fas fa-users"></i> Customers</a>
        <a href="/admin-markets" class="ml-admin-nav-link"><i class="fas fa-store"></i> Markets</a>
        <a href="/admin-products" class="ml-admin-nav-link"><i class="fas fa-box"></i> Products</a>
        <a href="/admin-orders" class="ml-admin-nav-link"><i class="fas fa-shopping-bag"></i> Orders</a>
        <a href="/admin-reviews" class="ml-admin-nav-link"><i class="fas fa-star"></i> Reviews</a>
        <a href="/admin-reports" class="ml-admin-nav-link active"><i class="fas fa-chart-bar"></i> Reports</a>
        <a href="/admin-categories" class="ml-admin-nav-link"><i class="fas fa-tags"></i> Categories</a>
        <a href="/admin-announcements" class="ml-admin-nav-link"><i class="fas fa-bullhorn"></i> Announcements</a>
        <a href="/notifications" class="ml-admin-nav-link"><i class="fas fa-bell"></i> Notifications</a>
        <hr>
        <form action="/logout" method="POST">
          @csrf
          <button type="submit" class="ml-admin-nav-link ml-admin-logout w-100 border-0 bg-transparent text-start"><i class="fas fa-sign-out-alt"></i> Logout</button>
        </form>
      </nav>
    </aside>
    <div class="ml-admin-backdrop" id="adminBackdrop"></div>

    <main class="ml-admin-main">
      <div class="ml-admin-topbar">
        <div class="ml-admin-topbar-left">
          <button class="ml-admin-toggle" type="button" data-admin-menu aria-controls="adminSidebar" aria-expanded="false" aria-label="Toggle navigation"><i class="fas fa-bars"></i></button>
          
          <h4 class="m-0 fw-bold">Reports & Analytics</h4>
        </div>
        <div class="text-end">
          <div class="small text-muted">Live totals as of {{ now()->format('M d, Y H:i') }}</div>
          <a href="/admin-orders" class="btn btn-success btn-sm mt-1"><i class="fas fa-shopping-bag"></i> View Orders</a>
        </div>
      </div>

      <div class="ml-admin-content">
        
        <!-- Report Cards (live) -->
        <div class="row g-4 mb-4">
          <div class="col-md-3">
            <div class="admin-stat-card border-0 bg-white">
              <div class="admin-stat-icon icon-purple"><i class="fas fa-shopping-cart"></i></div>
              <div class="admin-stat-info">
                <p>Total Orders</p>
                <h3>{{ $totalOrders }}</h3>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="admin-stat-card border-0 bg-white">
              <div class="admin-stat-icon icon-gradient"><i class="fas fa-money-bill-wave"></i></div>
              <div class="admin-stat-info">
                <p>Collected Revenue</p>
                <h3>PKR {{ $revenueFmt }}</h3>
                <small class="text-muted">Avg order PKR {{ $avgOrderFmt }}</small>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="admin-stat-card border-0 bg-white">
              <div class="admin-stat-icon icon-green"><i class="fas fa-tractor"></i></div>
              <div class="admin-stat-info">
                <p>Farmers / Markets</p>
                <h3>{{ $totalFarmers }} / {{ $totalMarkets }}</h3>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="admin-stat-card border-0 bg-white">
              <div class="admin-stat-icon icon-blue"><i class="fas fa-users"></i></div>
              <div class="admin-stat-info">
                <p>Clients</p>
                <h3>{{ $totalCustomers }}</h3>
                <small class="text-muted">{{ $totalProducts }} products listed</small>
              </div>
            </div>
          </div>
        </div>

        <!-- Monthly chart + category mix -->
        <div class="row g-4 mb-4">
          <div class="col-lg-7">
            <div class="admin-card h-100">
              <div class="admin-card-header"><h5>Order Value — Last 12 Months (PKR)</h5></div>
              <div class="admin-card-body">
                @php($maxMonth = max(1, max($monthly ?: [0])))
                <div class="simple-bar-chart">
                  @foreach($monthly as $month => $value)
                    <div class="bar-col">
                      <div class="bar" style="height: {{ max(2, round($value / $maxMonth * 100)) }}%; background-color:#2196F3" title="{{ number_format($value, 0) }} in {{ $month }}"></div>
                      <div class="bar-label">{{ $month }}</div>
                    </div>
                  @endforeach
                </div>
              </div>
            </div>
          </div>
          <div class="col-lg-5">
            <div class="admin-card h-100">
              <div class="admin-card-header"><h5>Units Sold by Category</h5></div>
              <div class="admin-card-body">
                @forelse($categoryShare as $category => $units)
                  <div class="mb-3">
                    <div class="d-flex justify-content-between mb-1">
                      <span>{{ $category }}</span>
                      <span>{{ $units }} unit{{ $units === 1 ? '' : 's' }}{{ $totalSold ? ' (' . round($units * 100 / $totalSold) . '%)' : '' }}</span>
                    </div>
                    <div class="progress" style="height: 8px;">
                      <div class="progress-bar bg-success" style="width: {{ $totalSold ? round($units * 100 / $totalSold) : 0 }}%"></div>
                    </div>
                  </div>
                @empty
                  <p class="text-muted mb-0">No sales recorded yet.</p>
                @endforelse
              </div>
            </div>
          </div>
        </div>

        <div class="row g-4">
          <div class="col-lg-6">
            <div class="admin-card h-100">
              <div class="admin-card-header">
                <h5>Market Activity (real)</h5>
              </div>
              <div class="table-responsive">
                <table class="table admin-table mb-0">
                  <thead>
                    <tr>
                      <th>Market Name</th>
                      <th>Orders</th>
                      <th>Revenue</th>
                      <th>Farmers</th>
                    </tr>
                  </thead>
                  <tbody>
                    @forelse(\App\Support\Catalog::allMarkets() as $market)
                      @php($mOrders = \App\Models\Order::where('market', $market->name))
                      <tr>
                        <td>{{ $market->name }}</td>
                        <td>{{ $mOrders->count() }}</td>
                        <td>PKR {{ number_format((float) $mOrders->sum('subtotal'), 0) }}</td>
                        <td>{{ $market->farmers_count }}</td>
                      </tr>
                    @empty
                      <tr><td colspan="4" class="text-center text-muted py-3">No markets created yet.</td></tr>
                    @endforelse
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          
          <div class="col-lg-6">
            <div class="admin-card h-100">
              <div class="admin-card-header">
                <h5>Top 5 Products (by units sold)</h5>
              </div>
              <div class="admin-card-body">
                @php($best = \App\Models\OrderItem::selectRaw('name, SUM(qty) as sold, SUM(qty * price) as money')->groupBy('name')->orderByDesc('sold')->limit(5)->get())
                @php($bestMax = max(1, (int) ($best->max('sold') ?? 1)))
                @forelse($best as $item)
                  <div class="d-flex align-items-center {{ $loop->last ? '' : 'mb-3' }}">
                    <span class="text-muted me-3" style="width: 20px">{{ $loop->iteration }}.</span>
                    <div class="flex-grow-1">
                      <div class="d-flex justify-content-between mb-1">
                        <span class="fw-bold">{{ $item->name }}</span>
                        <span>{{ (int) $item->sold }} sold &bull; PKR {{ number_format((float) $item->money, 0) }}</span>
                      </div>
                      <div class="progress" style="height: 6px;">
                        <div class="progress-bar bg-success" style="width: {{ round($item->sold / $bestMax * 100) }}%"></div>
                      </div>
                    </div>
                  </div>
                @empty
                  <p class="text-muted mb-0">No items sold yet.</p>
                @endforelse
              </div>
            </div>
          </div>
        </div>

      </div>
    </main>
  </div>
@endsection
