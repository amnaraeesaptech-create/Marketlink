@extends('layouts.dashboard')

@section('title', 'Admin Farmers - MarketLink')

@section('content')
<div class="ml-admin-layout">
    <!-- Sidebar -->
    <aside class="ml-admin-sidebar" id="adminSidebar">
      <div class="ml-admin-sidebar-header">
        <a href="/" class="ml-admin-brand"><i class="fas fa-seedling"></i> MarketLink</a>
        <span class="ml-admin-badge">Admin</span>
      </div>
      <div class="ml-admin-sidebar-user">
        <img src="{{ auth()->user()->avatarUrl() }}" alt="{{ auth()->user()->name }}">
        <div>
          <div>{{ auth()->user()->name }}</div>
          <div>{{ auth()->user()->email }}</div>
        </div>
      </div>
      <nav class="ml-admin-nav">
        <a href="/admin-dashboard" class="ml-admin-nav-link"><i class="fas fa-th-large"></i> Dashboard</a>
        <a href="/admin-farmers" class="ml-admin-nav-link active"><i class="fas fa-tractor"></i> Farmers</a>
        <a href="/admin-customers" class="ml-admin-nav-link"><i class="fas fa-users"></i> Customers</a>
        <a href="/admin-markets" class="ml-admin-nav-link"><i class="fas fa-store"></i> Markets</a>
        <a href="/admin-products" class="ml-admin-nav-link"><i class="fas fa-box"></i> Products</a>
        <a href="/admin-orders" class="ml-admin-nav-link"><i class="fas fa-shopping-bag"></i> Orders</a>
        <a href="/admin-reviews" class="ml-admin-nav-link"><i class="fas fa-star"></i> Reviews</a>
        <a href="/admin-reports" class="ml-admin-nav-link"><i class="fas fa-chart-bar"></i> Reports</a>

        <a href="/admin-categories" class="ml-admin-nav-link"><i class="fas fa-tags"></i> Categories</a>
        <a href="/admin-announcements" class="ml-admin-nav-link"><i class="fas fa-bullhorn"></i> Announcements</a>
        <a href="/notifications" class="ml-admin-nav-link"><i class="fas fa-bell"></i> Notifications</a>
        <hr>
        <form action="/logout" method="POST">
          @csrf
          <button type="submit" class="ml-admin-nav-link ml-admin-logout w-100 border-0 bg-transparent text-start"><i class="fas fa-sign-out-alt"></i> Logout</button>
        </form>
      </nav>
    </aside>

    <!-- Main Content -->
    <div class="ml-admin-backdrop" id="adminBackdrop"></div>

    <main class="ml-admin-main">
      <div class="ml-admin-topbar">
        <div class="ml-admin-topbar-left">
          <button class="ml-admin-toggle" type="button" data-admin-menu aria-controls="adminSidebar" aria-expanded="false" aria-label="Toggle navigation"><i class="fas fa-bars"></i></button>
          
          <h4 class="m-0 fw-bold">Manage Farmers</h4>
        </div>
        <div class="d-flex align-items-center gap-3">
          <span class="text-muted small" data-table-count="#adminFarmersTable"></span>
          <button class="btn btn-outline-secondary btn-sm" type="button" data-export-table="#adminFarmersTable" data-export-name="marketlink-farmers"><i class="fas fa-file-export"></i> Export CSV</button>
        </div>
      </div>

      <div class="ml-admin-content">
        
        <!-- Stats -->
        <div class="row g-4 mb-4">
          <div class="col-md-3">
            <div class="admin-stat-card">
              <div class="admin-stat-icon icon-blue"><i class="fas fa-users"></i></div>
              <div class="admin-stat-info">
                <p>Total Farmers</p>
                <h3>{{ $statTotal }}</h3>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="admin-stat-card">
              <div class="admin-stat-icon icon-green"><i class="fas fa-check-circle"></i></div>
              <div class="admin-stat-info">
                <p>Approved stalls</p>
                <h3>{{ $statApproved }}</h3>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="admin-stat-card">
              <div class="admin-stat-icon icon-amber"><i class="fas fa-box"></i></div>
              <div class="admin-stat-info">
                <p>Total Products</p>
                <h3>{{ $statProducts }}</h3>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="admin-stat-card">
              <div class="admin-stat-icon icon-amber" style="background:#fff3cd; color:#8a6d3b"><i class="fas fa-hourglass-half"></i></div>
              <div class="admin-stat-info">
                <p>Pending approval</p>
                <h3>{{ $statPending }}</h3>
              </div>
            </div>
          </div>
        </div>

        @if($statPending > 0)
        <div class="alert alert-warning d-flex align-items-center gap-2">
          <i class="fas fa-triangle-exclamation"></i>
          <div><strong>{{ $statPending }} stall(s) awaiting approval.</strong> Their products stay hidden from the storefront until you approve them (SRS: admin approves farmers).</div>
        </div>
        @endif

        <!-- Filters & Search -->
        <div class="admin-card mb-4">
          <div class="admin-card-body d-flex flex-wrap gap-3 align-items-center justify-content-between">
            <div class="d-flex gap-3 flex-grow-1" style="max-width: 500px;">
              <input type="text" class="form-control" data-table-filter="#adminFarmersTable" placeholder="Search farmers by name, stall, or email...">
            </div>
            <div class="d-flex gap-3">
              <select class="form-select w-auto" data-table-select="#adminFarmersTable" data-col="6">
                <option value="">All Statuses</option>
                <option value="approved">Active account</option>
                <option value="suspended">Suspended</option>
              </select>
              <select class="form-select w-auto" data-table-select="#adminFarmersTable" data-col="7">
                <option value="">All approvals</option>
                <option value="pending approval">Pending approval</option>
                <option value="listed">Listed</option>
              </select>
            </div>
          </div>
        </div>

        <!-- Table -->
        <div class="admin-card">
          <div class="table-responsive">
            <table class="table admin-table table-hover mb-0" id="adminFarmersTable" data-filterable>
              <thead>
                <tr>
                  <th>#</th>
                  <th>Farmer</th>
                  <th>Stall Name</th>
                  <th>Markets</th>
                  <th>Products</th>
                  <th>Orders</th>
                  <th>Status</th>
                  <th>Approval</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody id="farmerTableBody">
                @forelse($farmers ?? [] as $f)
                <tr>
                  <td>{{ $loop->iteration }}</td>
                  <td>
                    <div class="farmer-avatar-name">
                      <img src="{{ $f->avatarUrl() }}" alt="Avatar">
                      <div>
                        <strong>{{ $f->name }}</strong><br>
                        <small class="text-muted">{{ $f->email }}</small>
                      </div>
                    </div>
                  </td>
                  <td>{{ $f->farmer->stall_name ?? '—' }}</td>
                  <td>{{ count($f->farmer->markets ?? []) }}</td>
                  <td>{{ $f->products_count }}</td>
                  <td>{{ $f->farmer_orders_count }}</td>
                  <td><span class="badge {{ $f->is_active ? 'badge-approved' : 'badge-suspended' }}">{{ $f->is_active ? 'Active' : 'Suspended' }}</span></td>
                  <td>
                    @if(($f->farmer->is_approved ?? false))
                      <span class="badge badge-active">Listed</span>
                    @else
                      <span class="badge badge-pending">Pending approval</span>
                    @endif
                  </td>
                  <td class="text-nowrap">
                    <a href="/farmer-profile?id={{ $f->id }}" class="btn btn-sm btn-light" title="View public profile"><i class="fas fa-eye"></i></a>
                    @if(! ($f->farmer->is_approved ?? false))
                    <form action="/admin-farmers/{{ $f->id }}/approve" method="POST" class="d-inline">
                      @csrf
                      <button class="btn btn-sm btn-success" title="Approve this stall so its products go live"><i class="fas fa-check"></i> Approve</button>
                    </form>
                    @else
                    <form action="/admin-farmers/{{ $f->id }}/approve" method="POST" class="d-inline">
                      @csrf
                      <button class="btn btn-sm btn-light text-warning" title="Un-approve (hide products until reviewed again)"><i class="fas fa-rotate-left"></i></button>
                    </form>
                    @endif
                    <form action="/admin-farmers/{{ $f->id }}/toggle" method="POST" class="d-inline">
                      @csrf
                      <button class="btn btn-sm btn-light {{ $f->is_active ? 'text-danger' : 'text-success' }}" title="{{ $f->is_active ? 'Suspend' : 'Restore' }}"><i class="fas {{ $f->is_active ? 'fa-ban' : 'fa-undo' }}"></i></button>
                    </form>
                    <form action="/admin-farmers/{{ $f->id }}" method="POST" class="d-inline" onsubmit="return confirm('Delete this farmer and ALL their products and orders? This cannot be undone.')">
                      @csrf
                      @method('DELETE')
                      <button class="btn btn-sm btn-light text-danger" title="Delete"><i class="fas fa-trash"></i></button>
                    </form>
                  </td>
                </tr>
                @empty
                <tr data-filter-empty="1">
                  <td colspan="9" class="text-center text-muted py-4">
                    No farmers registered yet. Stalls appear here the moment someone registers at
                    <a href="/farmer-register" class="text-success text-decoration-none">/farmer-register</a>.
                  </td>
                </tr>
                @endforelse
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </main>
  </div>

  <!-- Farmer details open on the real public profile page (no demo modal). -->

@endsection
