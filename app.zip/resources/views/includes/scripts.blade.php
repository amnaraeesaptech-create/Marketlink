<!-- Floating UI -->
<button id="backToTop" aria-label="Back to top">
    <i class="fas fa-arrow-up"></i>
</button>

<!-- Scripts -->
<script src="/assets/vendor/bootstrap/bootstrap.bundle.min.js"></script>
<!-- Live DB feed (window.ML). Replaces the old hardcoded data.js mock. -->
<script src="/data-feed.js"></script>
<script src="/assets/js/main.js"></script>
@if(session('ml_reorder_seed'))
<script>
  window.ML_REORDER = {!! json_encode(session('ml_reorder_seed'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) !!};
  window.ML_REORDER_META = {!! json_encode(session('ml_reorder_meta'), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) !!};
</script>
@endif
<script src="/assets/js/cart.js"></script>
<script src="/assets/js/listings.js"></script>
<script src="/assets/js/geo.js"></script>
<script src="/assets/js/chatbot.js"></script>
