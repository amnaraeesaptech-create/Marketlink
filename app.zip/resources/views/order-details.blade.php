@extends('layouts.app')

@section('title', 'Order Details - MarketLink')

@section('content')
@if(!empty($order ?? null))
<div class="container py-5">
    <a href="{{ $backUrl ?? '/customer-orders' }}" class="text-decoration-none text-muted mb-3 d-inline-block"><i class="fas fa-arrow-left"></i> Back to Orders</a>

    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-2">
        <h2 class="fw-bold mb-0">Order {{ $order->code() }}</h2>
        <span class="badge {{ $order->statusBadge() }} px-3 py-2 rounded-pill fs-6">{{ $order->statusLabel() }}</span>
    </div>

    @if($order->status === 'cancelled')
      <div class="alert alert-danger"><i class="fas fa-ban me-2"></i> This order was cancelled. Stock has been returned to the farmer's inventory.</div>
    @endif

    <!-- Progress Timeline -->
    @php
      $steps = ['pending' => 'Placed', 'confirmed' => 'Accepted', 'ready' => 'Ready for Pickup', 'completed' => 'Completed'];
      $keys = array_keys($steps);
      $currentIdx = array_search($order->status, $keys);
      if ($currentIdx === false) $currentIdx = -1;
    @endphp
    <div class="step-indicator mb-5">
        @foreach($steps as $key => $label)
          @php $idx = array_search($key, $keys); @endphp
          @if($idx > 0)<div class="step-line {{ $idx <= $currentIdx ? 'bg-success' : '' }}"></div>@endif
          <div class="step {{ $idx < $currentIdx ? 'completed' : ($idx === $currentIdx ? 'active' : '') }}">
              <div class="step-icon">@if($idx < $currentIdx)<i class="fas fa-check"></i>@else{{ $idx + 1 }}@endif</div>
              <span>{{ $label }}</span>
          </div>
        @endforeach
    </div>

    <div class="row g-4">
        <!-- Left: Items -->
        <div class="col-lg-8">
            @if(in_array($order->status, ['pending', 'confirmed'], true))
              <div class="alert {{ ($canModify ?? false) ? 'alert-success' : 'alert-secondary' }} d-flex align-items-start gap-2">
                <i class="fas fa-hourglass-half mt-1"></i>
                <div class="small w-100">
                  @if($canModify ?? false)
                    <strong>Changes allowed until {{ $order->cutoffAt()?->format('M d, Y g:i A') }}</strong>
                    — You can edit quantities, change the pickup slot or cancel any time before
                    <strong>{{ $order->cutoffHours() }}h</strong> before your pickup
                    ({{ $order->pickupAt()?->format('M d, Y g:i A') }}).
                    <div class="mt-1 d-flex align-items-center gap-2">
                        <i class="fas fa-stopwatch text-success"></i>
                        Time remaining: <strong id="cutoff-countdown" class="text-success ms-1">calculating…</strong>
                    </div>
                  @else
                    The cut-off for changing this order has passed
                    @if($order->cutoffAt())
                        ({{ $order->cutoffAt()->format('M d, Y g:i A') }} — {{ $order->cutoffHours() }}h before pickup).
                    @endif
                    Please contact the farmer if something is wrong.
                  @endif
                </div>
              </div>
            @endif
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body p-4">
                    <h5 class="fw-bold mb-3">Items ({{ $order->items->count() }})</h5>
                    @foreach($order->items as $it)
                      <div class="d-flex align-items-center gap-3 mb-3 p-2 bg-light rounded-3">
                          <img src="{{ $it->product ? $it->product->imageUrl() : \App\Support\Placeholder::image($it->name) }}" class="rounded-2" width="70" height="70" alt="Item" style="object-fit: cover;">
                          <div class="flex-grow-1">
                              <div class="fw-medium">{{ $it->name }}</div>
                              <small class="text-muted">{{ $it->qty }} {{ $it->unit }} &times; PKR {{ number_format($it->price, 0) }}</small>
                          </div>
                          <div class="fw-bold">PKR {{ number_format($it->price * $it->qty, 0) }}</div>
                          @if(($canReview ?? false) && $it->product_id)
                            <button class="btn btn-sm btn-outline-warning text-nowrap" data-bs-toggle="modal" data-bs-target="#productReviewModal"
                                    data-product-id="{{ $it->product_id }}" data-product-name="{{ $it->name }}"
                                    data-rate-url="/reviews">Review</button>
                          @elseif(in_array($it->product_id, $reviewedProductIds ?? [], true))
                            <span class="badge bg-warning-subtle text-warning-emphasis text-nowrap">Product reviewed</span>
                          @endif
                      </div>
                    @endforeach
                    <hr>
                    <div class="d-flex justify-content-between mb-1">
                        <span class="text-muted">Subtotal</span>
                        <span class="fw-medium">PKR {{ number_format($order->subtotal, 0) }}</span>
                    </div>
                    <div class="d-flex justify-content-between">
                        <span class="fw-bold fs-5">Total (pay at pickup)</span>
                        <span class="fw-bold fs-5 text-success">PKR {{ number_format($order->subtotal, 0) }}</span>
                    </div>
                </div>
            </div>

            <!-- Pickup Info -->
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body p-4">
                    <h5 class="fw-bold mb-3">Pickup Information</h5>
                    <div class="row g-3">
                        <div class="col-md-4">
                            <div class="p-3 bg-light rounded-3 text-center">
                                <i class="fas fa-map-marker-alt text-success mb-1"></i>
                                <div class="fw-medium small">Market</div>
                                <div class="small text-muted">{{ $order->market ?? '—' }}</div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="p-3 bg-light rounded-3 text-center">
                                <i class="fas fa-calendar-alt text-success mb-1"></i>
                                <div class="fw-medium small">Pickup Date</div>
                                <div class="small text-muted">{{ $order->pickup_date ? \Carbon\Carbon::parse($order->pickup_date)->format('D, M d, Y') : '—' }}</div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="p-3 bg-light rounded-3 text-center">
                                <i class="fas fa-clock text-success mb-1"></i>
                                <div class="fw-medium small">Time Slot</div>
                                <div class="small text-muted">{{ $order->pickup_slot ?? '—' }}</div>
                            </div>
                        </div>
                    </div>
                    @if($order->notes)
                      <div class="mt-3 p-3 bg-light rounded-3">
                          <div class="fw-medium small mb-1">Your Notes</div>
                          <div class="small text-muted">{{ $order->notes }}</div>
                      </div>
                    @endif

                    {{-- SRS: "route-friendly pickup details through OpenStreetMap integration" --}}
                    @if(isset($pickupMarket) && $pickupMarket?->latitude && $pickupMarket?->longitude)
                    <div class="mt-3">
                        <div class="fw-medium small mb-2">
                            <i class="fas fa-map-marker-alt text-success me-1"></i>Pickup Location Map
                        </div>
                        <div class="rounded-3 overflow-hidden border mb-2" style="height:220px;">
                            <iframe
                                title="Pickup location — {{ $pickupMarket->name }}"
                                width="100%"
                                height="220"
                                style="border:0; display:block;"
                                loading="lazy"
                                referrerpolicy="no-referrer-when-downgrade"
                                src="https://www.openstreetmap.org/export/embed.html?bbox={{ (float)$pickupMarket->longitude - 0.012 }}%2C{{ (float)$pickupMarket->latitude - 0.012 }}%2C{{ (float)$pickupMarket->longitude + 0.012 }}%2C{{ (float)$pickupMarket->latitude + 0.012 }}&amp;layer=mapnik&amp;marker={{ (float)$pickupMarket->latitude }}%2C{{ (float)$pickupMarket->longitude }}">
                            </iframe>
                        </div>
                        <div class="d-flex flex-wrap gap-2">
                            <a href="https://www.openstreetmap.org/directions?to={{ (float)$pickupMarket->latitude }}%2C{{ (float)$pickupMarket->longitude }}"
                               target="_blank" rel="noopener" class="btn btn-success btn-sm flex-grow-1">
                                <i class="fa-solid fa-diamond-turn-right me-1"></i>Directions to {{ $pickupMarket->name }}
                            </a>
                            <a href="https://www.openstreetmap.org/?mlat={{ (float)$pickupMarket->latitude }}&amp;mlon={{ (float)$pickupMarket->longitude }}#map=16/{{ (float)$pickupMarket->latitude }}/{{ (float)$pickupMarket->longitude }}"
                               target="_blank" rel="noopener" class="btn btn-outline-success btn-sm">
                                <i class="fa-solid fa-up-right-from-square me-1"></i>Open map
                            </a>
                        </div>
                    </div>
                    @elseif($order->market)
                    <div class="mt-3 p-3 bg-light rounded-3">
                        <div class="small text-muted">
                            <i class="fas fa-map-marker-alt me-1 text-success"></i>
                            Pickup at <strong>{{ $order->market }}</strong> — map coordinates not set for this market yet.
                        </div>
                    </div>
                    @endif
                </div>
            </div>

            <!-- Review -->
            @if($canReview ?? false)
            <div class="card border-0 shadow-sm mb-4" id="write-review">
                <div class="card-body p-4">
                    <h5 class="fw-bold mb-3">Write a Review</h5>
                    <form action="/reviews" method="POST">
                        @csrf
                        <input type="hidden" name="order_id" value="{{ $order->id }}">
                        <div class="mb-3">
                            <label class="form-label fw-medium">Your Rating *</label>
                            <div class="d-flex gap-1 fs-4" id="star-picker">
                                @for($i = 1; $i <= 5; $i++)
                                  <i class="far fa-star text-warning" data-star="{{ $i }}" style="cursor:pointer;"></i>
                                @endfor
                            </div>
                            <input type="hidden" name="rating" id="rating-input" value="{{ old('rating', 5) }}" required>
                            @error('rating')<div class="text-danger small">{{ $message }}</div>@enderror
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-medium">Your Review</label>
                            <textarea class="form-control" name="comment" rows="3" placeholder="How was the quality? Was pickup smooth?">{{ old('comment') }}</textarea>
                        </div>
                        <button type="submit" class="btn btn-warning fw-bold"><i class="fas fa-star me-1"></i> Submit Review</button>
                    </form>
                </div>
            </div>
            @elseif($order->review)
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body p-4">
                    <h5 class="fw-bold mb-3">Your Review</h5>
                    <div class="text-warning mb-2">
                        @for($i = 1; $i <= 5; $i++)
                          <i class="fas fa-star {{ $i <= $order->review->rating ? '' : 'text-muted opacity-25' }}"></i>
                        @endfor
                    </div>
                    @if($order->review->comment)
                      <p class="mb-0">{{ $order->review->comment }}</p>
                    @endif
                    @if($order->review->hasReply())
                      <div class="mt-3 p-3 bg-light rounded-3">
                        <div class="small fw-medium mb-1"><i class="fas fa-reply text-success me-1"></i>Farmer replied{{ $order->review->replied_at ? ' ' . $order->review->replied_at->diffForHumans() : '' }}</div>
                        <div class="small text-muted mb-0">{{ $order->review->farmer_reply }}</div>
                      </div>
                    @endif
                </div>
            </div>
            @endif

            @if(($productReviews ?? collect())->isNotEmpty())
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body p-4">
                    <h5 class="fw-bold mb-3">Product Ratings You Sent</h5>
                    @foreach($productReviews as $pid => $rev)
                      <div class="d-flex justify-content-between align-items-start gap-2 mb-3">
                        <div>
                          <div class="fw-medium">{{ $rev->product->name ?? 'Product #' . $pid }}</div>
                          <div class="text-warning small">
                            @for($i = 1; $i <= 5; $i++)
                              <i class="fas fa-star {{ $i <= $rev->rating ? '' : 'text-muted opacity-25' }}"></i>
                            @endfor
                          </div>
                          @if($rev->comment)<div class="small text-muted">{{ $rev->comment }}</div>@endif
                        </div>
                        @if($rev->hasReply())
                          <div class="small text-end" style="max-width:45%">
                            <span class="d-block fw-medium"><i class="fas fa-reply text-success"></i> Farmer replied</span>
                            <span class="text-muted">{{ $rev->farmer_reply }}</span>
                          </div>
                        @endif
                      </div>
                    @endforeach
                </div>
            </div>
            @endif
        </div>

        <!-- Right: Farmer + Actions -->
        <div class="col-lg-4">
            @if($order->farmer)
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body p-4 text-center">
                    <img src="{{ $order->farmer->avatarUrl() }}" class="rounded-circle mb-2" width="70" height="70" alt="Farmer" style="object-fit: cover;">
                    <h6 class="fw-bold mb-0">{{ $order->farmer->displayName() }}</h6>
                    <small class="text-muted">{{ $order->farmer->marketNames() ? implode(', ', array_slice($order->farmer->marketNames(), 0, 2)) : 'Local Farmer' }}</small>
                    <div class="mt-2">
                        <a href="/farmer-profile?id={{ $order->farmer->id }}" class="btn btn-sm btn-outline-success">View Profile</a>
                    </div>
                </div>
            </div>
            @endif

            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body p-4">
                    <h6 class="fw-bold mb-3">Order Info</h6>
                    <div class="small mb-2 d-flex justify-content-between"><span class="text-muted">Placed</span><span>{{ $order->created_at->format('M d, Y h:i A') }}</span></div>
                    <div class="small mb-2 d-flex justify-content-between"><span class="text-muted">Customer</span><span>{{ $order->customer->name }}</span></div>
                    <div class="small d-flex justify-content-between"><span class="text-muted">Status</span><span class="badge {{ $order->statusBadge() }}">{{ $order->statusLabel() }}</span></div>
                </div>
            </div>

            @if(($canModify ?? false) || ($canCancel ?? false))
            <div class="card border-0 shadow-sm">
                <div class="card-body p-4">
                    @if($canModify ?? false)
                      <form action="/customer-orders/{{ $order->id }}/update" method="POST">
                          @csrf
                          <h6 class="fw-bold mb-3"><i class="fas fa-pen-to-square text-success me-1"></i>Modify Order</h6>
                          @foreach($order->items as $it)
                            <div class="mb-2">
                              <label class="form-label small mb-1" for="qty{{ $it->id }}">
                                {{ $it->name }} <span class="text-muted">({{ $it->qty }} {{ $it->unit }} × PKR {{ number_format($it->price, 0) }})</span>
                              </label>
                              <input type="number" class="form-control form-control-sm" id="qty{{ $it->id }}"
                                     name="qty[{{ $it->id }}]" min="0" value="{{ $it->qty }}"
                                     @if($it->product) max="{{ max($it->qty, $it->product->stock) }}" @endif>
                              <div class="form-text">Set 0 to drop this item.</div>
                            </div>
                          @endforeach
                          <div class="mb-3">
                            <label class="form-label small mb-1" for="modSlot">Pickup date &amp; time slot</label>
                            <input type="date" class="form-control form-control-sm mb-2" id="modDate" name="pickup_date"
                                   value="{{ \Carbon\Carbon::parse($order->pickup_date)->format('Y-m-d') }}" min="{{ now()->format('Y-m-d') }}">
                            <select class="form-select form-select-sm" id="modSlot" name="pickup_slot">
                              @foreach($pickupSlots ?? [] as $slot)
                                <option value="{{ $slot }}" {{ $order->pickup_slot === $slot ? 'selected' : '' }}>{{ $slot }}</option>
                              @endforeach
                              @if(empty($pickupSlots) || ! in_array($order->pickup_slot, $pickupSlots ?? [], true))
                                <option value="{{ $order->pickup_slot }}" selected>{{ $order->pickup_slot }}</option>
                              @endif
                            </select>
                          </div>
                          <div class="mb-3">
                            <label class="form-label small mb-1" for="modNotes">Notes for the farmer</label>
                            <textarea class="form-control form-control-sm" id="modNotes" name="notes" rows="2">{{ $order->notes }}</textarea>
                          </div>
                          <button type="submit" class="btn btn-success w-100 btn-sm"><i class="fas fa-check me-1"></i> Save Changes</button>
                          <div class="form-text">Clearing every quantity cancels the order automatically.</div>
                      </form>
                      @if($canCancel ?? false)<hr>@endif
                    @endif
                    @if($canCancel ?? false)
                    <form action="/customer-orders/{{ $order->id }}/cancel" method="POST" onsubmit="return confirm('Cancel this order?')">
                        @csrf
                        <button type="submit" class="btn btn-outline-danger w-100"><i class="fas fa-times me-1"></i> Cancel Order</button>
                    </form>
                    @endif
                </div>
            </div>
            @endif

            @if(!($canModify ?? false) && in_array($order->status, ['completed', 'cancelled'], true))
            <div class="card border-0 shadow-sm">
                <div class="card-body p-4 d-grid gap-2">
                    <form action="/customer-orders/{{ $order->id }}/reorder" method="POST">
                        @csrf
                        <button type="submit" class="btn btn-success w-100"><i class="fas fa-rotate-right me-1"></i> Reorder These Items</button>
                    </form>
                    <div class="small text-muted text-center">Adds available items to your cart — stock is checked again at checkout.</div>
                </div>
            </div>
            @endif
        </div>
    </div>
</div>
@else
<div class="container py-5 text-center">
    <a href="/customer-orders" class="text-decoration-none text-muted mb-4 d-inline-block"><i class="fas fa-arrow-left"></i> Back to Orders</a>
    <div class="py-5">
        <i class="fas fa-receipt fa-3x text-success mb-3"></i>
        <h2 class="h4 fw-bold">No order selected</h2>
        <p class="text-muted">Open an order from your list to see its items, pickup details and review options.</p>
        <a href="/customer-orders" class="btn btn-success">View My Orders</a>
    </div>
</div>
@endif

@if(!empty($order ?? null) && ($canReview ?? false))
<div class="modal fade" id="productReviewModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <form action="/reviews" method="POST">
        @csrf
        <input type="hidden" name="order_id" value="{{ $order->id }}">
        <input type="hidden" name="product_id" id="prProductId">
        <div class="modal-header">
          <h5 class="modal-title">Rate: <span id="prProductName"></span></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label class="form-label fw-medium">Product rating *</label>
            <div class="d-flex gap-1 fs-4" id="pr-star-picker">
              @for($i = 1; $i <= 5; $i++)
                <i class="far fa-star text-warning" data-pr-star="{{ $i }}" style="cursor:pointer;"></i>
              @endfor
            </div>
            <input type="hidden" name="rating" id="pr-rating-input" value="5" required>
          </div>
          <div class="mb-0">
            <label class="form-label fw-medium">Comment</label>
            <textarea class="form-control" name="comment" rows="3" placeholder="Freshness, size, packaging…"></textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-warning fw-bold"><i class="fas fa-star me-1"></i> Submit Product Review</button>
        </div>
      </form>
    </div>
  </div>
</div>
@endif
@endsection

@push('scripts')
<script>
    (function() {
        const prModal = document.getElementById('productReviewModal');
        if (prModal) {
            prModal.addEventListener('show.bs.modal', (e) => {
                const btn = e.relatedTarget;
                if (!btn) return;
                document.getElementById('prProductId').value = btn.dataset.productId;
                document.getElementById('prProductName').textContent = btn.dataset.productName;
            });
            const prPicker = document.getElementById('pr-star-picker');
            const prInput = document.getElementById('pr-rating-input');
            if (prPicker && prInput) {
                const prStars = prPicker.querySelectorAll('[data-pr-star]');
                const prPaint = (n) => prStars.forEach(s => {
                    const v = parseInt(s.dataset.prStar, 10);
                    s.classList.toggle('fas', v <= n);
                    s.classList.toggle('far', v > n);
                });
                prPaint(5);
                prStars.forEach(s => s.addEventListener('click', () => {
                    prInput.value = s.dataset.prStar;
                    prPaint(parseInt(prInput.value, 10));
                }));
            }
        }

        const picker = document.getElementById('star-picker');
        const input = document.getElementById('rating-input');
        if (!picker || !input) return;
        const stars = picker.querySelectorAll('[data-star]');
        const paint = (n) => {
            stars.forEach(s => {
                const v = parseInt(s.dataset.star, 10);
                s.classList.toggle('fas', v <= n);
                s.classList.toggle('far', v > n);
            });
        };
        paint(parseInt(input.value, 10) || 5);
        stars.forEach(s => s.addEventListener('click', () => {
            input.value = s.dataset.star;
            paint(parseInt(input.value, 10));
        }));
    })();
</script>

@if(isset($order) && ($canModify ?? false) && $order->cutoffAt())
<script>
    (function() {
        const cutoffEl = document.getElementById('cutoff-countdown');
        if (!cutoffEl) return;
        const cutoff = new Date("{{ $order->cutoffAt()->toIso8601String() }}");
        if (isNaN(cutoff.getTime())) { cutoffEl.textContent = '—'; return; }

        function tick() {
            const diff = cutoff - Date.now();
            if (diff <= 0) {
                cutoffEl.textContent = 'Expired — please refresh';
                cutoffEl.className = 'text-danger ms-1 fw-bold';
                return;
            }
            const h = Math.floor(diff / 3600000);
            const m = Math.floor((diff % 3600000) / 60000);
            const s = Math.floor((diff % 60000) / 1000);
            cutoffEl.textContent = h + 'h ' + m + 'm ' + s + 's';
            // Turn orange when under 1 hour
            cutoffEl.className = (h < 1)
                ? 'text-warning ms-1 fw-bold'
                : 'text-success ms-1 fw-bold';
            setTimeout(tick, 1000);
        }
        tick();
    })();
</script>
@endif
@endpush
