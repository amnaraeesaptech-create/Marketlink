@extends('layouts.app')

@section('title', ($product?->name ?? 'Product') . ' — MarketLink')

@section('content')
@if(!$product)
    <div class="container py-5 text-center">
        <i class="fas fa-seedling fa-3x text-success mb-3"></i>
        <h1 class="h3 fw-bold">No products in the catalogue yet</h1>
        <p class="text-muted">Farmers haven't listed anything for sale. Check back soon.</p>
        <a href="/products" class="btn btn-success">Back to Products</a>
    </div>
@else
@php($farmer = $product->farmer)
<!-- Breadcrumb -->
    <div class="bg-light py-2 border-bottom">
        <div class="container">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="/" class="text-decoration-none">Home</a></li>
                    <li class="breadcrumb-item"><a href="/products" class="text-decoration-none">Products</a></li>
                    <li class="breadcrumb-item"><a href="/products" class="text-decoration-none">{{ $product->category }}</a></li>
                    <li class="breadcrumb-item active" aria-current="page">{{ $product->name }}</li>
                </ol>
            </nav>
        </div>
    </div>

    <!-- Main Section -->
    <div class="container py-5">
        <div class="row mb-5">
            <!-- Left: Images -->
            <div class="col-md-7 mb-4 mb-md-0">
                <div class="main-img-container mb-3 shadow-sm" id="img-container">
                    <img src="{{ $product->imageUrl() }}" id="main-product-image" class="main-img" alt="{{ $product->name }}">
                </div>
                <div class="row g-2">
                    <div class="col-4">
                        <img src="{{ $product->imageUrl() }}" class="img-fluid rounded thumbnail active" onclick="changeImage(this)" alt="{{ $product->name }}">
                    </div>
                </div>
            </div>

            <!-- Right: Details -->
            <div class="col-md-5">
                <span class="badge bg-success mb-2 px-3 py-2">{{ $product->category }}</span>
                <h1 class="fw-bold mb-2">{{ $product->name }}</h1>

                <div class="d-flex align-items-center mb-3">
                    <div class="text-warning me-2">
                        @php($rating = (int) round($product->rating ?? 0))
                        @for($i = 1; $i <= 5; $i++)
                            <i class="fa{{ $i <= $rating ? 's' : 'r' }} fa-star"></i>
                        @endfor
                    </div>
                    <a href="#nav-reviews" class="text-muted text-decoration-none small" data-bs-toggle="tab" data-bs-target="#nav-reviews">({{ $productReviews->count() }} product rating{{ $productReviews->count() === 1 ? '' : 's' }})</a>
                </div>

                <div class="d-flex align-items-center mb-4 p-3 bg-light rounded border">
                    <img src="{{ $farmer?->avatarUrl() }}" class="rounded-circle me-3" width="50" height="50" alt="{{ $farmer?->displayName() }}">
                    <div class="flex-grow-1" style="min-width: 0;">
                        <p class="mb-0 fw-bold text-truncate"><a href="/farmer-profile?id={{ $product->farmer_id }}" class="text-dark text-decoration-none">{{ $farmer?->displayName() ?? 'Local Farm' }}</a></p>
                        <span class="badge bg-secondary text-wrap text-start" style="max-width: 100%;">{{ $farmer?->marketNames() ? implode(', ', array_slice($farmer->marketNames(), 0, 2)) : 'No market linked' }}</span>
                    </div>
                </div>

                <div class="mb-3">
                    <span class="display-5 fw-bold text-success">Rs {{ number_format((float) $product->price, 0) }}</span>
                    <span class="text-muted fs-5">/ {{ $product->unit }}</span>
                </div>

                @if($product->is_available && $product->stock > 0)
                    <p class="text-success small fw-bold mb-4">
                        <i class="fas fa-check-circle me-1"></i> In Stock ({{ $product->stock }} {{ $product->unit }} available)
                    </p>
                @else
                    <p class="text-danger small fw-bold mb-4"><i class="fas fa-times-circle me-1"></i> Currently unavailable</p>
                @endif

                <p class="text-muted mb-4">
                    {{ $product->description ?: 'This farmer has not added a description for this product yet.' }}
                </p>

                <div class="d-flex align-items-center mb-4">
                    <div class="input-group me-3" style="width: 130px;">
                        <button class="btn btn-outline-secondary" type="button" id="btn-minus">-</button>
                        <input type="number" class="form-control text-center" id="qty-input" value="1" min="1" max="{{ max(1, (int) $product->stock) }}">
                        <button class="btn btn-outline-secondary" type="button" id="btn-plus">+</button>
                    </div>
                </div>

                <div class="d-grid gap-2 d-md-flex mb-4">
                    @if($product->is_available && $product->stock > 0)
                        <button class="btn btn-success btn-lg flex-grow-1" id="pdp-add-cart" data-id="{{ $product->id }}"><i class="fas fa-shopping-cart me-2"></i>Add to Cart</button>
                    @else
                        <button class="btn btn-secondary btn-lg flex-grow-1" disabled><i class="fas fa-ban me-2"></i>Out of Stock</button>
                    @endif
                    @auth
                        @if(auth()->user()->isCustomer())
                            <form action="/favorites/toggle" method="POST" class="d-inline">
                                @csrf
                                <input type="hidden" name="product_id" value="{{ $product->id }}">
                                <button class="btn btn-outline-danger btn-lg px-4" type="submit" title="Add to favorites"><i class="far fa-heart"></i></button>
                            </form>
                        @endif
                    @else
                        <a href="/login" class="btn btn-outline-danger btn-lg px-4" title="Login as a client to save favorites"><i class="far fa-heart"></i></a>
                    @endauth
                </div>

                <div class="card bg-light border-0">
                    <div class="card-body">
                        <div class="d-flex">
                            <i class="fas fa-store text-success fs-3 me-3 mt-1"></i>
                            <div>
                                <h6 class="fw-bold mb-1">
                                    Pickup: {{ $farmer?->marketNames() ? implode(', ', $farmer->marketNames()) : 'market not set' }}
                                </h6>
                                <p class="text-muted small mb-0">
                                    {{ $farmer?->pickup_windows ? implode(' • ', $farmer->pickup_windows) : 'Pickup windows are set by the farmer' }}
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tabs -->
        <div class="row mb-5">
            <div class="col-12">
                <nav>
                    <div class="nav nav-tabs" id="nav-tab" role="tablist">
                        <button class="nav-link active text-success fw-bold" id="nav-desc-tab" data-bs-toggle="tab" data-bs-target="#nav-desc" type="button" role="tab">Description</button>
                        <button class="nav-link text-dark fw-bold" id="nav-pickup-tab" data-bs-toggle="tab" data-bs-target="#nav-pickup" type="button" role="tab">Pickup Info</button>
                        <button class="nav-link text-dark fw-bold" id="nav-reviews-tab" data-bs-toggle="tab" data-bs-target="#nav-reviews" type="button" role="tab">Reviews ({{ $farmerReviews->count() + $productReviews->count() }})</button>
                    </div>
                </nav>
                <div class="tab-content p-4 border border-top-0 rounded-bottom bg-white" id="nav-tabContent">
                    <!-- Description -->
                    <div class="tab-pane fade show active" id="nav-desc" role="tabpanel">
                        <h5 class="fw-bold">Product Information</h5>
                        <p>{{ $product->description ?: 'No extra product information has been provided by the farmer.' }}</p>
                        <ul class="mb-0">
                            <li>Category: {{ $product->category }}</li>
                            <li>Unit: {{ $product->unit }}</li>
                            <li>Sold by: {{ $farmer?->displayName() ?? 'Local Farm' }}</li>
                            <li>Stock on hand: {{ $product->stock }} {{ $product->unit }}</li>
                        </ul>
                    </div>

                    <!-- Pickup Info -->
                    <div class="tab-pane fade" id="nav-pickup" role="tabpanel">
                        <h5 class="fw-bold mb-3">Pickup Locations &amp; Times</h5>
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead class="table-light">
                                    <tr>
                                        <th>Market</th>
                                        <th>City</th>
                                        <th>Days</th>
                                        <th>Pickup windows</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @forelse($farmer?->markets()->get() ?? [] as $market)
                                        <tr>
                                            <td>{{ $market->name }}</td>
                                            <td>{{ $market->city ?: '—' }}</td>
                                            <td>{{ $market->daysLabel() }}</td>
                                            <td>{{ $farmer->pickup_windows ? implode(' • ', $farmer->pickup_windows) : '—' }}</td>
                                        </tr>
                                    @empty
                                        <tr><td colspan="4" class="text-muted">No pickup market has been linked by this farmer yet.</td></tr>
                                    @endforelse
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <!-- Reviews -->
                    <div class="tab-pane fade" id="nav-reviews" role="tabpanel">
                        <div class="row">
                            <div class="col-md-4 text-center mb-4 border-end">
                                <h6 class="text-muted text-uppercase small mb-1">This product</h6>
                                <h1 class="display-4 fw-bold text-dark mb-0">{{ $productRating ? number_format($productRating, 1) : '—' }}</h1>
                                <div class="text-warning mb-2">
                                    @php($prStars = (int) round($productRating ?? 0))
                                    @for($i = 1; $i <= 5; $i++)
                                        <i class="fa{{ $i <= $prStars ? 's' : 'r' }} fa-star"></i>
                                    @endfor
                                </div>
                                <p class="text-muted small mb-3">{{ $productReviews->count() }} rating{{ $productReviews->count() === 1 ? '' : 's' }} from completed orders</p>
                                <hr>
                                <h6 class="text-muted text-uppercase small mb-1">The stall</h6>
                                <h3 class="fw-bold text-dark mb-0">{{ $farmer?->averageRating() ? number_format($farmer->averageRating(), 1) : '—' }}</h3>
                                <p class="text-muted small mb-0">{{ $farmerReviews->count() }} stall review{{ $farmerReviews->count() === 1 ? '' : 's' }}</p>
                            </div>
                            <div class="col-md-8">
                                <h6 class="fw-bold mb-3">Ratings for this product ({{ $productReviews->count() }})</h6>
                                @forelse($productReviews as $review)
                                    <div class="border-bottom pb-3 mb-3">
                                        <div class="d-flex justify-content-between">
                                            <strong>{{ $review->customer?->name ?? 'Client' }}</strong>
                                            <small class="text-muted">{{ $review->created_at?->format('M d, Y') }}</small>
                                        </div>
                                        <div class="text-warning small mb-2">
                                            @for($i = 1; $i <= 5; $i++)
                                                <i class="fa{{ $i <= $review->rating ? 's' : 'r' }} fa-star"></i>
                                            @endfor
                                        </div>
                                        <p class="text-muted mb-1">{{ $review->comment ?: 'No comment left.' }}</p>
                                        @if($review->hasReply())
                                            <div class="p-2 bg-light rounded-3">
                                                <small class="fw-bold d-block"><i class="fas fa-reply text-success me-1"></i>{{ $farmer?->displayName() }} replied</small>
                                                <small class="text-muted">{{ $review->farmer_reply }}</small>
                                            </div>
                                        @endif
                                    </div>
                                @empty
                                    <p class="text-muted">This product has no ratings yet — buyers rate it after a completed pickup.</p>
                                @endforelse

                                <h6 class="fw-bold mt-4 mb-3">Stall reviews ({{ $farmerReviews->count() }})</h6>
                                @forelse($farmerReviews as $review)
                                    <div class="border-bottom pb-3 mb-3">
                                        <div class="d-flex justify-content-between">
                                            <strong>{{ $review->customer?->name ?? 'Client' }}</strong>
                                            <small class="text-muted">{{ $review->created_at?->format('M d, Y') }}</small>
                                        </div>
                                        <div class="text-warning small mb-2">
                                            @for($i = 1; $i <= 5; $i++)
                                                <i class="fa{{ $i <= $review->rating ? 's' : 'r' }} fa-star"></i>
                                            @endfor
                                        </div>
                                        <p class="text-muted mb-1">{{ $review->comment ?: 'No comment left.' }}</p>
                                        @if($review->hasReply())
                                            <div class="p-2 bg-light rounded-3">
                                                <small class="fw-bold d-block"><i class="fas fa-reply text-success me-1"></i>{{ $farmer?->displayName() }} replied</small>
                                                <small class="text-muted">{{ $review->farmer_reply }}</small>
                                            </div>
                                        @endif
                                    </div>
                                @empty
                                    <p class="text-muted">No reviews for this stall yet.</p>
                                @endforelse
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Related Products -->
        <div class="row">
            <div class="col-12">
                <h4 class="fw-bold mb-4">More in {{ $product->category }}</h4>
                <div class="row g-4">
                    @forelse($related as $item)
                        <div class="col-6 col-md-3">
                            <div class="card h-100 border-0 shadow-sm">
                                <img src="{{ $item->imageUrl() }}" class="card-img-top" style="height:160px;object-fit:cover" alt="{{ $item->name }}">
                                <div class="card-body">
                                    <h6 class="card-title fw-bold"><a href="/product-details?id={{ $item->id }}" class="text-dark text-decoration-none">{{ $item->name }}</a></h6>
                                    <p class="text-muted small mb-1">{{ $item->farmer?->displayName() }}</p>
                                    <p class="text-success mb-0">Rs {{ number_format((float) $item->price, 0) }} / {{ $item->unit }}</p>
                                </div>
                            </div>
                        </div>
                    @empty
                        <div class="col-12 text-muted">No other products in this category.</div>
                    @endforelse
                </div>
            </div>
        </div>
    </div>
@endif
@endsection

@push('scripts')
<script>
    /* Live catalogue for the quick-view widgets (real DB rows only). */
    window.ML = window.ML || {};
    window.ML.products = window.ML.products || @json($products ?? []);
</script>
@endpush
