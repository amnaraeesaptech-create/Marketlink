@extends('layouts.app')

@section('title', 'Pre-Order - MarketLink')

@section('no-navbar', '1')

@section('content')
<!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top">
        <div class="container">
            <a class="navbar-brand fw-bold text-success" href="/"><i class="fas fa-leaf me-2"></i>MarketLink</a>
        </div>
    </nav>

    <div class="container py-5">
        <div class="text-center mb-4">
            <h2 class="fw-bold">Place Your Pre-Order</h2>
        </div>

        <!-- Step Indicator -->
        <div class="step-indicator">
            <div class="step completed">
                <div class="step-icon"><i class="fas fa-check"></i></div>
                <span>Cart</span>
            </div>
            <div class="step-line bg-success"></div>
            <div class="step active" id="step2-indicator">
                <div class="step-icon">2</div>
                <span>Pre-Order Details</span>
            </div>
            <div class="step-line"></div>
            <div class="step" id="step3-indicator">
                <div class="step-icon">3</div>
                <span>My Orders</span>
            </div>
        </div>

        <div class="row" id="main-content">
            <!-- Left: Form -->
            <div class="col-lg-7 mb-4">
                <form id="preorder-form" action="/preorder" method="POST" class="card border-0 shadow-sm p-4">
                    @csrf
                    <input type="hidden" name="items_json" id="items-json" value="[]">

                    <h5 class="fw-bold border-bottom pb-2 mb-4">Customer Information</h5>
                    <div class="row g-3 mb-4">
                        <div class="col-md-6">
                            <label class="form-label">Full Name</label>
                            <input type="text" class="form-control" value="{{ auth()->user()->name }}" readonly title="From your profile">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Contact Number</label>
                            <input type="tel" class="form-control" value="{{ auth()->user()->phone }}" readonly title="From your profile">
                        </div>
                        <div class="col-12">
                            <label class="form-label">Email Address</label>
                            <input type="email" class="form-control" value="{{ auth()->user()->email }}" readonly title="From your profile">
                        </div>
                    </div>

                    <h5 class="fw-bold border-bottom pb-2 mb-4">Pickup Details</h5>
                    <div class="row g-3 mb-4">
                        <div class="col-12" id="market-select-wrap">
                            {{-- Populated by JS below based on cart contents --}}
                            {{-- Fallback for non-JS: show full dropdown --}}
                            <noscript>
                                <label class="form-label">Select Pickup Market</label>
                                <select class="form-select" name="market">
                                    <option value="" selected disabled>Choose a market...</option>
                                    @foreach($markets ?? [] as $market)
                                        <option value="{{ $market->name }}">{{ $market->name }}@if($market->city) — {{ $market->city }}@endif</option>
                                    @endforeach
                                </select>
                            </noscript>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Select Pickup Date *</label>
                            <input type="date" class="form-control @error('pickup_date') is-invalid @enderror" id="pickup-date" name="pickup_date" value="{{ old('pickup_date') }}" required>
                            @error('pickup_date')<div class="invalid-feedback d-block">{{ $message }}</div>@enderror
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Select Time Slot</label>
                            <select class="form-select @error('pickup_slot') is-invalid @enderror" name="pickup_slot" id="pickup-slot">
                                <option value="" selected disabled>Choose time...</option>
                                {{-- Options populated dynamically by JS from farmer pickup_windows --}}
                                <option value="8:00 AM - 9:00 AM" {{ old('pickup_slot') === '8:00 AM - 9:00 AM' ? 'selected' : '' }}>8:00 AM - 9:00 AM</option>
                                <option value="9:00 AM - 10:00 AM" {{ old('pickup_slot') === '9:00 AM - 10:00 AM' ? 'selected' : '' }}>9:00 AM - 10:00 AM</option>
                                <option value="10:00 AM - 11:00 AM" {{ old('pickup_slot') === '10:00 AM - 11:00 AM' ? 'selected' : '' }}>10:00 AM - 11:00 AM</option>
                                <option value="11:00 AM - 12:00 PM" {{ old('pickup_slot') === '11:00 AM - 12:00 PM' ? 'selected' : '' }}>11:00 AM - 12:00 PM</option>
                            </select>
                            @error('pickup_slot')<div class="invalid-feedback d-block">{{ $message }}</div>@enderror
                        </div>
                        <div class="col-12">
                            <label class="form-label">Special Notes (Optional)</label>
                            <textarea class="form-control" name="notes" rows="2" placeholder="e.g., I will send my brother to pick up.">{{ old('notes') }}</textarea>
                        </div>
                    </div>

                    <div class="alert alert-warning d-flex align-items-center mb-4" role="alert">
                        <i class="fas fa-wallet fs-4 me-3"></i>
                        <div>
                            <strong>Payment Notice:</strong> Payment will be made in person at the pickup location directly to the farmer. No online payment required.
                        </div>
                    </div>

                    <button type="submit" class="btn btn-success btn-lg w-100 fw-bold" id="place-order-btn">Place Pre-Order</button>
                </form>
            </div>

            <!-- Right: Summary -->
            <div class="col-lg-5">
                <div class="card border-0 shadow-sm sticky-top" style="top: 90px;">
                    <div class="card-body p-4 bg-light rounded">
                        <h4 class="fw-bold mb-4">Order Summary</h4>

                        <div id="order-items-list" class="mb-4">
                            <!-- Items from your real cart -->
                        </div>

                        <hr>

                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Subtotal</span>
                            <span class="fw-medium" id="summary-subtotal">Rs 0</span>
                        </div>
                        <div class="d-flex justify-content-between mb-4">
                            <span class="fw-bold fs-5">Total to Pay at Pickup</span>
                            <span class="fw-bold fs-4 text-success" id="summary-total">Rs 0</span>
                        </div>

                        <div class="p-3 bg-white border rounded">
                            <h6 class="fw-bold mb-2"><i class="fas fa-box me-2 text-success"></i>Pre-Order Info</h6>
                            <ul class="list-unstyled small text-muted mb-0">
                                <li class="mb-1">&bull; Items from different stalls become separate orders.</li>
                                <li class="mb-1">&bull; Bring order ID to the market.</li>
                                <li>&bull; Pay directly at each farmer's stall.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('scripts')
<script>
        // Set min date for date picker to today
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('pickup-date').setAttribute('min', today);

        // Farmer pickup windows from DB, keyed by farmer_id (string)
        const FARMER_WINDOWS = @json($farmerWindows ?? []);
        const DEFAULT_SLOTS = [
            '8:00 AM - 9:00 AM',
            '9:00 AM - 10:00 AM',
            '10:00 AM - 11:00 AM',
            '11:00 AM - 12:00 PM'
        ];
        const OLD_SLOT = "{{ old('pickup_slot') }}";

        function populateSlots() {
            const cart = (window.getCart && window.getCart()) || [];
            const mlProducts = (window.ML && window.ML.products) || [];

            // Resolve farmer IDs — stored farmer_id first, then ML feed fallback
            const farmerIds = [...new Set(
                cart.map(i => {
                    if (i.farmer_id) return String(i.farmer_id);
                    const mlProd = mlProducts.find(p => String(p.id) === String(i.id));
                    return mlProd ? String(mlProd.farmerId || '') : '';
                }).filter(Boolean)
            )];

            // Get selected pickup date's 3-char day abbreviation (Mon, Tue, ...)
            const dateEl = document.getElementById('pickup-date');
            const dateVal = dateEl && dateEl.value;
            const DAY3  = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
            const DFULL = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
            let selectedDay3 = null, selectedDayFull = null;
            if (dateVal) {
                const d = new Date(dateVal + 'T00:00:00');
                selectedDay3    = DAY3[d.getDay()];
                selectedDayFull = DFULL[d.getDay()];
            }

            let slots = [];
            farmerIds.forEach(fid => {
                const windows = FARMER_WINDOWS[fid] || [];
                windows.forEach(w => {
                    // w is now {day, label, start, end} from normalizedPickupWindows()
                    const label = (typeof w === 'object') ? (w.label || '') : String(w);
                    if (!label) return;

                    // If a date is selected and the window has a day tag, filter by day
                    if (selectedDay3 && w.day) {
                        const wDay3 = String(w.day).substring(0, 3);
                        if (wDay3 !== selectedDay3 && w.day !== selectedDayFull) return;
                    }
                    if (!slots.includes(label)) slots.push(label);
                });
            });

            // Fall back to defaults if no windows match
            if (!slots.length) slots = DEFAULT_SLOTS;

            const sel = document.getElementById('pickup-slot');
            if (!sel) return;

            sel.innerHTML = '<option value="" disabled selected>Choose time...</option>'
                + slots.map(s => {
                    const selected = (OLD_SLOT === s) ? ' selected' : '';
                    return `<option value="${s}"${selected}>${s}</option>`;
                }).join('');

            // Auto-select if only one slot available
            if (!OLD_SLOT && slots.length === 1) sel.value = slots[0];
        }

        // Re-run slots whenever the date changes (day-of-week filtering)
        document.getElementById('pickup-date')?.addEventListener('change', populateSlots);

        // Render REAL cart items (from localStorage cart)
        const cart = (window.getCart && window.getCart()) || [];
        const list = document.getElementById('order-items-list');
        const fmtRs = (n) => 'Rs ' + (parseFloat(n) || 0).toLocaleString('en-PK', {maximumFractionDigits: 0});
        if (!cart.length) {
            list.innerHTML = '<div class="text-center py-4"><i class="fas fa-basket-shopping fa-2x text-muted mb-2"></i>' +
                '<p class="text-muted mb-2">Your cart is empty.</p>' +
                '<a href="/products" class="btn btn-sm btn-success">Browse Products</a></div>';
            document.getElementById('place-order-btn').disabled = true;
        } else {
            let total = 0;
            cart.forEach(item => {
                const sub = (parseFloat(item.price) || 0) * (item.quantity || 0);
                total += sub;
                const div = document.createElement('div');
                div.className = 'd-flex justify-content-between mb-3 border-bottom pb-2';
                div.innerHTML =
                    '<div><h6 class="mb-0 fw-bold">' + (item.quantity || 0) + 'x ' + item.name + '</h6></div>' +
                    '<span class="fw-medium">' + fmtRs(sub) + '</span>';
                list.appendChild(div);
            });
            document.getElementById('summary-subtotal').textContent = fmtRs(total);
            document.getElementById('summary-total').textContent = fmtRs(total);
        }

        // Populate slots: run immediately, then again once the ML data feed
        // has loaded (it loads async via <script src="/data-feed.js">)
        populateSlots();
        document.addEventListener('DOMContentLoaded', populateSlots);
        window.addEventListener('load', populateSlots);
        // If data-feed.js loads after window.load (cached), repopulate when ML appears
        (function waitForML(tries) {
            if (window.ML && window.ML.products && window.ML.products.length) {
                populateSlots();
            } else if (tries > 0) {
                setTimeout(function() { waitForML(tries - 1); }, 200);
            }
        })(15);

        // Attach cart items to the real form submit
        document.getElementById('preorder-form').addEventListener('submit', function(e) {
            const items = (window.getCart && window.getCart()) || [];
            if (!items.length) {
                e.preventDefault();
                if (window.showToast) window.showToast('Your cart is empty.', 'info');
                return;
            }
            document.getElementById('items-json').value = JSON.stringify(items.map(i => ({id: i.id, qty: i.quantity})));
        });

        // ----- Auto-lock market from cart context -----
        (function () {
            var wrap = document.getElementById('market-select-wrap');
            if (!wrap) return;

            var cart   = (window.getCart && window.getCart()) || [];
            var oldMkt = "{{ old('market') }}";

            // Collect distinct markets stored in cart items
            var markets = [...new Set(cart.map(i => i.market).filter(Boolean))];

            // Also check sessionStorage for the shopping market set on /products
            var sessionMkt = null;
            try { sessionMkt = sessionStorage.getItem('ml_shopping_market'); } catch(e) {}
            if (!markets.length && sessionMkt) markets = [sessionMkt];

            var allMarkets = @json($markets->map(fn($m) => [
                'name' => $m->name,
                'city' => $m->city,
                'lat'  => (float) ($m->latitude ?? 0),
                'lng'  => (float) ($m->longitude ?? 0),
            ])->values());

            if (markets.length === 1) {
                // ✅ All items from one market — lock it, no dropdown
                var mkt = markets[0];
                wrap.innerHTML =
                    '<label class="form-label fw-medium">Pickup Market</label>' +
                    '<div class="alert alert-success d-flex align-items-center gap-2 py-2 mb-0">' +
                    '  <i class="fas fa-store text-success"></i>' +
                    '  <span>Pickup at <strong>' + mkt + '</strong></span>' +
                    '  <a href="/products" class="ms-auto small text-success text-decoration-none">' +
                    '    <i class="fas fa-exchange-alt me-1"></i>Change market</a>' +
                    '</div>' +
                    '<input type="hidden" name="market" value="' + mkt + '">';

            } else if (markets.length > 1) {
                // ⚠️ Cart spans multiple markets — warn + let them pick
                var opts = markets.map(m => '<option value="' + m + '"' + (m === oldMkt ? ' selected' : '') + '>' + m + '</option>').join('');
                wrap.innerHTML =
                    '<label class="form-label fw-medium">Pickup Market</label>' +
                    '<div class="alert alert-warning small py-2 mb-2">' +
                    '  <i class="fas fa-exclamation-triangle me-1"></i>' +
                    '  Your cart has items from ' + markets.length + ' different markets. Pick the one you\'ll collect from.' +
                    '</div>' +
                    '<select class="form-select" name="market">' +
                    '<option value="" disabled' + (oldMkt ? '' : ' selected') + '>Choose a market...</option>' +
                    opts + '</select>';

            } else {
                // No market context — full dropdown with Near Me sort
                var opts2 = allMarkets.map(function(m) {
                    return '<option value="' + m.name + '"' +
                        (m.name === oldMkt ? ' selected' : '') +
                        ' data-lat="' + m.lat + '" data-lng="' + m.lng + '" data-city="' + m.city + '">' +
                        m.name + (m.city ? ' \u2014 ' + m.city : '') + '</option>';
                }).join('');

                wrap.innerHTML =
                    '<label class="form-label d-flex justify-content-between align-items-center fw-medium">' +
                    '  <span>Select Pickup Market</span>' +
                    '  <button type="button" id="preorderNearMe" class="btn btn-sm btn-outline-success py-0 px-2">' +
                    '    <i class="fas fa-location-arrow me-1"></i>Near Me</button>' +
                    '</label>' +
                    '<select class="form-select" name="market" id="market-select">' +
                    '<option value="" disabled' + (oldMkt ? '' : ' selected') + '>Choose a market...</option>' +
                    opts2 + '</select>';

                // Wire Near Me to sort the freshly-rendered select
                var nearBtn = document.getElementById('preorderNearMe');
                var sel     = document.getElementById('market-select');

                function sortByDist(lat, lng) {
                    var opts = Array.from(sel.options).filter(o => o.value);
                    opts.forEach(function(o) {
                        var olat = parseFloat(o.dataset.lat), olng = parseFloat(o.dataset.lng);
                        if (olat && olng) {
                            o.dataset.dist = window.MLGeo.haversine(lat, lng, olat, olng);
                            o.textContent = o.value + (o.dataset.city ? ' \u2014 ' + o.dataset.city : '')
                                + '  (' + window.MLGeo.fmtDist(parseFloat(o.dataset.dist)) + ')';
                        } else { o.dataset.dist = '99999'; }
                    });
                    opts.sort((a,b) => parseFloat(a.dataset.dist) - parseFloat(b.dataset.dist));
                    var ph = sel.options[0];
                    opts.forEach(o => sel.appendChild(o));
                    sel.insertBefore(ph, sel.firstChild);
                    nearBtn.classList.replace('btn-outline-success','btn-success');
                }

                if (nearBtn) {
                    nearBtn.addEventListener('click', function() {
                        nearBtn.disabled = true;
                        nearBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>Locating…';
                        window.MLGeo.getLocation(
                            function(lat, lng) { nearBtn.disabled=false; nearBtn.innerHTML='<i class="fas fa-location-arrow me-1"></i>Near Me'; sortByDist(lat, lng); },
                            function()         { nearBtn.disabled=false; nearBtn.innerHTML='<i class="fas fa-location-arrow me-1"></i>Near Me'; }
                        );
                    });
                }

                // Auto-sort if location already cached
                (function() {
                    var loc = null;
                    try { loc = JSON.parse(sessionStorage.getItem('ml_user_loc')); } catch(e) {}
                    if (loc && loc.lat && loc.lng) sortByDist(loc.lat, loc.lng);
                })();
            }
        })();
    </script>
@endpush
