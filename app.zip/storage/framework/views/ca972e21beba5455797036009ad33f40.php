<?php $__env->startSection('title', 'MarketLink - Farmer Orders'); ?>

<?php $__env->startSection('content'); ?>
<div class="dashboard-layout">
    <!-- Sidebar -->
    <aside class="ml-sidebar ml-sidebar-farmer" id="sidebar">
      <div class="ml-sidebar-header">
        <a href="/" class="ml-sidebar-brand"><i class="fas fa-seedling"></i> MarketLink</a>
        <button class="ml-sidebar-close d-lg-none" id="sidebarClose"><i class="fas fa-times"></i></button>
      </div>
      <div class="ml-sidebar-user">
        <img src="<?php echo e(auth()->user()->avatarUrl()); ?>" alt="Farmer" class="ml-sidebar-avatar">
        <div>
          <div class="ml-sidebar-username"><?php echo e(auth()->user()->displayName()); ?></div>
          <div class="ml-sidebar-role">Farmer</div>
        </div>
      </div>
      <nav class="ml-sidebar-nav">
        <a href="/farmer-dashboard" class="ml-sidebar-link"><i class="fas fa-chart-pie"></i> Dashboard</a>
        <a href="/farmer-profile" class="ml-sidebar-link"><i class="fas fa-user-edit"></i> My Profile</a>
        <a href="/farmer-products" class="ml-sidebar-link"><i class="fas fa-box"></i> Products</a>
        <a href="/farmer-add-product" class="ml-sidebar-link"><i class="fas fa-plus-circle"></i> Add Product</a>
        <a href="/farmer-products" class="ml-sidebar-link"><i class="fas fa-warehouse"></i> Inventory</a>
        <a href="/farmer-orders" class="ml-sidebar-link active"><i class="fas fa-shopping-bag"></i> Orders</a>
        <a href="/farmer-profile/edit" class="ml-sidebar-link"><i class="fas fa-clock"></i> Pickup Slots</a>
        <a href="/farmer-reviews" class="ml-sidebar-link"><i class="fas fa-star"></i> Reviews</a>
        <a href="/farmer-stock-template" class="ml-sidebar-link"><i class="fas fa-layer-group"></i> Weekly Stock</a>
        <a href="/notifications" class="ml-sidebar-link"><i class="fas fa-bell"></i> Notifications</a>
        <a href="/farmer-orders" class="ml-sidebar-link"><i class="fas fa-chart-bar"></i> Sales History</a>
        <hr class="ml-sidebar-divider">
        <form action="/logout" method="POST">
            <?php echo csrf_field(); ?>
            <button type="submit" class="ml-sidebar-link ml-sidebar-logout w-100 border-0 bg-transparent text-start"><i class="fas fa-sign-out-alt"></i> Logout</button>
        </form>
      </nav>
    </aside>

    <!-- Main Content -->
    <div class="dashboard-main">
      <div class="dashboard-topbar">
        <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
        <div class="d-flex align-items-center gap-3">
          <button class="btn btn-light position-relative" type="button">
            <i class="fas fa-bell"></i>
          </button>
          <img src="<?php echo e(auth()->user()->avatarUrl()); ?>" alt="User" class="rounded-circle border" width="40" height="40" style="object-fit: cover;">
        </div>
      </div>

      <div class="dashboard-content">

        <!-- Header & Tabs -->
        <div class="order-header-section">
          <h2 class="h4 fw-bold mb-0">Order Management</h2>
          <p class="text-muted mb-3">Manage pre-orders and pickups from your customers.</p>

          <ul class="nav nav-tabs order-tabs border-0 gap-2">
            <li class="nav-item">
                <a class="nav-link rounded-pill px-3 py-2 order-tab" data-status="" href="/farmer-orders">
                  All Orders
                  <span class="badge bg-light text-dark ms-1 rounded-pill"><?php echo e($countsAll ?? 0); ?></span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link rounded-pill px-3 py-2 order-tab" data-status="pending" href="/farmer-orders?status=pending">
                  Pending
                  <span class="badge bg-light text-dark ms-1 rounded-pill"><?php echo e($countsPending ?? 0); ?></span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link rounded-pill px-3 py-2 order-tab" data-status="confirmed" href="/farmer-orders?status=confirmed">
                  Accepted
                  <span class="badge bg-light text-dark ms-1 rounded-pill"><?php echo e($countsConfirmed ?? 0); ?></span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link rounded-pill px-3 py-2 order-tab" data-status="ready" href="/farmer-orders?status=ready">
                  Ready
                  <span class="badge bg-light text-dark ms-1 rounded-pill"><?php echo e($countsReady ?? 0); ?></span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link rounded-pill px-3 py-2 order-tab" data-status="completed" href="/farmer-orders?status=completed">
                  Completed
                  <span class="badge bg-light text-dark ms-1 rounded-pill"><?php echo e($countsCompleted ?? 0); ?></span>
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link rounded-pill px-3 py-2 order-tab" data-status="cancelled" href="/farmer-orders?status=cancelled">
                  Cancelled
                  <span class="badge bg-light text-dark ms-1 rounded-pill"><?php echo e($countsCancelled ?? 0); ?></span>
                </a>
              </li>
          </ul>

          <!-- Search Row -->
          <form method="GET" action="/farmer-orders" class="d-flex flex-wrap gap-2 mt-3 mb-4">
            <input type="hidden" name="status" value="<?php echo e($status ?? ''); ?>">
            <div class="input-group" style="max-width: 350px;">
              <span class="input-group-text bg-white border-end-0"><i class="fas fa-search text-muted"></i></span>
              <input type="text" name="search" class="form-control border-start-0" placeholder="Search order ID or customer..." value="<?php echo e($search ?? ''); ?>">
            </div>
            <input type="date" name="date" class="form-control" style="max-width: 170px;" value="<?php echo e($date ?? ''); ?>" onchange="this.form.submit()">
            <button type="submit" class="btn btn-success px-4">Search</button>
            <a href="/farmer-orders" class="btn btn-light border">Clear</a>
          </form>
        </div>

        <!-- Orders List -->
        <?php $__empty_1 = true; $__currentLoopData = $orders ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="card order-card border-0 shadow-sm rounded-3 mb-4">
          <!-- Top Row: ID, Customer, Status -->
          <div class="card-header bg-white border-bottom p-3 d-flex justify-content-between align-items-center flex-wrap gap-2">
            <div class="d-flex align-items-center gap-3">
              <div>
                <span class="fw-bold fs-6"><?php echo e($o->code()); ?></span>
                <span class="text-muted small ms-2"><i class="far fa-clock"></i> <?php echo e($o->created_at->diffForHumans()); ?></span>
              </div>
              <div class="d-flex align-items-center gap-2 ms-2 border-start ps-3">
                <img src="<?php echo e($o->customer->avatarUrl()); ?>" class="rounded-circle" width="32" height="32" alt="C" style="object-fit: cover;">
                <span class="fw-medium small"><?php echo e($o->customer->name); ?></span>
              </div>
            </div>
            <span class="badge <?php echo e($o->statusBadge()); ?> px-3 py-2 rounded-pill"><?php echo e($o->statusLabel()); ?></span>
          </div>

          <!-- Middle Row: Items & Details -->
          <div class="card-body p-4">
            <div class="row g-4">
              <!-- Items -->
              <div class="col-md-7">
                <h6 class="fw-bold mb-3 text-uppercase small text-muted">Order Items (<?php echo e($o->items->count()); ?>)</h6>
                <?php $__currentLoopData = $o->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="d-flex align-items-center gap-3 mb-3 p-2 bg-light rounded-3">
                    <img src="<?php echo e($it->product ? $it->product->imageUrl() : \App\Support\Placeholder::image($it->name)); ?>" class="rounded-2" width="60" height="60" alt="Item" style="object-fit: cover;">
                    <div class="flex-grow-1">
                      <div class="fw-medium"><?php echo e($it->name); ?></div>
                      <small class="text-muted"><?php echo e($it->qty); ?> <?php echo e($it->unit); ?> &times; PKR <?php echo e(number_format($it->price, 0)); ?></small>
                    </div>
                    <div class="fw-bold">PKR <?php echo e(number_format($it->price * $it->qty, 0)); ?></div>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>

              <!-- Pickup Info -->
              <div class="col-md-5">
                <h6 class="fw-bold mb-3 text-uppercase small text-muted">Pickup Details</h6>
                <div class="bg-light p-3 rounded-3 h-100">
                  <div class="mb-2 small"><i class="fas fa-calendar-alt text-success me-2"></i> <?php echo e($o->pickup_date ? \Carbon\Carbon::parse($o->pickup_date)->format('l, M d') : '—'); ?></div>
                  <div class="mb-2 small"><i class="fas fa-clock text-success me-2"></i> <?php echo e($o->pickup_slot ?? '—'); ?></div>
                  <div class="small"><i class="fas fa-map-marker-alt text-success me-2"></i> <?php echo e($o->market ?? '—'); ?></div>
                  <hr class="my-2">
                  <div class="d-flex justify-content-between fw-bold">
                    <span>Total</span>
                    <span class="text-success">PKR <?php echo e(number_format($o->subtotal, 0)); ?></span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <!-- Bottom Row: Actions -->
          <div class="card-footer bg-white border-top p-3 d-flex justify-content-between align-items-center flex-wrap gap-2">
            <a href="/order-details?id=<?php echo e($o->id); ?>" class="btn btn-outline-secondary btn-sm"><i class="fas fa-eye me-1"></i> View Details</a>
            <div class="d-flex gap-2 flex-wrap">
              <?php if($o->status === 'pending'): ?>
                <form action="/farmer-orders/<?php echo e($o->id); ?>/status" method="POST" class="d-inline">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="status" value="confirmed">
                  <button type="submit" class="btn btn-success btn-sm px-4"><i class="fas fa-check me-1"></i> Confirm Order</button>
                </form>
                <form action="/farmer-orders/<?php echo e($o->id); ?>/status" method="POST" class="d-inline" onsubmit="return confirm('Decline this order? Stock will be returned.')">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="status" value="cancelled">
                  <button type="submit" class="btn btn-light border btn-sm text-danger px-3">Decline</button>
                </form>
              <?php elseif($o->status === 'confirmed'): ?>
                <form action="/farmer-orders/<?php echo e($o->id); ?>/status" method="POST" class="d-inline">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="status" value="ready">
                  <button type="submit" class="btn btn-primary btn-sm px-4"><i class="fas fa-bell me-1"></i> Mark as Ready</button>
                </form>
                <form action="/farmer-orders/<?php echo e($o->id); ?>/status" method="POST" class="d-inline" onsubmit="return confirm('Cancel this order? Stock will be returned.')">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="status" value="cancelled">
                  <button type="submit" class="btn btn-light border btn-sm text-danger px-3">Cancel</button>
                </form>
              <?php elseif($o->status === 'ready'): ?>
                <form action="/farmer-orders/<?php echo e($o->id); ?>/status" method="POST" class="d-inline">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="status" value="completed">
                  <button type="submit" class="btn btn-success btn-sm px-4"><i class="fas fa-check-double me-1"></i> Mark as Completed</button>
                </form>
                <form action="/farmer-orders/<?php echo e($o->id); ?>/status" method="POST" class="d-inline" onsubmit="return confirm('Cancel this order? Stock will be returned.')">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="status" value="cancelled">
                  <button type="submit" class="btn btn-light border btn-sm text-danger px-3">Cancel</button>
                </form>
              <?php elseif($o->status === 'completed'): ?>
                <span class="text-success small fw-medium"><i class="fas fa-check-circle me-1"></i> Completed &amp; paid at pickup</span>
              <?php else: ?>
                <span class="text-muted small fw-medium"><i class="fas fa-ban me-1"></i> Order cancelled</span>
              <?php endif; ?>
            </div>
          </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="card order-card border-0 shadow-sm rounded-3 mb-4">
          <div class="card-body text-center py-5 text-muted">
            <i class="fas fa-shopping-bag fa-2x mb-3 d-block"></i>
            No orders found for the selected filter.
          </div>
        </div>
        <?php endif; ?>

      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', () => {
      const sidebar = document.getElementById('sidebar');
      const sidebarToggle = document.getElementById('sidebarToggle');
      const sidebarClose = document.getElementById('sidebarClose');
      if (sidebarToggle) sidebarToggle.addEventListener('click', () => sidebar.classList.add('show'));
      if (sidebarClose) sidebarClose.addEventListener('click', () => sidebar.classList.remove('show'));
      var curStatus = new URLSearchParams(window.location.search).get('status') || '';
      document.querySelectorAll('.order-tab').forEach(function (a) {
        if ((a.getAttribute('data-status') || '') !== curStatus) return;
        a.classList.add('active');
        if (a.classList.contains('bg-white')) { a.classList.remove('bg-white', 'text-dark', 'border'); a.classList.add('bg-success', 'text-white'); }
        var b = a.querySelector('.badge');
        if (b) { b.classList.remove('bg-light', 'text-dark'); b.classList.add('bg-white', 'text-success'); }
      });
    });
  </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\techproject\project\marketlink-final\resources\views/farmer/orders.blade.php ENDPATH**/ ?>