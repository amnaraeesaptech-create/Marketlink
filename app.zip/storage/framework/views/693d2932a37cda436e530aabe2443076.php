<!-- Navbar -->
<nav class="navbar navbar-expand-lg ml-navbar sticky-top">
    <div class="container">
        <a class="navbar-brand ml-brand" href="/">
            <i class="fas fa-seedling"></i> MarketLink
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMain"
                aria-controls="navbarMain" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarMain">
            <ul class="navbar-nav mx-auto mb-2 mb-lg-0">
                <li class="nav-item"><a class="nav-link <?php echo e(request()->is('/') ? 'active' : ''); ?>" href="/">Home</a></li>
                <li class="nav-item"><a class="nav-link <?php echo e(request()->is('markets*') ? 'active' : ''); ?>" href="/markets">Markets</a></li>
                <li class="nav-item"><a class="nav-link <?php echo e(request()->is('farmers*') ? 'active' : ''); ?>" href="/farmers">Farmers</a></li>
                <li class="nav-item"><a class="nav-link <?php echo e(request()->is('products*') ? 'active' : ''); ?>" href="/products">Products</a></li>
                <li class="nav-item"><a class="nav-link <?php echo e(request()->is('about') ? 'active' : ''); ?>" href="/about">About</a></li>
                <li class="nav-item"><a class="nav-link <?php echo e(request()->is('contact') ? 'active' : ''); ?>" href="/contact">Contact</a></li>
            </ul>
            <div class="d-flex align-items-center gap-2">
                <a href="/cart" class="ml-cart-btn" id="cartNavBtn" aria-label="Shopping Cart">
                    <i class="fas fa-shopping-basket"></i>
                    <span class="ml-cart-badge" id="cartBadge">0</span>
                </a>
                <?php if(auth()->guard()->check()): ?>
                    <?php ($bellUnread = auth()->user()->alerts()->whereNull('read_at')->count()); ?>
                    <?php ($bellLatest = auth()->user()->alerts()->latest()->take(5)->get()); ?>
                    <div class="dropdown">
                        <button class="ml-cart-btn" type="button" data-bs-toggle="dropdown" aria-expanded="false" aria-label="Notifications">
                            <i class="fas fa-bell"></i>
                            <?php if($bellUnread): ?>
                                <span class="ml-cart-badge bg-danger"><?php echo e($bellUnread); ?></span>
                            <?php endif; ?>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end shadow ml-notif-menu">
                            <li class="dropdown-header d-flex justify-content-between align-items-center">
                                <span>Notifications</span>
                                <?php if($bellUnread): ?><span class="badge bg-danger"><?php echo e($bellUnread); ?> new</span><?php endif; ?>
                            </li>
                            <?php $__empty_1 = true; $__currentLoopData = $bellLatest; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <li>
                                    <a class="dropdown-item py-2 <?php echo e($note->isUnread() ? 'ml-notif-unread' : ''); ?>" href="/notifications/<?php echo e($note->id); ?>/read?_token=<?php echo e(csrf_token()); ?>" onclick="event.preventDefault(); this.closest('li').querySelector('form') ? this.closest('li').querySelector('form').submit() : window.location.href='/notifications';">
                                        <div class="d-flex gap-2">
                                            <i class="fas <?php echo e($note->icon()); ?> text-success mt-1"></i>
                                            <div class="small">
                                                <div class="fw-semibold"><?php echo e(Str::limit($note->title, 42)); ?></div>
                                                <div class="text-muted"><?php echo e(Str::limit($note->body, 55)); ?></div>
                                                <div class="text-muted" style="font-size:.72rem;"><?php echo e($note->created_at->diffForHumans()); ?></div>
                                            </div>
                                        </div>
                                    </a>
                                    <form action="/notifications/<?php echo e($note->id); ?>/read" method="POST" class="d-none"><?php echo csrf_field(); ?></form>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <li><span class="dropdown-item-text small text-muted">No notifications yet.</span></li>
                            <?php endif; ?>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item text-success small fw-semibold" href="/notifications"><i class="fas fa-list me-2"></i>View all notifications</a></li>
                        </ul>
                    </div>
                <?php endif; ?>
                <?php if(auth()->guard()->guest()): ?>
                    
                    <div class="ml-auth-links">
                        <a href="/login" class="btn-login"><i class="fas fa-user me-1"></i> Client Login</a>
                        <a href="/farmer-login" class="btn-register"><i class="fas fa-tractor me-1"></i> Farmer Login</a>
                    </div>
                <?php endif; ?>
                <?php if(auth()->guard()->check()): ?>
                    <div class="dropdown">
                        <button class="btn ml-user-chip dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <img src="<?php echo e(auth()->user()->avatarUrl()); ?>" alt="avatar" class="ml-user-chip-img">
                            <span class="d-none d-md-inline"><?php echo e(Str::limit(auth()->user()->displayName(), 14)); ?></span>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end shadow">
                            <li><h6 class="dropdown-header"><?php echo e(auth()->user()->displayName()); ?><br><small class="text-muted"><?php echo e(ucfirst(auth()->user()->role)); ?></small></h6></li>
                            <li><a class="dropdown-item" href="<?php echo e(auth()->user()->dashboardUrl()); ?>"><i class="fas fa-th-large me-2 text-success"></i>Dashboard</a></li>
                            <?php if(auth()->user()->isCustomer()): ?>
                                <li><a class="dropdown-item" href="/customer-profile"><i class="fas fa-user me-2 text-success"></i>My Profile</a></li>
                            <?php elseif(auth()->user()->isFarmer()): ?>
                                <li><a class="dropdown-item" href="/farmer-profile"><i class="fas fa-store me-2 text-success"></i>My Stall Profile</a></li>
                            <?php endif; ?>
                            <li><hr class="dropdown-divider"></li>
                            <li>
                                <form action="/logout" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="dropdown-item text-danger"><i class="fas fa-sign-out-alt me-2"></i>Logout</button>
                                </form>
                            </li>
                        </ul>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</nav>

<?php ($mlAnnouncement = \App\Models\Announcement::liveFor(auth()->user()?->role)->first()); ?>
<?php if($mlAnnouncement): ?>
<div class="ml-announcement-bar">
    <div class="container d-flex align-items-center gap-2 py-2">
        <i class="fas fa-bullhorn"></i>
        <strong class="me-1"><?php echo e($mlAnnouncement->title); ?></strong>
        <span class="d-none d-md-inline text-truncate"><?php echo e(Str::limit($mlAnnouncement->body, 110)); ?></span>
        <span class="badge bg-light text-success ms-auto"><?php echo e($mlAnnouncement->audienceLabel()); ?></span>
    </div>
</div>
<?php endif; ?>
<?php /**PATH /home/user/marketlink-final/resources/views/includes/navbar.blade.php ENDPATH**/ ?>