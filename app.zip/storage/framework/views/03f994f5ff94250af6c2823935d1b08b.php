<?php $__env->startSection('title', 'Pre-Order - MarketLink'); ?>

<?php $__env->startSection('no-navbar', '1'); ?>

<?php $__env->startSection('content'); ?>
<!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm sticky-top">
        <div class="container">
            <a class="navbar-brand fw-bold text-success" href="/"><i class="fas fa-leaf me-2"></i>MarketLink</a>
        </div>
    </nav>

    <div class="container py-5">
        <div class="text-center mb-4">
            <h2 class="fw-bold">Place Your Pre-Order</h2>
        </div>

        <!-- Step Indicator -->
        <div class="step-indicator">
            <div class="step completed">
                <div class="step-icon"><i class="fas fa-check"></i></div>
                <span>Cart</span>
            </div>
            <div class="step-line bg-success"></div>
            <div class="step active" id="step2-indicator">
                <div class="step-icon">2</div>
                <span>Pre-Order Details</span>
            </div>
            <div class="step-line"></div>
            <div class="step" id="step3-indicator">
                <div class="step-icon">3</div>
                <span>My Orders</span>
            </div>
        </div>

        <div class="row" id="main-content">
            <!-- Left: Form -->
            <div class="col-lg-7 mb-4">
                <form id="preorder-form" action="/preorder" method="POST" class="card border-0 shadow-sm p-4">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="items_json" id="items-json" value="[]">

                    <h5 class="fw-bold border-bottom pb-2 mb-4">Customer Information</h5>
                    <div class="row g-3 mb-4">
                        <div class="col-md-6">
                            <label class="form-label">Full Name</label>
                            <input type="text" class="form-control" value="<?php echo e(auth()->user()->name); ?>" readonly title="From your profile">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Contact Number</label>
                            <input type="tel" class="form-control" value="<?php echo e(auth()->user()->phone); ?>" readonly title="From your profile">
                        </div>
                        <div class="col-12">
                            <label class="form-label">Email Address</label>
                            <input type="email" class="form-control" value="<?php echo e(auth()->user()->email); ?>" readonly title="From your profile">
                        </div>
                    </div>

                    <h5 class="fw-bold border-bottom pb-2 mb-4">Pickup Details</h5>
                    <div class="row g-3 mb-4">
                        <div class="col-12">
                            <label class="form-label d-flex justify-content-between align-items-center">
                                <span>Select Pickup Market</span>
                                <button type="button" id="preorderNearMe" class="btn btn-sm btn-outline-success py-0 px-2"
                                        title="Sort markets by distance from your location">
                                    <i class="fas fa-location-arrow me-1"></i><span id="nearMeBtnLabel">Near Me</span>
                                </button>
                            </label>
                            <select class="form-select <?php $__errorArgs = ['market'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="market" id="market-select">
                                <option value="" selected disabled>Choose a market...</option>
                                <?php $__currentLoopData = $markets ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $market): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($market->name); ?>"
                                            data-lat="<?php echo e($market->latitude ?? ''); ?>"
                                            data-lng="<?php echo e($market->longitude ?? ''); ?>"
                                            data-city="<?php echo e($market->city ?? ''); ?>"
                                            <?php echo e(old('market') === $market->name ? 'selected' : ''); ?>>
                                        <?php echo e($market->name); ?><?php if($market->city): ?> — <?php echo e($market->city); ?><?php endif; ?>
                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <div id="preorderDistHint" class="form-text text-muted" style="display:none;">
                                <i class="fas fa-info-circle me-1"></i>Markets sorted nearest first. Distance shown in brackets.
                            </div>
                            <?php $__errorArgs = ['market'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback d-block"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Select Pickup Date *</label>
                            <input type="date" class="form-control <?php $__errorArgs = ['pickup_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="pickup-date" name="pickup_date" value="<?php echo e(old('pickup_date')); ?>" required>
                            <?php $__errorArgs = ['pickup_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback d-block"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Select Time Slot</label>
                            <select class="form-select <?php $__errorArgs = ['pickup_slot'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pickup_slot" id="pickup-slot">
                                <option value="" selected disabled>Choose time...</option>
                                
                                <option value="8:00 AM - 9:00 AM" <?php echo e(old('pickup_slot') === '8:00 AM - 9:00 AM' ? 'selected' : ''); ?>>8:00 AM - 9:00 AM</option>
                                <option value="9:00 AM - 10:00 AM" <?php echo e(old('pickup_slot') === '9:00 AM - 10:00 AM' ? 'selected' : ''); ?>>9:00 AM - 10:00 AM</option>
                                <option value="10:00 AM - 11:00 AM" <?php echo e(old('pickup_slot') === '10:00 AM - 11:00 AM' ? 'selected' : ''); ?>>10:00 AM - 11:00 AM</option>
                                <option value="11:00 AM - 12:00 PM" <?php echo e(old('pickup_slot') === '11:00 AM - 12:00 PM' ? 'selected' : ''); ?>>11:00 AM - 12:00 PM</option>
                            </select>
                            <?php $__errorArgs = ['pickup_slot'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback d-block"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Special Notes (Optional)</label>
                            <textarea class="form-control" name="notes" rows="2" placeholder="e.g., I will send my brother to pick up."><?php echo e(old('notes')); ?></textarea>
                        </div>
                    </div>

                    <div class="alert alert-warning d-flex align-items-center mb-4" role="alert">
                        <i class="fas fa-wallet fs-4 me-3"></i>
                        <div>
                            <strong>Payment Notice:</strong> Payment will be made in person at the pickup location directly to the farmer. No online payment required.
                        </div>
                    </div>

                    <button type="submit" class="btn btn-success btn-lg w-100 fw-bold" id="place-order-btn">Place Pre-Order</button>
                </form>
            </div>

            <!-- Right: Summary -->
            <div class="col-lg-5">
                <div class="card border-0 shadow-sm sticky-top" style="top: 90px;">
                    <div class="card-body p-4 bg-light rounded">
                        <h4 class="fw-bold mb-4">Order Summary</h4>

                        <div id="order-items-list" class="mb-4">
                            <!-- Items from your real cart -->
                        </div>

                        <hr>

                        <div class="d-flex justify-content-between mb-2">
                            <span class="text-muted">Subtotal</span>
                            <span class="fw-medium" id="summary-subtotal">Rs 0</span>
                        </div>
                        <div class="d-flex justify-content-between mb-4">
                            <span class="fw-bold fs-5">Total to Pay at Pickup</span>
                            <span class="fw-bold fs-4 text-success" id="summary-total">Rs 0</span>
                        </div>

                        <div class="p-3 bg-white border rounded">
                            <h6 class="fw-bold mb-2"><i class="fas fa-box me-2 text-success"></i>Pre-Order Info</h6>
                            <ul class="list-unstyled small text-muted mb-0">
                                <li class="mb-1">&bull; Items from different stalls become separate orders.</li>
                                <li class="mb-1">&bull; Bring order ID to the market.</li>
                                <li>&bull; Pay directly at each farmer's stall.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
        // Set min date for date picker to today
        const today = new Date().toISOString().split('T')[0];
        document.getElementById('pickup-date').setAttribute('min', today);

        // Farmer pickup windows from DB, keyed by farmer_id (string)
        const FARMER_WINDOWS = <?php echo json_encode($farmerWindows ?? [], 15, 512) ?>;
        const DEFAULT_SLOTS = [
            '8:00 AM - 9:00 AM',
            '9:00 AM - 10:00 AM',
            '10:00 AM - 11:00 AM',
            '11:00 AM - 12:00 PM'
        ];
        const OLD_SLOT = "<?php echo e(old('pickup_slot')); ?>";

        function populateSlots() {
            const cart = (window.getCart && window.getCart()) || [];
            const mlProducts = (window.ML && window.ML.products) || [];

            // Collect unique farmer IDs — prefer stored farmer_id, fall back to
            // looking up the product in the live ML feed by product id
            const farmerIds = [...new Set(
                cart.map(i => {
                    if (i.farmer_id) return String(i.farmer_id);
                    // Legacy cart items (added before farmer_id was stored): resolve via ML feed
                    const mlProd = mlProducts.find(p => String(p.id) === String(i.id));
                    return mlProd ? String(mlProd.farmerId || '') : '';
                }).filter(Boolean)
            )];

            let slots = [];
            farmerIds.forEach(fid => {
                const windows = FARMER_WINDOWS[fid];
                if (windows && windows.length) {
                    windows.forEach(w => { if (w && !slots.includes(w)) slots.push(w); });
                }
            });

            // Fall back to defaults if no farmer windows found
            if (!slots.length) slots = DEFAULT_SLOTS;

            const sel = document.getElementById('pickup-slot');
            if (!sel) return;

            sel.innerHTML = '<option value="" disabled selected>Choose time...</option>'
                + slots.map(s => {
                    const selected = (OLD_SLOT === s) ? ' selected' : '';
                    return `<option value="${s}"${selected}>${s}</option>`;
                }).join('');

            // If exactly one stall in cart and only one slot, auto-select it
            if (!OLD_SLOT && slots.length === 1) {
                sel.value = slots[0];
            }
        }

        // Render REAL cart items (from localStorage cart)
        const cart = (window.getCart && window.getCart()) || [];
        const list = document.getElementById('order-items-list');
        const fmtRs = (n) => 'Rs ' + (parseFloat(n) || 0).toLocaleString('en-PK', {maximumFractionDigits: 0});
        if (!cart.length) {
            list.innerHTML = '<div class="text-center py-4"><i class="fas fa-basket-shopping fa-2x text-muted mb-2"></i>' +
                '<p class="text-muted mb-2">Your cart is empty.</p>' +
                '<a href="/products" class="btn btn-sm btn-success">Browse Products</a></div>';
            document.getElementById('place-order-btn').disabled = true;
        } else {
            let total = 0;
            cart.forEach(item => {
                const sub = (parseFloat(item.price) || 0) * (item.quantity || 0);
                total += sub;
                const div = document.createElement('div');
                div.className = 'd-flex justify-content-between mb-3 border-bottom pb-2';
                div.innerHTML =
                    '<div><h6 class="mb-0 fw-bold">' + (item.quantity || 0) + 'x ' + item.name + '</h6></div>' +
                    '<span class="fw-medium">' + fmtRs(sub) + '</span>';
                list.appendChild(div);
            });
            document.getElementById('summary-subtotal').textContent = fmtRs(total);
            document.getElementById('summary-total').textContent = fmtRs(total);
        }

        // Populate slots: run immediately, then again once the ML data feed
        // has loaded (it loads async via <script src="/data-feed.js">)
        populateSlots();
        document.addEventListener('DOMContentLoaded', populateSlots);
        window.addEventListener('load', populateSlots);
        // If data-feed.js loads after window.load (cached), repopulate when ML appears
        (function waitForML(tries) {
            if (window.ML && window.ML.products && window.ML.products.length) {
                populateSlots();
            } else if (tries > 0) {
                setTimeout(function() { waitForML(tries - 1); }, 200);
            }
        })(15);

        // Attach cart items to the real form submit
        document.getElementById('preorder-form').addEventListener('submit', function(e) {
            const items = (window.getCart && window.getCart()) || [];
            if (!items.length) {
                e.preventDefault();
                if (window.showToast) window.showToast('Your cart is empty.', 'info');
                return;
            }
            document.getElementById('items-json').value = JSON.stringify(items.map(i => ({id: i.id, qty: i.quantity})));
        });

        // ----- Near Me: sort market <select> options by distance -----
        (function () {
            var nearBtn = document.getElementById('preorderNearMe');
            var sel     = document.getElementById('market-select');
            var hint    = document.getElementById('preorderDistHint');
            var label   = document.getElementById('nearMeBtnLabel');
            if (!nearBtn || !sel) return;

            function sortOptionsByDist(userLat, userLng) {
                var opts = Array.from(sel.options).filter(o => o.value); // skip placeholder
                opts.forEach(function (o) {
                    var lat = parseFloat(o.dataset.lat);
                    var lng = parseFloat(o.dataset.lng);
                    if (lat && lng) {
                        o.dataset.dist = window.MLGeo.haversine(userLat, userLng, lat, lng);
                        // Append distance to label
                        var base = o.value + (o.dataset.city ? ' — ' + o.dataset.city : '');
                        o.textContent = base + '  (' + window.MLGeo.fmtDist(parseFloat(o.dataset.dist)) + ')';
                    } else {
                        o.dataset.dist = '99999';
                    }
                });
                opts.sort((a, b) => parseFloat(a.dataset.dist) - parseFloat(b.dataset.dist));
                // Re-append sorted (keep placeholder first)
                var placeholder = sel.options[0];
                opts.forEach(o => sel.appendChild(o));
                sel.insertBefore(placeholder, sel.firstChild);

                nearBtn.classList.remove('btn-outline-success');
                nearBtn.classList.add('btn-success');
                if (label) label.textContent = 'Sorted';
                if (hint) hint.style.display = '';
            }

            function activate() {
                nearBtn.disabled = true;
                if (label) label.textContent = 'Locating…';
                nearBtn.querySelector('i').className = 'fas fa-spinner fa-spin me-1';
                window.MLGeo.getLocation(
                    function (lat, lng) {
                        nearBtn.disabled = false;
                        nearBtn.querySelector('i').className = 'fas fa-location-arrow me-1';
                        sortOptionsByDist(lat, lng);
                    },
                    function (code) {
                        nearBtn.disabled = false;
                        nearBtn.querySelector('i').className = 'fas fa-location-arrow me-1';
                        if (label) label.textContent = 'Near Me';
                        if (code === 1) alert('Location permission denied. Please allow location access in your browser.');
                        else alert('Could not get your location. Try again.');
                    }
                );
            }

            nearBtn.addEventListener('click', activate);

            // Auto-sort if location already cached from /markets or /farmers
            (function () {
                var cached = null;
                try { cached = JSON.parse(sessionStorage.getItem('ml_user_loc')); } catch (e) {}
                if (cached && cached.lat && cached.lng) sortOptionsByDist(cached.lat, cached.lng);
            })();
        })();
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\techproject\project\marketlink-final\resources\views/preorder.blade.php ENDPATH**/ ?>