<?php $__env->startSection('title', 'Contact Us — MarketLink'); ?>

<?php $__env->startSection('content'); ?>
<main>
        <!-- Page Hero -->
        <section class="ml-page-hero text-white py-5" style="background: linear-gradient(135deg, #183d26 0%, #2b5b3f 100%);">
            <div class="container py-5 text-center">
                <h1 class="display-4 fw-bold mb-3">Contact Us</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb justify-content-center mb-0">
                        <li class="breadcrumb-item"><a href="/" class="text-white-50 text-decoration-none">Home</a></li>
                        <li class="breadcrumb-item active text-white" aria-current="page">Contact</li>
                    </ol>
                </nav>
            </div>
        </section>

        <!-- Contact Section -->
        <section class="py-5">
            <div class="container py-4">
                <div class="row g-5">
                    <!-- Contact Form -->
                    <div class="col-lg-7">
                        <div class="bg-white p-4 p-md-5 rounded-4 shadow-sm border">
                            <h3 class="fw-bold mb-2">Get in Touch</h3>
                            <p class="text-muted mb-4">Have questions about an order, a farmer, or want to join our platform? Fill out the form below and we'll get back to you within 24 hours.</p>
                            
                            <form id="contactForm" action="/contact" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <label for="contactName" class="form-label fw-medium">Full Name <span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" id="contactName" name="contactName" placeholder="Your full name" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label for="contactEmail" class="form-label fw-medium">Email Address <span class="text-danger">*</span></label>
                                        <input type="email" class="form-control" id="contactEmail" placeholder="john@example.com" required>
                                    </div>
                                    <div class="col-12">
                                        <label for="contactSubject" class="form-label fw-medium">Subject <span class="text-danger">*</span></label>
                                        <select class="form-select" id="contactSubject" name="subject" required>
                                            <option value="" selected disabled>Select a subject...</option>
                                            <option value="General Inquiry">General Inquiry</option>
                                            <option value="Customer Support">Customer Support / Order Issue</option>
                                            <option value="Farmer Application">Farmer Application</option>
                                            <option value="Market Partnership">Market Partnership</option>
                                        </select>
                                    </div>
                                    <div class="col-12">
                                        <label for="contactMessage" class="form-label fw-medium">Message <span class="text-danger">*</span></label>
                                        <textarea class="form-control" id="contactMessage" rows="5" placeholder="How can we help you?" required></textarea>
                                    </div>
                                    <div class="col-12 mt-4">
                                        <button type="submit" class="btn ml-btn-primary px-5 py-2">Send Message <i class="fas fa-paper-plane ms-2"></i></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    
                    <!-- Contact Info -->
                    <div class="col-lg-5">
                        <div class="d-flex flex-column h-100 gap-4">
                            <!-- Info Cards -->
                            <div class="bg-success-subtle p-4 rounded-4">
                                <h4 class="fw-bold mb-4">Contact Information</h4>
                                
                                <div class="d-flex mb-4">
                                    <div class="bg-white text-success rounded-circle d-flex align-items-center justify-content-center me-3 shadow-sm flex-shrink-0" style="width: 45px; height: 45px;">
                                        <i class="fas fa-map-marker-alt"></i>
                                    </div>
                                    <div>
                                        <h6 class="fw-bold mb-1">Office Address</h6>
                                        <p class="text-muted small mb-0">MarketLink (student demo project)<br>Islamabad &amp; Karachi<br>Pakistan</p>
                                    </div>
                                </div>
                                
                                <div class="d-flex mb-4">
                                    <div class="bg-white text-success rounded-circle d-flex align-items-center justify-content-center me-3 shadow-sm flex-shrink-0" style="width: 45px; height: 45px;">
                                        <i class="fas fa-envelope"></i>
                                    </div>
                                    <div>
                                        <h6 class="fw-bold mb-1">Email Us</h6>
                                        <p class="text-muted small mb-0"><a href="mailto:support@marketlink.com" class="text-decoration-none text-muted">support@marketlink.com</a><br><a href="mailto:farmers@marketlink.com" class="text-decoration-none text-muted">farmers@marketlink.com</a></p>
                                    </div>
                                </div>
                                
                                <div class="d-flex mb-4">
                                    <div class="bg-white text-success rounded-circle d-flex align-items-center justify-content-center me-3 shadow-sm flex-shrink-0" style="width: 45px; height: 45px;">
                                        <i class="fas fa-phone-alt"></i>
                                    </div>
                                    <div>
                                        <h6 class="fw-bold mb-1">Call Us</h6>
                                        <p class="text-muted small mb-0">Use the form on this page<br>We reply within 2 working days</p>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Social Links -->
                            <div class="bg-light p-4 rounded-4 text-center">
                                <h5 class="fw-bold mb-3">Connect With Us</h5>
                                <div class="d-flex justify-content-center gap-3">
                                    <a href="#" class="btn btn-outline-success rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;"><i class="fab fa-facebook-f"></i></a>
                                    <a href="#" class="btn btn-outline-success rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;"><i class="fab fa-twitter"></i></a>
                                    <a href="#" class="btn btn-outline-success rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;"><i class="fab fa-instagram"></i></a>
                                    <a href="#" class="btn btn-outline-success rounded-circle d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;"><i class="fab fa-youtube"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Map Section — OpenStreetMap embed (Islamabad, Pakistan) -->
        <section class="py-5 bg-light">
            <div class="container">
                <div class="text-center mb-4">
                    <h2 class="fw-bold">Find Us on the Map</h2>
                    <p class="text-muted">MarketLink operates across local farmers markets in Pakistan.</p>
                </div>
                <div class="rounded-4 overflow-hidden shadow-sm border">
                    <iframe
                        title="MarketLink Location — Islamabad, Pakistan"
                        width="100%"
                        height="420"
                        style="border:0; display:block;"
                        loading="lazy"
                        referrerpolicy="no-referrer-when-downgrade"
                        src="https://www.openstreetmap.org/export/embed.html?bbox=73.0379%2C33.6744%2C73.0579%2C33.6944&amp;layer=mapnik&amp;marker=33.6844%2C73.0479">
                    </iframe>
                </div>
                <div class="text-center mt-3">
                    <a href="https://www.openstreetmap.org/?mlat=33.6844&amp;mlon=73.0479#map=15/33.6844/73.0479"
                       target="_blank" rel="noopener" class="text-success text-decoration-none small">
                        <i class="fas fa-external-link-alt me-1"></i>Open larger map on OpenStreetMap
                    </a>
                    &nbsp;&bull;&nbsp;
                    <a href="https://www.openstreetmap.org/directions?engine=fossgis_osrm_car&amp;route=;;33.6844,73.0479"
                       target="_blank" rel="noopener" class="text-success text-decoration-none small">
                        <i class="fa-solid fa-diamond-turn-right me-1"></i>Get directions
                    </a>
                </div>
            </div>
        </section>

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\techproject\project\marketlink-final\resources\views/contact.blade.php ENDPATH**/ ?>