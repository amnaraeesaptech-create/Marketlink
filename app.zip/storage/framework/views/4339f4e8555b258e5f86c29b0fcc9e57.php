<?php $__env->startSection('title', 'AI Assistant - MarketLink'); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Hero -->
    <section class="hero-section">
        <div class="container animate-fadeInUp">
            <h1 class="fw-bold mb-3">MarketLink AI Assistant</h1>
            <p class="lead mb-4">Ask about the live catalogue — <?php echo e($stats['products']); ?> products from <?php echo e($stats['farmers']); ?> stalls at <?php echo e($stats['markets']); ?> markets</p>
        </div>
    </section>

    <!-- Chat Interface -->
    <div class="container">
        <div class="chat-container animate-fadeInUp delay-200">
            <!-- Suggested Questions -->
            <div class="suggested-chips">
                <span class="text-muted w-100 d-block mb-2" style="font-size: 0.85rem;"><i class="fas fa-lightbulb me-1"></i> Suggested Questions</span>
                <button class="btn btn-outline-success btn-sm suggestion-btn">Where can I find tomatoes?</button>
                <button class="btn btn-outline-success btn-sm suggestion-btn">Which markets are open today?</button>
                <button class="btn btn-outline-success btn-sm suggestion-btn">Which farmers sell dairy products?</button>
                <button class="btn btn-outline-success btn-sm suggestion-btn">What are the pickup timings?</button>
                <button class="btn btn-outline-success btn-sm suggestion-btn">What vegetables are available?</button>
                <button class="btn btn-outline-success btn-sm suggestion-btn">Best rated stalls</button>
            </div>

            <!-- Chat Window -->
            <div class="chat-window" id="full-chat-window">
                <!-- Welcome Message -->
                <div class="bot-message-wrapper animate-chatBubblePop">
                    <div class="bot-avatar">
                        <i class="fas fa-seedling"></i>
                    </div>
                    <div class="message-bubble bot-message">
                        Hi! I answer from MarketLink's live data: <?php echo e($stats['products']); ?> products, <?php echo e($stats['farmers']); ?> stalls and <?php echo e($stats['markets']); ?> markets right now. Ask me about a product, a category, opening days or pickup timings.
                    </div>
                </div>
            </div>

            <!-- Input Area -->
            <div class="chat-input-area">
                <div class="chat-input-group">
                    <button class="btn text-muted p-2 me-1" title="Attach file (UI only)"><i class="fas fa-paperclip"></i></button>
                    <input type="text" id="full-chat-input" placeholder="Type your message here..." autocomplete="off">
                    <button class="btn text-muted p-2 mx-1" title="Voice input (UI only)"><i class="fas fa-microphone"></i></button>
                    <button class="btn btn-success text-white" id="full-chat-send" title="Send message"><i class="fas fa-paper-plane"></i></button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/user/marketlink-final/resources/views/ai-assistant.blade.php ENDPATH**/ ?>