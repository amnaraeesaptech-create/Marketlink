
<?php
    $latId    = $latId  ?? 'latitude';
    $lngId    = $lngId  ?? 'longitude';
    $latVal   = $latVal ?? '';
    $lngVal   = $lngVal ?? '';
    $pickerId = 'lp_' . $latId;
?>

<?php if (! $__env->hasRenderedOnce('59cd4d7c-f415-42b5-b6b6-05211e9e9f93')): $__env->markAsRenderedOnce('59cd4d7c-f415-42b5-b6b6-05211e9e9f93'); ?>
<?php $__env->startPush('styles'); ?>
<link rel="stylesheet"
      href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
      integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY="
      crossorigin=""/>
<?php $__env->stopPush(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
        integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV/XN/WLs="
        crossorigin=""></script>
<?php $__env->stopPush(); ?>
<?php endif; ?>

<div class="row g-3 align-items-end mb-2">
    <div class="col-md-4">
        <label class="form-label fw-medium small" for="<?php echo e($latId); ?>">Latitude</label>
        <input type="number" step="0.00000001"
               name="<?php echo e($latId); ?>" id="<?php echo e($latId); ?>"
               class="form-control <?php $__errorArgs = [$latId];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
               value="<?php echo e($latVal); ?>"
               placeholder="33.68440000">
        <?php $__errorArgs = [$latId];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-md-4">
        <label class="form-label fw-medium small" for="<?php echo e($lngId); ?>">Longitude</label>
        <input type="number" step="0.00000001"
               name="<?php echo e($lngId); ?>" id="<?php echo e($lngId); ?>"
               class="form-control <?php $__errorArgs = [$lngId];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
               value="<?php echo e($lngVal); ?>"
               placeholder="73.04790000">
        <?php $__errorArgs = [$lngId];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="col-md-4">
        <button type="button" id="<?php echo e($pickerId); ?>_gpsBtn"
                class="btn btn-outline-success w-100"
                title="Fill from your current GPS position">
            <i class="fas fa-location-arrow me-1"></i>Use My Location
        </button>
    </div>
</div>

<div id="<?php echo e($pickerId); ?>_status" class="small mb-2" style="display:none;"></div>

<div class="rounded-3 overflow-hidden border" style="height:260px;">
    <div id="<?php echo e($pickerId); ?>_map" style="height:260px;"></div>
</div>
<p class="text-muted small mt-1 mb-0">
    <i class="fas fa-info-circle me-1"></i>
    Click the map to place your pin, or drag the marker to adjust.
</p>

<?php $__env->startPush('scripts'); ?>
<script>
(function () {
    var latEl    = document.getElementById('<?php echo e($latId); ?>');
    var lngEl    = document.getElementById('<?php echo e($lngId); ?>');
    var gpsBtn   = document.getElementById('<?php echo e($pickerId); ?>_gpsBtn');
    var statusEl = document.getElementById('<?php echo e($pickerId); ?>_status');
    if (!latEl || !lngEl) return;

    var initLat  = parseFloat(latEl.value) || 30.3753;
    var initLng  = parseFloat(lngEl.value) || 69.3451;
    var initZoom = parseFloat(latEl.value)  ? 15 : 5;

    var map    = L.map('<?php echo e($pickerId); ?>_map').setView([initLat, initLng], initZoom);
    var marker = null;

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
        maxZoom: 19
    }).addTo(map);

    function placeMarker(lat, lng) {
        lat = Math.round(lat * 1e8) / 1e8;
        lng = Math.round(lng * 1e8) / 1e8;
        latEl.value = lat;
        lngEl.value = lng;
        if (marker) {
            marker.setLatLng([lat, lng]);
        } else {
            marker = L.marker([lat, lng], { draggable: true }).addTo(map);
            marker.on('dragend', function () {
                var p = marker.getLatLng();
                placeMarker(p.lat, p.lng);
            });
        }
        map.setView([lat, lng], Math.max(map.getZoom(), 15));
    }

    // Show existing pin if values already set
    if (parseFloat(latEl.value) && parseFloat(lngEl.value)) {
        placeMarker(parseFloat(latEl.value), parseFloat(lngEl.value));
    }

    // Click on map → place pin
    map.on('click', function (e) { placeMarker(e.latlng.lat, e.latlng.lng); });

    // GPS button
    if (gpsBtn) {
        gpsBtn.addEventListener('click', function () {
            gpsBtn.disabled = true;
            gpsBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>Locating…';
            statusEl.style.display = 'none';

            window.MLGeo.getLocation(
                function (lat, lng) {
                    placeMarker(lat, lng);
                    gpsBtn.disabled = false;
                    gpsBtn.classList.remove('btn-outline-success');
                    gpsBtn.classList.add('btn-success');
                    gpsBtn.innerHTML = '<i class="fas fa-check me-1"></i>Location Set';
                    statusEl.textContent = '\u2713 Coordinates set from GPS';
                    statusEl.className = 'text-success small mb-2';
                    statusEl.style.display = '';
                },
                function (code) {
                    gpsBtn.disabled = false;
                    gpsBtn.innerHTML = '<i class="fas fa-location-arrow me-1"></i>Use My Location';
                    var msgs = { 1: 'Permission denied \u2014 click the map to pin manually.',
                                 2: 'Position unavailable.', 3: 'Request timed out.' };
                    statusEl.textContent = '\u2717 ' + (msgs[code] || 'Could not get location.');
                    statusEl.className = 'text-danger small mb-2';
                    statusEl.style.display = '';
                }
            );
        });
    }
})();
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\techproject\project\marketlink-final\resources\views/includes/location-picker.blade.php ENDPATH**/ ?>