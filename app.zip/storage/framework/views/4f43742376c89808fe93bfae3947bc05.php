<?php $__env->startSection('title', 'Weekly Stock Template — MarketLink'); ?>

<?php $__env->startSection('content'); ?>
<div class="dashboard-layout">
    <?php echo $__env->make('includes.sidebar-farmer', ['active' => 'stock'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="dashboard-main">
        <div class="dashboard-topbar">
            <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
            <h1 class="ml-topbar-title">Weekly Stock Template</h1>
            <a href="/farmer-products" class="btn btn-sm btn-outline-success"><i class="fas fa-box me-1"></i>Manage Products</a>
        </div>

        <div class="dashboard-content">
            <div class="mb-4">
                <h2 class="h4 fw-bold mb-1">Set this week's stock in one pass</h2>
                <p class="text-muted mb-0 small">
                    Update the quantity you will bring to the market and untick anything you are not selling this week.
                    Saving pushes the numbers live to the storefront; clients who saved a sold-out item get a restock alert automatically.
                </p>
            </div>

            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0 small">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?php if(session('success')): ?>
                <div class="alert alert-success"><?php echo e(session('success')); ?></div>
            <?php endif; ?>

            <div class="row g-3 mb-4">
                <div class="col-6 col-lg-3">
                    <div class="card border-0 shadow-sm rounded-3 h-100">
                        <div class="card-body">
                            <div class="text-muted small">Products listed</div>
                            <div class="h4 fw-bold mb-0"><?php echo e($products->count()); ?></div>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-lg-3">
                    <div class="card border-0 shadow-sm rounded-3 h-100">
                        <div class="card-body">
                            <div class="text-muted small">In stock now</div>
                            <div class="h4 fw-bold mb-0"><?php echo e($products->where('stock', '>', 0)->count()); ?></div>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-lg-3">
                    <div class="card border-0 shadow-sm rounded-3 h-100">
                        <div class="card-body">
                            <div class="text-muted small">Sold out</div>
                            <div class="h4 fw-bold mb-0"><?php echo e($products->where('stock', '<=', 0)->count()); ?></div>
                        </div>
                    </div>
                </div>
                <div class="col-6 col-lg-3">
                    <div class="card border-0 shadow-sm rounded-3 h-100">
                        <div class="card-body">
                            <div class="text-muted small">Last inventory change</div>
                            <div class="fw-bold"><?php echo e($lastUpdated ? $lastUpdated->diffForHumans() : '—'); ?></div>
                            <div class="small text-muted"><?php echo e($lastUpdated ? $lastUpdated->format('M j, Y g:i A') : 'No stock saved yet'); ?></div>
                        </div>
                    </div>
                </div>
            </div>

            <form action="/farmer-stock-template" method="POST">
                <?php echo csrf_field(); ?>
                <div class="card border-0 shadow-sm rounded-3">
                    <div class="card-header bg-white border-bottom p-3 d-flex flex-wrap justify-content-between align-items-center gap-2">
                        <h3 class="h6 mb-0 fw-bold">This week's market list</h3>
                        <div class="d-flex gap-2">
                            <button type="button" class="btn btn-sm btn-outline-secondary" id="stockSelectAll">Select all</button>
                            <button type="button" class="btn btn-sm btn-outline-secondary" id="stockSelectNone">Clear all</button>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0" id="stockTemplateTable">
                            <thead class="table-light">
                                <tr>
                                    <th class="ps-3">Product</th>
                                    <th>Category</th>
                                    <th>Price</th>
                                    <th style="width:150px;">Bring this week</th>
                                    <th>On sale</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td class="ps-3">
                                            <div class="d-flex align-items-center gap-2">
                                                <img src="<?php echo e($product->imageUrl()); ?>" alt="<?php echo e($product->name); ?>" class="rounded-2" width="40" height="40" style="object-fit:cover;">
                                                <div>
                                                    <div class="fw-medium"><?php echo e($product->name); ?></div>
                                                    <?php if(! $product->is_approved): ?>
                                                        <span class="badge bg-warning text-dark">Awaiting admin approval</span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="text-muted small"><?php echo e($product->category); ?></td>
                                        <td class="small">PKR <?php echo e(number_format((float) $product->price, 0)); ?> <span class="text-muted">/ <?php echo e($product->unit); ?></span></td>
                                        <td>
                                            <div class="input-group input-group-sm">
                                                <input type="number" min="0" max="1000000" class="form-control stock-qty"
                                                       name="stock[<?php echo e($product->id); ?>]" value="<?php echo e((int) $product->stock); ?>"
                                                       data-product="<?php echo e($product->name); ?>">
                                                <span class="input-group-text"><?php echo e($product->unit); ?></span>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="form-check form-switch">
                                                <input class="form-check-input stock-available" type="checkbox"
                                                       name="available[]" value="<?php echo e($product->id); ?>" id="avail-<?php echo e($product->id); ?>"
                                                       <?php echo e($product->is_available ? 'checked' : ''); ?>>
                                                <label class="form-check-label small" for="avail-<?php echo e($product->id); ?>">
                                                    <?php echo e($product->is_available ? 'Listed' : 'Hidden'); ?>

                                                </label>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="5" class="text-center text-muted py-4">
                                            No products yet. <a href="/farmer-add-product" class="text-success">Add your first product</a> to build a weekly template.
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php if($products->isNotEmpty()): ?>
                    <div class="card-footer bg-white border-top p-3 d-flex flex-wrap justify-content-between align-items-center gap-2">
                        <span class="small text-muted">Tip: set the quantity to 0 to mark an item sold out for this week.</span>
                        <button type="submit" class="btn btn-success"><i class="fas fa-save me-1"></i>Save Weekly Stock</button>
                    </div>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const sidebar = document.getElementById('sidebar');
        const toggle = document.getElementById('sidebarToggle');
        if (toggle && sidebar) toggle.addEventListener('click', () => sidebar.classList.add('show'));

        document.getElementById('stockSelectAll')?.addEventListener('click', function () {
            document.querySelectorAll('.stock-available').forEach(c => { c.checked = true; });
        });
        document.getElementById('stockSelectNone')?.addEventListener('click', function () {
            document.querySelectorAll('.stock-available').forEach(c => { c.checked = false; });
        });

        // Sold-out items should not stay listed as available.
        document.querySelectorAll('.stock-qty').forEach(function (input) {
            input.addEventListener('change', function () {
                const row = input.closest('tr');
                const toggle = row?.querySelector('.stock-available');
                if (!toggle) return;
                if ((parseInt(input.value, 10) || 0) <= 0) toggle.checked = false;
            });
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/user/marketlink-final/resources/views/farmer/stock-template.blade.php ENDPATH**/ ?>