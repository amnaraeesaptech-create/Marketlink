<?php $__env->startSection('title', 'Markets — Admin'); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet"
      href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"
      integrity="sha256-p4NxAoJBhIIN+hmNHrzRCf9tD/miZyoHS5obTRR9BMY="
      crossorigin=""/>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="ml-admin-layout">
    <!-- Sidebar -->
    <aside class="ml-admin-sidebar" id="adminSidebar">
      <div class="ml-admin-sidebar-header">
        <a href="/" class="ml-admin-brand"><i class="fas fa-seedling"></i> MarketLink</a>
        <span class="ml-admin-badge">Admin</span>
      </div>
      <div class="ml-admin-sidebar-user">
        <img src="<?php echo e(auth()->user()->avatarUrl()); ?>" alt="<?php echo e(auth()->user()->name); ?>">
        <div>
          <div><?php echo e(auth()->user()->name); ?></div>
          <div><?php echo e(auth()->user()->email); ?></div>
        </div>
      </div>
      <nav class="ml-admin-nav">
        <a href="/admin-dashboard" class="ml-admin-nav-link"><i class="fas fa-th-large"></i> Dashboard</a>
        <a href="/admin-farmers" class="ml-admin-nav-link"><i class="fas fa-tractor"></i> Farmers</a>
        <a href="/admin-customers" class="ml-admin-nav-link"><i class="fas fa-users"></i> Customers</a>
        <a href="/admin-markets" class="ml-admin-nav-link active"><i class="fas fa-store"></i> Markets</a>
        <a href="/admin-products" class="ml-admin-nav-link"><i class="fas fa-box"></i> Products</a>
        <a href="/admin-orders" class="ml-admin-nav-link"><i class="fas fa-shopping-bag"></i> Orders</a>
        <a href="/admin-reviews" class="ml-admin-nav-link"><i class="fas fa-star"></i> Reviews</a>
        <a href="/admin-reports" class="ml-admin-nav-link"><i class="fas fa-chart-bar"></i> Reports</a>

        <a href="/admin-categories" class="ml-admin-nav-link"><i class="fas fa-tags"></i> Categories</a>
        <a href="/admin-announcements" class="ml-admin-nav-link"><i class="fas fa-bullhorn"></i> Announcements</a>
        <a href="/notifications" class="ml-admin-nav-link"><i class="fas fa-bell"></i> Notifications</a>
        <hr>
        <form action="/logout" method="POST">
          <?php echo csrf_field(); ?>
          <button type="submit" class="ml-admin-nav-link ml-admin-logout w-100 border-0 bg-transparent text-start"><i class="fas fa-sign-out-alt"></i> Logout</button>
        </form>
      </nav>
    </aside>

    <!-- Main Content -->
    <div class="ml-admin-backdrop" id="adminBackdrop"></div>

    <main class="ml-admin-main">
      <div class="ml-admin-topbar">
        <div class="ml-admin-topbar-left">
          <button class="ml-admin-toggle" type="button" data-admin-menu aria-controls="adminSidebar" aria-expanded="false" aria-label="Toggle navigation"><i class="fas fa-bars"></i></button>
          
          <h4 class="m-0 fw-bold">Markets</h4>
          <small class="text-muted">Create, edit and remove the markets farmers trade at.</small>
        </div>
        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#marketModal" onclick="resetMarketForm()">
          <i class="fas fa-plus"></i> Add Market
        </button>
      </div>

      <div class="ml-admin-content">
        <?php if(session('success')): ?>
          <div class="alert alert-success alert-dismissible fade show"><?php echo e(session('success')); ?><button class="btn-close" data-bs-dismiss="alert"></button></div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
          <div class="alert alert-danger alert-dismissible fade show">
            <strong>Please fix:</strong>
            <ul class="mb-0"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
            <button class="btn-close" data-bs-dismiss="alert"></button>
          </div>
        <?php endif; ?>

        <div class="row g-3 mb-4">
          <div class="col-md-4">
            <div class="admin-stat-card">
              <div class="admin-stat-icon icon-amber"><i class="fas fa-store"></i></div>
              <div class="admin-stat-info"><p>Total Markets</p><h3><?php echo e($statTotal); ?></h3></div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="admin-stat-card">
              <div class="admin-stat-icon icon-green"><i class="fas fa-check-circle"></i></div>
              <div class="admin-stat-info"><p>Active</p><h3><?php echo e($statActive); ?></h3></div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="admin-stat-card">
              <div class="admin-stat-icon icon-blue"><i class="fas fa-tractor"></i></div>
              <div class="admin-stat-info"><p>Stall Links</p><h3><?php echo e($statStalls); ?></h3></div>
            </div>
          </div>
        </div>

        <div class="row g-4">
          <?php $__empty_1 = true; $__currentLoopData = $markets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $market): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-md-6 col-lg-4">
              <div class="admin-card h-100">
                <img src="<?php echo e($market->imageUrl()); ?>" alt="<?php echo e($market->name); ?>" class="card-img-top" style="height: 150px; object-fit: cover;">
                <div class="admin-card-body">
                  <h5 class="fw-bold mb-2"><?php echo e($market->name); ?>

                    <?php if (! ($market->is_active)): ?><span class="badge bg-secondary ms-1">Inactive</span><?php endif; ?>
                  </h5>
                  <p class="text-muted small mb-2"><i class="fas fa-map-marker-alt"></i> <?php echo e($market->address ?: 'No address'); ?><?php if($market->city): ?>, <?php echo e($market->city); ?><?php endif; ?></p>
                  <p class="text-muted small mb-3"><i class="far fa-clock"></i> <?php echo e($market->daysLabel()); ?> | <?php echo e($market->hoursLabel()); ?></p>
                  <div class="d-flex justify-content-between align-items-center mt-3 pt-3 border-top">
                    <span class="badge bg-success bg-opacity-10 text-success"><i class="fas fa-tractor"></i> <?php echo e($market->farmers_count); ?> Stall<?php echo e($market->farmers_count === 1 ? '' : 's'); ?></span>
                    <div class="d-flex gap-1">
                      <a href="/market-details?id=<?php echo e($market->id); ?>" class="btn btn-sm btn-light text-secondary" title="View public page"><i class="fas fa-eye"></i></a>
                      <button class="btn btn-sm btn-light text-primary" title="Edit"
                              data-bs-toggle="modal" data-bs-target="#marketModal"
                              data-market="<?php echo e(json_encode([
                                  'id' => $market->id, 'name' => $market->name, 'city' => $market->city,
                                  'address' => $market->address, 'days' => $market->days,
                                  'open_time' => $market->open_time, 'close_time' => $market->close_time,
                                  'description' => $market->description, 'google_maps_url' => $market->google_maps_url,
                                  'latitude' => $market->latitude, 'longitude' => $market->longitude,
                                  'is_active' => $market->is_active,
                              ], JSON_HEX_APOS | JSON_HEX_QUOT)); ?>"
                              onclick="fillMarketForm(this)">
                        <i class="fas fa-edit"></i>
                      </button>
                      <form action="/admin-markets/<?php echo e($market->id); ?>" method="POST" onsubmit="return confirm('Delete <?php echo e($market->name); ?>? Farmers will be unlinked from it.');">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-sm btn-light text-danger" title="Delete"><i class="fas fa-trash"></i></button>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12 text-center text-muted py-5">
              <i class="fas fa-store fa-2x mb-3 d-block text-success"></i>
              No markets yet. Click <strong>Add Market</strong> to create the first one — farmers pick from this list.
            </div>
          <?php endif; ?>
        </div>
      </div>
    </main>
  </div>

  <!-- Add / Edit Market Modal -->
  <div class="modal fade" id="marketModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
      <div class="modal-content">
        <form id="marketForm" action="/admin-markets" method="POST">
          <?php echo csrf_field(); ?>
          <input type="hidden" name="_method" id="marketMethod" value="POST">
          <div class="modal-header">
            <h5 class="modal-title" id="marketModalTitle">Add Market</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
          </div>
          <div class="modal-body">
            <div class="row g-3">
              <div class="col-md-12">
                <label class="form-label">Market Name *</label>
                <input type="text" class="form-control" name="name" id="mkName" value="<?php echo e(old('name')); ?>" required placeholder="e.g. Downtown Farmers Market">
              </div>
              <div class="col-md-6">
                <label class="form-label">City</label>
                <input type="text" class="form-control" name="city" id="mkCity" value="<?php echo e(old('city')); ?>" placeholder="e.g. Islamabad">
              </div>
              <div class="col-md-6">
                <label class="form-label">Address</label>
                <input type="text" class="form-control" name="address" id="mkAddress" value="<?php echo e(old('address')); ?>" placeholder="Street / area">
              </div>
              <div class="col-md-6">
                <label class="form-label">Opens At</label>
                <input type="time" class="form-control" name="open_time" id="mkOpen" value="<?php echo e(old('open_time')); ?>">
              </div>
              <div class="col-md-6">
                <label class="form-label">Closes At</label>
                <input type="time" class="form-control" name="close_time" id="mkClose" value="<?php echo e(old('close_time')); ?>">
              </div>
              <div class="col-md-12">
                <label class="form-label d-block">Operating Days</label>
                <?php $__currentLoopData = \App\Models\Market::DAYS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" name="days[]" value="<?php echo e($day); ?>" id="mkDay<?php echo e(substr($day, 0, 3)); ?>">
                    <label class="form-check-label" for="mkDay<?php echo e(substr($day, 0, 3)); ?>"><?php echo e(substr($day, 0, 3)); ?></label>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <div class="col-md-12">
                <label class="form-label">Google Maps URL</label>
                <input type="url" class="form-control" name="google_maps_url" id="mkMaps" value="<?php echo e(old('google_maps_url')); ?>" placeholder="https://maps.google.com/...">
              </div>
              <div class="row g-3 mt-0">
                <div class="col-12">
                  <label class="form-label">Map Location</label>
                  <p class="text-muted small mb-2">Click the map to pin this market, or drag the marker to adjust.</p>
                  <div class="row g-2 align-items-end mb-2">
                    <div class="col-md-5">
                      <label class="form-label small mb-1" for="mkLat">Latitude</label>
                      <input type="number" step="0.00000001" class="form-control form-control-sm"
                             name="latitude" id="mkLat" value="<?php echo e(old('latitude')); ?>" placeholder="33.68440000">
                      <div class="form-text">Drives the map pin + directions link.</div>
                    </div>
                    <div class="col-md-5">
                      <label class="form-label small mb-1" for="mkLng">Longitude</label>
                      <input type="number" step="0.00000001" class="form-control form-control-sm"
                             name="longitude" id="mkLng" value="<?php echo e(old('longitude')); ?>" placeholder="73.04790000">
                    </div>
                    <div class="col-md-2">
                      <button type="button" id="mkGpsBtn" class="btn btn-outline-success btn-sm w-100"
                              title="Use my current location">
                        <i class="fas fa-location-arrow"></i>
                      </button>
                    </div>
                  </div>
                  <div id="mkMapWrap" class="rounded-3 overflow-hidden border" style="height:220px;">
                    <div id="mkMap" style="height:220px;"></div>
                  </div>
                  <p class="text-muted small mt-1">Click map to place market pin, or drag marker to adjust.</p>
                </div>
              </div>
              <div class="col-md-12">
                <label class="form-label">Description</label>
                <textarea class="form-control" name="description" id="mkDescription" rows="3" placeholder="What visitors should know about this market"><?php echo e(old('description')); ?></textarea>
              </div>
              <div class="col-md-12">
                <div class="form-check form-switch">
                  <input class="form-check-input" type="checkbox" name="is_active" value="1" id="mkActive" checked>
                  <label class="form-check-label" for="mkActive">Active (listed publicly)</label>
                </div>
              </div>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancel</button>
            <button type="submit" class="btn btn-success" id="marketSubmitBtn">Create Market</button>
          </div>
        </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
  function resetMarketForm() {
    document.getElementById('marketModalTitle').textContent = 'Add Market';
    document.getElementById('marketSubmitBtn').textContent = 'Create Market';
    document.getElementById('marketForm').action = '/admin-markets';
    document.getElementById('marketMethod').value = 'POST';
    ['mkName','mkCity','mkAddress','mkOpen','mkClose','mkMaps','mkDescription','mkLat','mkLng'].forEach(function (id) {
      document.getElementById(id).value = '';
    });
    document.querySelectorAll('#marketModal input[name="days[]"]').forEach(function (cb) { cb.checked = false; });
    document.getElementById('mkActive').checked = true;
  }

  function fillMarketForm(btn) {
    var m = JSON.parse(btn.getAttribute('data-market'));
    document.getElementById('marketModalTitle').textContent = 'Edit Market';
    document.getElementById('marketSubmitBtn').textContent = 'Save Changes';
    document.getElementById('marketForm').action = '/admin-markets/' + m.id;
    document.getElementById('marketMethod').value = 'PUT';
    document.getElementById('mkName').value = m.name || '';
    document.getElementById('mkCity').value = m.city || '';
    document.getElementById('mkAddress').value = m.address || '';
    document.getElementById('mkOpen').value = m.open_time || '';
    document.getElementById('mkClose').value = m.close_time || '';
    document.getElementById('mkMaps').value = m.google_maps_url || '';
    document.getElementById('mkDescription').value = m.description || '';
    document.getElementById('mkLat').value = m.latitude || '';
    document.getElementById('mkLng').value = m.longitude || '';
    document.getElementById('mkActive').checked = !!m.is_active;
    document.querySelectorAll('#marketModal input[name="days[]"]').forEach(function (cb) {
      cb.checked = (m.days || []).indexOf(cb.value) !== -1;
    });
    // Refresh map pin when editing an existing market
    if (window._mkMapReady && m.latitude && m.longitude) {
        window._mkPlaceMarker(parseFloat(m.latitude), parseFloat(m.longitude));
    }
  }
</script>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"
        integrity="sha256-20nQCchB9co0qIjJZRGuk2/Z9VM+kNiyxNV/XN/WLs="
        crossorigin=""></script>
<script>
(function () {
    var mkMap    = null;
    var mkMarker = null;
    var latEl    = document.getElementById('mkLat');
    var lngEl    = document.getElementById('mkLng');
    var gpsBtn   = document.getElementById('mkGpsBtn');

    window._mkMapReady = false;

    window._mkPlaceMarker = function (lat, lng) {
        lat = Math.round(lat * 1e8) / 1e8;
        lng = Math.round(lng * 1e8) / 1e8;
        if (latEl) latEl.value = lat;
        if (lngEl) lngEl.value = lng;
        if (mkMarker) {
            mkMarker.setLatLng([lat, lng]);
        } else {
            mkMarker = L.marker([lat, lng], { draggable: true }).addTo(mkMap);
            mkMarker.on('dragend', function () {
                var p = mkMarker.getLatLng();
                window._mkPlaceMarker(p.lat, p.lng);
            });
        }
        mkMap.setView([lat, lng], Math.max(mkMap.getZoom(), 15));
    };

    // Init Leaflet map when modal becomes visible (avoids tile-load bug in hidden modals)
    var modal = document.getElementById('marketModal');
    if (modal) {
        modal.addEventListener('shown.bs.modal', function () {
            if (!mkMap) {
                mkMap = L.map('mkMap').setView([30.3753, 69.3451], 5);
                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
                    maxZoom: 19
                }).addTo(mkMap);
                mkMap.on('click', function (e) {
                    window._mkPlaceMarker(e.latlng.lat, e.latlng.lng);
                });
                window._mkMapReady = true;
            }
            mkMap.invalidateSize(); // fix tile rendering after modal animation
            // Place existing marker if editing
            var lat = parseFloat(latEl && latEl.value), lng = parseFloat(lngEl && lngEl.value);
            if (lat && lng) window._mkPlaceMarker(lat, lng);
        });
    }

    // GPS button
    if (gpsBtn) {
        gpsBtn.addEventListener('click', function () {
            gpsBtn.disabled = true;
            gpsBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i>';
            window.MLGeo.getLocation(
                function (lat, lng) {
                    window._mkPlaceMarker(lat, lng);
                    gpsBtn.disabled = false;
                    gpsBtn.classList.remove('btn-outline-success');
                    gpsBtn.classList.add('btn-success');
                    gpsBtn.innerHTML = '<i class="fas fa-check"></i>';
                },
                function () {
                    gpsBtn.disabled = false;
                    gpsBtn.innerHTML = '<i class="fas fa-location-arrow"></i>';
                }
            );
        });
    }
})();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\techproject\project\marketlink-final\resources\views/admin/markets.blade.php ENDPATH**/ ?>