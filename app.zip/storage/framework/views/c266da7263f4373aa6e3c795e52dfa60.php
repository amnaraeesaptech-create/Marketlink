<?php $__env->startSection('title', 'Edit Stall Profile — MarketLink'); ?>

<?php $__env->startSection('content'); ?>
<div class="dashboard-layout">
    <?php echo $__env->make('includes.sidebar-farmer', ['active' => 'profile'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="dashboard-main">
        <div class="dashboard-topbar">
            <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
            <h1 class="ml-topbar-title">Edit Stall Profile</h1>
            <div class="d-flex align-items-center gap-2">
                <a href="/farmer-profile" class="btn btn-sm btn-outline-success"><i class="fas fa-eye me-1"></i>View Public Profile</a>
            </div>
        </div>

        <div class="dashboard-content">
            <form action="/farmer-profile" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <!-- Business info -->
                <div class="card border-0 shadow-sm rounded-4 mb-4">
                    <div class="card-body p-4">
                        <h5 class="fw-bold mb-3"><i class="fas fa-store me-2 text-success"></i>Business Information</h5>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label fw-medium small" for="stall_name">Stall / Business Name *</label>
                                <input type="text" name="stall_name" id="stall_name" value="<?php echo e(old('stall_name', $user->farmer->stall_name ?? $user->name)); ?>" class="form-control <?php $__errorArgs = ['stall_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                <?php $__errorArgs = ['stall_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-medium small" for="contact_person">Contact Person *</label>
                                <input type="text" name="contact_person" id="contact_person" value="<?php echo e(old('contact_person', $user->farmer->contact_person ?? $user->name)); ?>" class="form-control <?php $__errorArgs = ['contact_person'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                <?php $__errorArgs = ['contact_person'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-medium small" for="phone">Contact Number *</label>
                                <input type="text" name="phone" id="phone" value="<?php echo e(old('phone', $user->phone)); ?>" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-medium small" for="email">Email Address *</label>
                                <input type="email" name="email" id="email" value="<?php echo e(old('email', $user->email)); ?>" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-12">
                                <label class="form-label fw-medium small" for="address">Farm / Business Address *</label>
                                <input type="text" name="address" id="address" value="<?php echo e(old('address', $user->address)); ?>" class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-12">
                                <label class="form-label fw-medium small" for="description">About the Farm</label>
                                <textarea name="description" id="description" rows="3" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Tell customers about your farm, practices and specialties..."><?php echo e(old('description', $user->farmer->description ?? '')); ?></textarea>
                                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-12">
                                <label class="form-label fw-medium small" for="avatar">Stall / Profile Photo</label>
                                <input type="file" name="avatar" id="avatar" accept="image/*" class="form-control <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Markets + days + categories -->
                <div class="card border-0 shadow-sm rounded-4 mb-4">
                    <div class="card-body p-4">
                        <h5 class="fw-bold mb-3"><i class="fas fa-map-marked-alt me-2 text-success"></i>Markets & Schedule</h5>
                        <?php
                            $myMarkets = old('markets', $selectedMarkets ?? $user->marketNames());
                            $myDays = old('operating_days', $user->farmer->operating_days ?? []);
                            $myCats = old('categories', $user->farmer->categories ?? []);
                            $allDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
                            $allCats = \App\Models\Category::names();
                        ?>
                        <label class="form-label fw-medium small">Markets you sell at</label>
                        <div class="row g-2 mb-4">
                            <?php $__empty_1 = true; $__currentLoopData = $allMarkets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $market): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="col-md-6">
                                    <div class="form-check border rounded p-2">
                                        <input class="form-check-input ms-1" type="checkbox" name="markets[]" value="<?php echo e($market->name); ?>" id="mkt-<?php echo e($market->id); ?>" <?php echo e(in_array($market->name, $myMarkets) ? 'checked' : ''); ?>>
                                        <label class="form-check-label ms-2" for="mkt-<?php echo e($market->id); ?>"><?php echo e($market->name); ?><span class="text-muted small"> — <?php echo e($market->city); ?></span></label>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="col-12 text-muted small">No markets are open yet — an admin adds them from the Markets page.</div>
                            <?php endif; ?>
                        </div>

                        <label class="form-label fw-medium small">Operating days</label>
                        <div class="d-flex flex-wrap gap-2 mb-4">
                            <?php $__currentLoopData = $allDays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="m-0">
                                    <input class="btn-check" type="checkbox" name="operating_days[]" value="<?php echo e($day); ?>" id="day-<?php echo e($day); ?>" autocomplete="off" <?php echo e(in_array($day, $myDays) ? 'checked' : ''); ?>>
                                    <label class="btn btn-outline-success btn-sm" for="day-<?php echo e($day); ?>"><?php echo e($day); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <label class="form-label fw-medium small">Product categories</label>
                        <div class="d-flex flex-wrap gap-3">
                            <?php $__currentLoopData = $allCats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="categories[]" value="<?php echo e($cat); ?>" id="cat-<?php echo e($loop->index); ?>" <?php echo e(in_array($cat, $myCats) ? 'checked' : ''); ?>>
                                    <label class="form-check-label" for="cat-<?php echo e($loop->index); ?>"><?php echo e($cat); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>

                <!-- Pickup windows -->
                <div class="card border-0 shadow-sm rounded-4 mb-4">
                    <div class="card-body p-4">
                        <h5 class="fw-bold mb-1"><i class="fas fa-clock me-2 text-success"></i>Pickup Time Windows</h5>
                        <p class="text-muted small mb-3">e.g. "Sat 8:00 AM - 1:00 PM". Customers can only pre-order inside these windows.</p>
                        <div id="pickupWindows">
                            <?php $__empty_1 = true; $__currentLoopData = old('pickup_windows', $user->farmer->pickup_windows ?? ['']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $window): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="input-group mb-2 pickup-row">
                                    <span class="input-group-text bg-light"><i class="far fa-clock text-success"></i></span>
                                    <input type="text" name="pickup_windows[]" value="<?php echo e($window); ?>" class="form-control" placeholder="Sat 8:00 AM - 1:00 PM">
                                    <button type="button" class="btn btn-outline-danger remove-window"><i class="fas fa-times"></i></button>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="input-group mb-2 pickup-row">
                                    <span class="input-group-text bg-light"><i class="far fa-clock text-success"></i></span>
                                    <input type="text" name="pickup_windows[]" value="" class="form-control" placeholder="Sat 8:00 AM - 1:00 PM">
                                    <button type="button" class="btn btn-outline-danger remove-window"><i class="fas fa-times"></i></button>
                                </div>
                            <?php endif; ?>
                        </div>
                        <button type="button" class="btn btn-sm btn-outline-success" id="addWindow"><i class="fas fa-plus me-1"></i>Add Window</button>
                    </div>
                </div>

                <!-- Order cut-off -->
                <div class="card border-0 shadow-sm rounded-4 mb-4">
                    <div class="card-body p-4">
                        <h5 class="fw-bold mb-1"><i class="fas fa-hourglass-half me-2 text-success"></i>Order Cut-off</h5>
                        <p class="text-muted small mb-3">Customers can place, change or cancel a pre-order only until this many hours before pickup. After that the order is locked so you can harvest and pack.</p>
                        <div class="row g-3 align-items-end">
                            <div class="col-md-4">
                                <label class="form-label fw-medium small" for="cutoff_hours">Cut-off hours</label>
                                <input type="number" min="1" max="168" name="cutoff_hours" id="cutoff_hours"
                                       value="<?php echo e(old('cutoff_hours', $user->farmer->cutoff_hours ?? 12)); ?>"
                                       class="form-control <?php $__errorArgs = ['cutoff_hours'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <?php $__errorArgs = ['cutoff_hours'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-8">
                                <div class="alert alert-light border small mb-0">
                                    <i class="fas fa-circle-info text-success me-1"></i>
                                    Current setting: <strong><?php echo e((int) ($user->farmer->cutoff_hours ?? 12)); ?> hours</strong> before the pickup slot.
                                    Typical values: 12h (same-day market), 24h (next-morning orders), 48h (weekend market).
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Map pin -->
                <div class="card border-0 shadow-sm rounded-4 mb-4">
                    <div class="card-body p-4">
                        <h5 class="fw-bold mb-1"><i class="fas fa-map-pin me-2 text-success"></i>Map Pin (OpenStreetMap)</h5>
                        <p class="text-muted small mb-3">Drop your stall location so customers can find and navigate to you.</p>
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label fw-medium small" for="latitude">Latitude</label>
                                <input type="number" step="0.00000001" name="latitude" id="latitude" value="<?php echo e(old('latitude', $user->farmer->latitude ?? '')); ?>" class="form-control <?php $__errorArgs = ['latitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="33.68440000">
                                <?php $__errorArgs = ['latitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-medium small" for="longitude">Longitude</label>
                                <input type="number" step="0.00000001" name="longitude" id="longitude" value="<?php echo e(old('longitude', $user->farmer->longitude ?? '')); ?>" class="form-control <?php $__errorArgs = ['longitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="73.04790000">
                                <?php $__errorArgs = ['longitude'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="d-flex gap-2 mb-5">
                    <button type="submit" class="btn ml-btn-primary"><i class="fas fa-save me-2"></i>Save Profile</button>
                    <a href="/farmer-profile" class="btn btn-outline-secondary">Cancel</a>
                </div>
            </form>

            <!-- Password -->
            <div class="card border-0 shadow-sm rounded-4 mb-5">
                <div class="card-body p-4">
                    <h5 class="fw-bold mb-3"><i class="fas fa-key me-2 text-success"></i>Change Password</h5>
                    <form action="/farmer-password" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="row g-3">
                            <div class="col-md-4">
                                <label class="form-label fw-medium small" for="current_password">Current Password</label>
                                <input type="password" name="current_password" id="current_password" class="form-control" required>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-medium small" for="password">New Password</label>
                                <input type="password" name="password" id="password" class="form-control" required>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label fw-medium small" for="password_confirmation">Confirm New</label>
                                <input type="password" name="password_confirmation" id="password_confirmation" class="form-control" required>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-outline-success mt-3">Update Password</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.getElementById('addWindow')?.addEventListener('click', function () {
        const wrap = document.getElementById('pickupWindows');
        const row = document.createElement('div');
        row.className = 'input-group mb-2 pickup-row';
        row.innerHTML = '<span class="input-group-text bg-light"><i class="far fa-clock text-success"></i></span>' +
            '<input type="text" name="pickup_windows[]" class="form-control" placeholder="Sat 8:00 AM - 1:00 PM">' +
            '<button type="button" class="btn btn-outline-danger remove-window"><i class="fas fa-times"></i></button>';
        wrap.appendChild(row);
    });
    document.getElementById('pickupWindows')?.addEventListener('click', function (e) {
        const btn = e.target.closest('.remove-window');
        if (btn && this.querySelectorAll('.pickup-row').length > 1) {
            btn.closest('.pickup-row').remove();
        }
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/user/marketlink-final/resources/views/farmer/profile-edit.blade.php ENDPATH**/ ?>