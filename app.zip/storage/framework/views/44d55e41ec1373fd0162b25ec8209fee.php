<?php $__env->startSection('title', 'Order Details - MarketLink'); ?>

<?php $__env->startSection('content'); ?>
<?php if(!empty($order ?? null)): ?>
<div class="container py-5">
    <a href="<?php echo e($backUrl ?? '/customer-orders'); ?>" class="text-decoration-none text-muted mb-3 d-inline-block"><i class="fas fa-arrow-left"></i> Back to Orders</a>

    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-2">
        <h2 class="fw-bold mb-0">Order <?php echo e($order->code()); ?></h2>
        <span class="badge <?php echo e($order->statusBadge()); ?> px-3 py-2 rounded-pill fs-6"><?php echo e($order->statusLabel()); ?></span>
    </div>

    <?php if($order->status === 'cancelled'): ?>
      <div class="alert alert-danger"><i class="fas fa-ban me-2"></i> This order was cancelled. Stock has been returned to the farmer's inventory.</div>
    <?php endif; ?>

    <!-- Progress Timeline -->
    <?php
      $steps = ['pending' => 'Placed', 'confirmed' => 'Accepted', 'ready' => 'Ready for Pickup', 'completed' => 'Completed'];
      $keys = array_keys($steps);
      $currentIdx = array_search($order->status, $keys);
      if ($currentIdx === false) $currentIdx = -1;
    ?>
    <div class="step-indicator mb-5">
        <?php $__currentLoopData = $steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php $idx = array_search($key, $keys); ?>
          <?php if($idx > 0): ?><div class="step-line <?php echo e($idx <= $currentIdx ? 'bg-success' : ''); ?>"></div><?php endif; ?>
          <div class="step <?php echo e($idx < $currentIdx ? 'completed' : ($idx === $currentIdx ? 'active' : '')); ?>">
              <div class="step-icon"><?php if($idx < $currentIdx): ?><i class="fas fa-check"></i><?php else: ?><?php echo e($idx + 1); ?><?php endif; ?></div>
              <span><?php echo e($label); ?></span>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="row g-4">
        <!-- Left: Items -->
        <div class="col-lg-8">
            <?php if(in_array($order->status, ['pending', 'confirmed'], true)): ?>
              <div class="alert <?php echo e(($canModify ?? false) ? 'alert-success' : 'alert-secondary'); ?> d-flex align-items-start gap-2">
                <i class="fas fa-hourglass-half mt-1"></i>
                <div class="small w-100">
                  <?php if($canModify ?? false): ?>
                    <strong>Changes allowed until <?php echo e($order->cutoffAt()?->format('M d, Y g:i A')); ?></strong>
                    — You can edit quantities, change the pickup slot or cancel any time before
                    <strong><?php echo e($order->cutoffHours()); ?>h</strong> before your pickup
                    (<?php echo e($order->pickupAt()?->format('M d, Y g:i A')); ?>).
                    <div class="mt-1 d-flex align-items-center gap-2">
                        <i class="fas fa-stopwatch text-success"></i>
                        Time remaining: <strong id="cutoff-countdown" class="text-success ms-1">calculating…</strong>
                    </div>
                  <?php else: ?>
                    The cut-off for changing this order has passed
                    <?php if($order->cutoffAt()): ?>
                        (<?php echo e($order->cutoffAt()->format('M d, Y g:i A')); ?> — <?php echo e($order->cutoffHours()); ?>h before pickup).
                    <?php endif; ?>
                    Please contact the farmer if something is wrong.
                  <?php endif; ?>
                </div>
              </div>
            <?php endif; ?>
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body p-4">
                    <h5 class="fw-bold mb-3">Items (<?php echo e($order->items->count()); ?>)</h5>
                    <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="d-flex align-items-center gap-3 mb-3 p-2 bg-light rounded-3">
                          <img src="<?php echo e($it->product ? $it->product->imageUrl() : \App\Support\Placeholder::image($it->name)); ?>" class="rounded-2" width="70" height="70" alt="Item" style="object-fit: cover;">
                          <div class="flex-grow-1">
                              <div class="fw-medium"><?php echo e($it->name); ?></div>
                              <small class="text-muted"><?php echo e($it->qty); ?> <?php echo e($it->unit); ?> &times; PKR <?php echo e(number_format($it->price, 0)); ?></small>
                          </div>
                          <div class="fw-bold">PKR <?php echo e(number_format($it->price * $it->qty, 0)); ?></div>
                          <?php if(($canReview ?? false) && $it->product_id): ?>
                            <button class="btn btn-sm btn-outline-warning text-nowrap" data-bs-toggle="modal" data-bs-target="#productReviewModal"
                                    data-product-id="<?php echo e($it->product_id); ?>" data-product-name="<?php echo e($it->name); ?>"
                                    data-rate-url="/reviews">Review</button>
                          <?php elseif(in_array($it->product_id, $reviewedProductIds ?? [], true)): ?>
                            <span class="badge bg-warning-subtle text-warning-emphasis text-nowrap">Product reviewed</span>
                          <?php endif; ?>
                      </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <hr>
                    <div class="d-flex justify-content-between mb-1">
                        <span class="text-muted">Subtotal</span>
                        <span class="fw-medium">PKR <?php echo e(number_format($order->subtotal, 0)); ?></span>
                    </div>
                    <div class="d-flex justify-content-between">
                        <span class="fw-bold fs-5">Total (pay at pickup)</span>
                        <span class="fw-bold fs-5 text-success">PKR <?php echo e(number_format($order->subtotal, 0)); ?></span>
                    </div>
                </div>
            </div>

            <!-- Pickup Info -->
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body p-4">
                    <h5 class="fw-bold mb-3">Pickup Information</h5>
                    <div class="row g-3">
                        <div class="col-md-4">
                            <div class="p-3 bg-light rounded-3 text-center">
                                <i class="fas fa-map-marker-alt text-success mb-1"></i>
                                <div class="fw-medium small">Market</div>
                                <div class="small text-muted"><?php echo e($order->market ?? '—'); ?></div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="p-3 bg-light rounded-3 text-center">
                                <i class="fas fa-calendar-alt text-success mb-1"></i>
                                <div class="fw-medium small">Pickup Date</div>
                                <div class="small text-muted"><?php echo e($order->pickup_date ? \Carbon\Carbon::parse($order->pickup_date)->format('D, M d, Y') : '—'); ?></div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="p-3 bg-light rounded-3 text-center">
                                <i class="fas fa-clock text-success mb-1"></i>
                                <div class="fw-medium small">Time Slot</div>
                                <div class="small text-muted"><?php echo e($order->pickup_slot ?? '—'); ?></div>
                            </div>
                        </div>
                    </div>
                    <?php if($order->notes): ?>
                      <div class="mt-3 p-3 bg-light rounded-3">
                          <div class="fw-medium small mb-1">Your Notes</div>
                          <div class="small text-muted"><?php echo e($order->notes); ?></div>
                      </div>
                    <?php endif; ?>

                    
                    <?php if(isset($pickupMarket) && $pickupMarket?->latitude && $pickupMarket?->longitude): ?>
                    <div class="mt-3">
                        <div class="fw-medium small mb-2">
                            <i class="fas fa-map-marker-alt text-success me-1"></i>Pickup Location Map
                        </div>
                        <div class="rounded-3 overflow-hidden border mb-2" style="height:220px;">
                            <iframe
                                title="Pickup location — <?php echo e($pickupMarket->name); ?>"
                                width="100%"
                                height="220"
                                style="border:0; display:block;"
                                loading="lazy"
                                referrerpolicy="no-referrer-when-downgrade"
                                src="https://www.openstreetmap.org/export/embed.html?bbox=<?php echo e((float)$pickupMarket->longitude - 0.012); ?>%2C<?php echo e((float)$pickupMarket->latitude - 0.012); ?>%2C<?php echo e((float)$pickupMarket->longitude + 0.012); ?>%2C<?php echo e((float)$pickupMarket->latitude + 0.012); ?>&amp;layer=mapnik&amp;marker=<?php echo e((float)$pickupMarket->latitude); ?>%2C<?php echo e((float)$pickupMarket->longitude); ?>">
                            </iframe>
                        </div>
                        <div class="d-flex flex-wrap gap-2">
                            <a href="https://www.openstreetmap.org/directions?engine=fossgis_osrm_car&amp;route=;;<?php echo e((float)$pickupMarket->latitude); ?>,<?php echo e((float)$pickupMarket->longitude); ?>"
                               target="_blank" rel="noopener" class="btn btn-success btn-sm flex-grow-1">
                                <i class="fa-solid fa-diamond-turn-right me-1"></i>Directions to <?php echo e($pickupMarket->name); ?>

                            </a>
                            <a href="https://www.openstreetmap.org/?mlat=<?php echo e((float)$pickupMarket->latitude); ?>&amp;mlon=<?php echo e((float)$pickupMarket->longitude); ?>#map=16/<?php echo e((float)$pickupMarket->latitude); ?>/<?php echo e((float)$pickupMarket->longitude); ?>"
                               target="_blank" rel="noopener" class="btn btn-outline-success btn-sm">
                                <i class="fa-solid fa-up-right-from-square me-1"></i>Open map
                            </a>
                        </div>
                    </div>
                    <?php elseif($order->market): ?>
                    <div class="mt-3 p-3 bg-light rounded-3">
                        <div class="small text-muted">
                            <i class="fas fa-map-marker-alt me-1 text-success"></i>
                            Pickup at <strong><?php echo e($order->market); ?></strong> — map coordinates not set for this market yet.
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Review -->
            <?php if($canReview ?? false): ?>
            <div class="card border-0 shadow-sm mb-4" id="write-review">
                <div class="card-body p-4">
                    <h5 class="fw-bold mb-3">Write a Review</h5>
                    <form action="/reviews" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="order_id" value="<?php echo e($order->id); ?>">
                        <div class="mb-3">
                            <label class="form-label fw-medium">Your Rating *</label>
                            <div class="d-flex gap-1 fs-4" id="star-picker">
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                  <i class="far fa-star text-warning" data-star="<?php echo e($i); ?>" style="cursor:pointer;"></i>
                                <?php endfor; ?>
                            </div>
                            <input type="hidden" name="rating" id="rating-input" value="<?php echo e(old('rating', 5)); ?>" required>
                            <?php $__errorArgs = ['rating'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-medium">Your Review</label>
                            <textarea class="form-control" name="comment" rows="3" placeholder="How was the quality? Was pickup smooth?"><?php echo e(old('comment')); ?></textarea>
                        </div>
                        <button type="submit" class="btn btn-warning fw-bold"><i class="fas fa-star me-1"></i> Submit Review</button>
                    </form>
                </div>
            </div>
            <?php elseif($order->review): ?>
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body p-4">
                    <h5 class="fw-bold mb-3">Your Review</h5>
                    <div class="text-warning mb-2">
                        <?php for($i = 1; $i <= 5; $i++): ?>
                          <i class="fas fa-star <?php echo e($i <= $order->review->rating ? '' : 'text-muted opacity-25'); ?>"></i>
                        <?php endfor; ?>
                    </div>
                    <?php if($order->review->comment): ?>
                      <p class="mb-0"><?php echo e($order->review->comment); ?></p>
                    <?php endif; ?>
                    <?php if($order->review->hasReply()): ?>
                      <div class="mt-3 p-3 bg-light rounded-3">
                        <div class="small fw-medium mb-1"><i class="fas fa-reply text-success me-1"></i>Farmer replied<?php echo e($order->review->replied_at ? ' ' . $order->review->replied_at->diffForHumans() : ''); ?></div>
                        <div class="small text-muted mb-0"><?php echo e($order->review->farmer_reply); ?></div>
                      </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>

            <?php if(($productReviews ?? collect())->isNotEmpty()): ?>
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body p-4">
                    <h5 class="fw-bold mb-3">Product Ratings You Sent</h5>
                    <?php $__currentLoopData = $productReviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pid => $rev): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="d-flex justify-content-between align-items-start gap-2 mb-3">
                        <div>
                          <div class="fw-medium"><?php echo e($rev->product->name ?? 'Product #' . $pid); ?></div>
                          <div class="text-warning small">
                            <?php for($i = 1; $i <= 5; $i++): ?>
                              <i class="fas fa-star <?php echo e($i <= $rev->rating ? '' : 'text-muted opacity-25'); ?>"></i>
                            <?php endfor; ?>
                          </div>
                          <?php if($rev->comment): ?><div class="small text-muted"><?php echo e($rev->comment); ?></div><?php endif; ?>
                        </div>
                        <?php if($rev->hasReply()): ?>
                          <div class="small text-end" style="max-width:45%">
                            <span class="d-block fw-medium"><i class="fas fa-reply text-success"></i> Farmer replied</span>
                            <span class="text-muted"><?php echo e($rev->farmer_reply); ?></span>
                          </div>
                        <?php endif; ?>
                      </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <!-- Right: Farmer + Actions -->
        <div class="col-lg-4">
            <?php if($order->farmer): ?>
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body p-4 text-center">
                    <img src="<?php echo e($order->farmer->avatarUrl()); ?>" class="rounded-circle mb-2" width="70" height="70" alt="Farmer" style="object-fit: cover;">
                    <h6 class="fw-bold mb-0"><?php echo e($order->farmer->displayName()); ?></h6>
                    <small class="text-muted"><?php echo e($order->farmer->marketNames() ? implode(', ', array_slice($order->farmer->marketNames(), 0, 2)) : 'Local Farmer'); ?></small>
                    <div class="mt-2">
                        <a href="/farmer-profile?id=<?php echo e($order->farmer->id); ?>" class="btn btn-sm btn-outline-success">View Profile</a>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <div class="card border-0 shadow-sm mb-4">
                <div class="card-body p-4">
                    <h6 class="fw-bold mb-3">Order Info</h6>
                    <div class="small mb-2 d-flex justify-content-between"><span class="text-muted">Placed</span><span><?php echo e($order->created_at->format('M d, Y h:i A')); ?></span></div>
                    <div class="small mb-2 d-flex justify-content-between"><span class="text-muted">Customer</span><span><?php echo e($order->customer->name); ?></span></div>
                    <div class="small d-flex justify-content-between"><span class="text-muted">Status</span><span class="badge <?php echo e($order->statusBadge()); ?>"><?php echo e($order->statusLabel()); ?></span></div>
                </div>
            </div>

            <?php if(($canModify ?? false) || ($canCancel ?? false)): ?>
            <div class="card border-0 shadow-sm">
                <div class="card-body p-4">
                    <?php if($canModify ?? false): ?>
                      <form action="/customer-orders/<?php echo e($order->id); ?>/update" method="POST">
                          <?php echo csrf_field(); ?>
                          <h6 class="fw-bold mb-3"><i class="fas fa-pen-to-square text-success me-1"></i>Modify Order</h6>
                          <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="mb-2">
                              <label class="form-label small mb-1" for="qty<?php echo e($it->id); ?>">
                                <?php echo e($it->name); ?> <span class="text-muted">(<?php echo e($it->qty); ?> <?php echo e($it->unit); ?> × PKR <?php echo e(number_format($it->price, 0)); ?>)</span>
                              </label>
                              <input type="number" class="form-control form-control-sm" id="qty<?php echo e($it->id); ?>"
                                     name="qty[<?php echo e($it->id); ?>]" min="0" value="<?php echo e($it->qty); ?>"
                                     <?php if($it->product): ?> max="<?php echo e(max($it->qty, $it->product->stock)); ?>" <?php endif; ?>>
                              <div class="form-text">Set 0 to drop this item.</div>
                            </div>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <div class="mb-3">
                            <label class="form-label small mb-1" for="modSlot">Pickup date &amp; time slot</label>
                            <input type="date" class="form-control form-control-sm mb-2" id="modDate" name="pickup_date"
                                   value="<?php echo e(\Carbon\Carbon::parse($order->pickup_date)->format('Y-m-d')); ?>" min="<?php echo e(now()->format('Y-m-d')); ?>">
                            <select class="form-select form-select-sm" id="modSlot" name="pickup_slot">
                              <?php $__currentLoopData = $pickupSlots ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($slot); ?>" <?php echo e($order->pickup_slot === $slot ? 'selected' : ''); ?>><?php echo e($slot); ?></option>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              <?php if(empty($pickupSlots) || ! in_array($order->pickup_slot, $pickupSlots ?? [], true)): ?>
                                <option value="<?php echo e($order->pickup_slot); ?>" selected><?php echo e($order->pickup_slot); ?></option>
                              <?php endif; ?>
                            </select>
                          </div>
                          <div class="mb-3">
                            <label class="form-label small mb-1" for="modNotes">Notes for the farmer</label>
                            <textarea class="form-control form-control-sm" id="modNotes" name="notes" rows="2"><?php echo e($order->notes); ?></textarea>
                          </div>
                          <button type="submit" class="btn btn-success w-100 btn-sm"><i class="fas fa-check me-1"></i> Save Changes</button>
                          <div class="form-text">Clearing every quantity cancels the order automatically.</div>
                      </form>
                      <?php if($canCancel ?? false): ?><hr><?php endif; ?>
                    <?php endif; ?>
                    <?php if($canCancel ?? false): ?>
                    <form action="/customer-orders/<?php echo e($order->id); ?>/cancel" method="POST" onsubmit="return confirm('Cancel this order?')">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-outline-danger w-100"><i class="fas fa-times me-1"></i> Cancel Order</button>
                    </form>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>

            <?php if(!($canModify ?? false) && in_array($order->status, ['completed', 'cancelled'], true)): ?>
            <div class="card border-0 shadow-sm">
                <div class="card-body p-4 d-grid gap-2">
                    <form action="/customer-orders/<?php echo e($order->id); ?>/reorder" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-success w-100"><i class="fas fa-rotate-right me-1"></i> Reorder These Items</button>
                    </form>
                    <div class="small text-muted text-center">Adds available items to your cart — stock is checked again at checkout.</div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php else: ?>
<div class="container py-5 text-center">
    <a href="/customer-orders" class="text-decoration-none text-muted mb-4 d-inline-block"><i class="fas fa-arrow-left"></i> Back to Orders</a>
    <div class="py-5">
        <i class="fas fa-receipt fa-3x text-success mb-3"></i>
        <h2 class="h4 fw-bold">No order selected</h2>
        <p class="text-muted">Open an order from your list to see its items, pickup details and review options.</p>
        <a href="/customer-orders" class="btn btn-success">View My Orders</a>
    </div>
</div>
<?php endif; ?>

<?php if(!empty($order ?? null) && ($canReview ?? false)): ?>
<div class="modal fade" id="productReviewModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <form action="/reviews" method="POST">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="order_id" value="<?php echo e($order->id); ?>">
        <input type="hidden" name="product_id" id="prProductId">
        <div class="modal-header">
          <h5 class="modal-title">Rate: <span id="prProductName"></span></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label class="form-label fw-medium">Product rating *</label>
            <div class="d-flex gap-1 fs-4" id="pr-star-picker">
              <?php for($i = 1; $i <= 5; $i++): ?>
                <i class="far fa-star text-warning" data-pr-star="<?php echo e($i); ?>" style="cursor:pointer;"></i>
              <?php endfor; ?>
            </div>
            <input type="hidden" name="rating" id="pr-rating-input" value="5" required>
          </div>
          <div class="mb-0">
            <label class="form-label fw-medium">Comment</label>
            <textarea class="form-control" name="comment" rows="3" placeholder="Freshness, size, packaging…"></textarea>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-warning fw-bold"><i class="fas fa-star me-1"></i> Submit Product Review</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    (function() {
        const prModal = document.getElementById('productReviewModal');
        if (prModal) {
            prModal.addEventListener('show.bs.modal', (e) => {
                const btn = e.relatedTarget;
                if (!btn) return;
                document.getElementById('prProductId').value = btn.dataset.productId;
                document.getElementById('prProductName').textContent = btn.dataset.productName;
            });
            const prPicker = document.getElementById('pr-star-picker');
            const prInput = document.getElementById('pr-rating-input');
            if (prPicker && prInput) {
                const prStars = prPicker.querySelectorAll('[data-pr-star]');
                const prPaint = (n) => prStars.forEach(s => {
                    const v = parseInt(s.dataset.prStar, 10);
                    s.classList.toggle('fas', v <= n);
                    s.classList.toggle('far', v > n);
                });
                prPaint(5);
                prStars.forEach(s => s.addEventListener('click', () => {
                    prInput.value = s.dataset.prStar;
                    prPaint(parseInt(prInput.value, 10));
                }));
            }
        }

        const picker = document.getElementById('star-picker');
        const input = document.getElementById('rating-input');
        if (!picker || !input) return;
        const stars = picker.querySelectorAll('[data-star]');
        const paint = (n) => {
            stars.forEach(s => {
                const v = parseInt(s.dataset.star, 10);
                s.classList.toggle('fas', v <= n);
                s.classList.toggle('far', v > n);
            });
        };
        paint(parseInt(input.value, 10) || 5);
        stars.forEach(s => s.addEventListener('click', () => {
            input.value = s.dataset.star;
            paint(parseInt(input.value, 10));
        }));
    })();
</script>

<?php if(isset($order) && ($canModify ?? false) && $order->cutoffAt()): ?>
<script>
    (function() {
        const cutoffEl = document.getElementById('cutoff-countdown');
        if (!cutoffEl) return;
        const cutoff = new Date("<?php echo e($order->cutoffAt()->toIso8601String()); ?>");
        if (isNaN(cutoff.getTime())) { cutoffEl.textContent = '—'; return; }

        function tick() {
            const diff = cutoff - Date.now();
            if (diff <= 0) {
                cutoffEl.textContent = 'Expired — please refresh';
                cutoffEl.className = 'text-danger ms-1 fw-bold';
                return;
            }
            const h = Math.floor(diff / 3600000);
            const m = Math.floor((diff % 3600000) / 60000);
            const s = Math.floor((diff % 60000) / 1000);
            cutoffEl.textContent = h + 'h ' + m + 'm ' + s + 's';
            // Turn orange when under 1 hour
            cutoffEl.className = (h < 1)
                ? 'text-warning ms-1 fw-bold'
                : 'text-success ms-1 fw-bold';
            setTimeout(tick, 1000);
        }
        tick();
    })();
</script>
<?php endif; ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\techproject\project\marketlink-final\resources\views/order-details.blade.php ENDPATH**/ ?>