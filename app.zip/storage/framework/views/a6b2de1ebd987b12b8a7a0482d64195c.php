
<aside class="ml-sidebar ml-sidebar-farmer" id="sidebar">
    <div class="ml-sidebar-header">
        <a href="/" class="ml-sidebar-brand"><i class="fas fa-seedling"></i> MarketLink</a>
        <button class="ml-sidebar-close d-lg-none" id="sidebarClose"><i class="fas fa-times"></i></button>
    </div>
    <div class="ml-sidebar-user">
        <img src="<?php echo e(auth()->user()->avatarUrl()); ?>" alt="Farmer" class="ml-sidebar-avatar">
        <div>
            <div class="ml-sidebar-username"><?php echo e(auth()->user()->displayName()); ?></div>
            <div class="ml-sidebar-role">Farmer</div>
        </div>
    </div>
    <nav class="ml-sidebar-nav">
        <a href="/farmer-dashboard" class="ml-sidebar-link <?php echo e(($active ?? '') === 'dashboard' ? 'active' : ''); ?>"><i class="fas fa-chart-pie"></i> Dashboard</a>
        <a href="/farmer-profile" class="ml-sidebar-link <?php echo e(($active ?? '') === 'profile' ? 'active' : ''); ?>"><i class="fas fa-user-edit"></i> My Profile</a>
        <a href="/farmer-products" class="ml-sidebar-link <?php echo e(($active ?? '') === 'products' ? 'active' : ''); ?>"><i class="fas fa-box"></i> Products</a>
        <a href="/farmer-add-product" class="ml-sidebar-link <?php echo e(($active ?? '') === 'add-product' ? 'active' : ''); ?>"><i class="fas fa-plus-circle"></i> Add Product</a>
        <a href="/farmer-orders" class="ml-sidebar-link <?php echo e(($active ?? '') === 'orders' ? 'active' : ''); ?>"><i class="fas fa-shopping-bag"></i> Orders</a>
        <a href="/farmer-stock-template" class="ml-sidebar-link <?php echo e(($active ?? '') === 'stock' ? 'active' : ''); ?>"><i class="fas fa-layer-group"></i> Weekly Stock</a>
        <a href="/farmer-profile/edit" class="ml-sidebar-link <?php echo e(($active ?? '') === 'slots' ? 'active' : ''); ?>"><i class="fas fa-clock"></i> Pickup Slots &amp; Cut-off</a>
        <a href="/farmer-reviews" class="ml-sidebar-link <?php echo e(($active ?? '') === 'reviews' ? 'active' : ''); ?>"><i class="fas fa-star"></i> Reviews</a>
        <a href="/notifications" class="ml-sidebar-link <?php echo e(($active ?? '') === 'notifications' ? 'active' : ''); ?>"><i class="fas fa-bell"></i> Notifications</a>
    <hr class="ml-sidebar-divider">
        <form action="/logout" method="POST">
            <?php echo csrf_field(); ?>
            <button type="submit" class="ml-sidebar-link ml-sidebar-logout w-100 border-0 bg-transparent text-start"><i class="fas fa-sign-out-alt"></i> Logout</button>
        </form>
    </nav>
</aside>
<div class="ml-sidebar-overlay" id="sidebarOverlay"></div>
<?php /**PATH /home/user/marketlink-final/resources/views/includes/sidebar-farmer.blade.php ENDPATH**/ ?>