
<aside class="ml-sidebar" id="sidebar">
    <div class="ml-sidebar-header">
        <a href="/" class="ml-sidebar-brand text-decoration-none"><i class="fas fa-seedling"></i> MarketLink</a>
        <button class="ml-sidebar-close d-lg-none" id="sidebarClose"><i class="fas fa-times"></i></button>
    </div>
    <div class="ml-sidebar-user">
        <img src="<?php echo e(auth()->user()->avatarUrl()); ?>" alt="User" class="ml-sidebar-avatar">
        <div>
            <div class="ml-sidebar-username"><?php echo e(auth()->user()->name); ?></div>
            <div class="ml-sidebar-role">Customer</div>
        </div>
    </div>
    <nav class="ml-sidebar-nav">
        <a href="/customer-dashboard" class="ml-sidebar-link <?php echo e(($active ?? '') === 'dashboard' ? 'active' : ''); ?>"><i class="fas fa-th-large"></i> Dashboard</a>
        <a href="/customer-orders" class="ml-sidebar-link <?php echo e(($active ?? '') === 'orders' ? 'active' : ''); ?>"><i class="fas fa-shopping-bag"></i> My Orders</a>
        <a href="/customer-favorites" class="ml-sidebar-link <?php echo e(($active ?? '') === 'favorites' ? 'active' : ''); ?>"><i class="fas fa-heart"></i> Favorites</a>
        <a href="/customer-profile" class="ml-sidebar-link <?php echo e(($active ?? '') === 'profile' ? 'active' : ''); ?>"><i class="fas fa-user"></i> Profile</a>
        <a href="/customer-reviews" class="ml-sidebar-link <?php echo e(($active ?? '') === 'reviews' ? 'active' : ''); ?>"><i class="fas fa-star"></i> Reviews</a>
            <a href="/notifications" class="ml-sidebar-link <?php echo e(($active ?? '') === 'notifications' ? 'active' : ''); ?>"><i class="fas fa-bell"></i> Notifications</a>
    <hr class="ml-sidebar-divider">
        <form action="/logout" method="POST">
            <?php echo csrf_field(); ?>
            <button type="submit" class="ml-sidebar-link ml-sidebar-logout w-100 border-0 bg-transparent text-start"><i class="fas fa-sign-out-alt"></i> Logout</button>
        </form>
    </nav>
</aside>
<div class="ml-sidebar-overlay" id="sidebarOverlay"></div>
<?php /**PATH /home/user/marketlink-final/resources/views/includes/sidebar-customer.blade.php ENDPATH**/ ?>