<?php $__env->startSection('title', 'Login — MarketLink'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid p-0">
        <div class="row g-0 auth-split-layout">
            <!-- Left Branding Panel -->
            <div class="col-lg-5 d-none d-lg-flex auth-panel-brand flex-column justify-content-center align-items-center p-5 text-center position-relative">
                <div class="position-absolute top-0 start-0 w-100 h-100 opacity-25" style="background: url('/images/img1.jpg') center/cover;"></div>

                <div class="position-relative z-1">
                    <a href="/" class="text-white text-decoration-none d-inline-block mb-4">
                        <h1 class="display-4 fw-bold"><i class="fas fa-seedling me-2"></i>MarketLink</h1>
                    </a>
                    <h3 class="fw-light mb-3">Freshness delivered to your local market.</h3>
                    <p class="text-white-50 px-4">Sign in to your account to pre-order seasonal produce, support local farmers, and manage your favorites.</p>
                </div>

                <div class="position-absolute bottom-0 start-0 w-100 p-4 text-center z-1">
                    <p class="small text-white-50 mb-0">&copy; 2026 MarketLink. All rights reserved.</p>
                </div>
            </div>

            <!-- Right Form Panel -->
            <div class="col-lg-7 d-flex align-items-center justify-content-center p-4 p-md-5">
                <div class="w-100" style="max-width: 450px;">

                    <!-- Mobile Brand Header -->
                    <div class="text-center d-lg-none mb-4">
                        <a href="/" class="text-decoration-none d-inline-block">
                            <h2 class="fw-bold ml-text-green"><i class="fas fa-seedling me-2"></i>MarketLink</h2>
                        </a>
                    </div>

                    <div class="card border-0 shadow-sm rounded-4 p-4 p-md-5">
                        <div class="mb-4">
                            <h3 class="fw-bold mb-1">Client Login</h3>
                            <p class="text-muted small">Sign in to pre-order produce, track pickups and manage your favorites.</p>
                        </div>

                        <form action="/login" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="email" class="form-label fw-medium small">Email Address</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light border-end-0"><i class="far fa-envelope text-muted"></i></span>
                                    <input type="email" name="email" value="<?php echo e(old('email')); ?>" class="form-control bg-light border-start-0 ps-0 <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" placeholder="name@example.com" required>
                                </div>
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-4">
                                <label for="password" class="form-label fw-medium small">Password</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light border-end-0"><i class="fas fa-lock text-muted"></i></span>
                                    <input type="password" name="password" class="form-control bg-light border-start-0 ps-0 border-end-0 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="password" placeholder="••••••••" required>
                                    <button class="btn btn-light border border-start-0 text-muted" type="button" data-toggle-password="password"><i class="far fa-eye"></i></button>
                                </div>
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="d-flex justify-content-end align-items-center mb-4">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="remember" id="rememberMe" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                    <label class="form-check-label small text-muted" for="rememberMe">Remember me</label>
                                </div>
                            </div>

                            <button type="submit" class="btn ml-btn-primary w-100 py-2 mb-4">Login to My Account</button>

                            <p class="text-center small text-muted mb-0">New client? <a href="/register" class="text-success text-decoration-none fw-bold">Create a client account</a></p>
                            <p class="text-center small text-muted mt-3 mb-0 border-top pt-3"><a href="/farmer-login" class="text-secondary text-decoration-none"><i class="fas fa-tractor me-1"></i>Are you a farmer? Farmer login</a></p>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\techproject\project\marketlink-final\resources\views/login.blade.php ENDPATH**/ ?>