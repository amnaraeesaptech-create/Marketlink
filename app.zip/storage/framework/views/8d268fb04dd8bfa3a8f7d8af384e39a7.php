<?php $__env->startSection('title', 'Our Farmers — MarketLink'); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Hero -->
    <section class="hero-section">
        <div class="container">
            <h1>Meet Our Local Farmers</h1>
            <p class="lead mb-4">Connect with the people who grow your food.</p>
        </div>
    </section>

    <!-- Filters Bar -->
    <section class="filters-bar">
        <div class="container">
            <div class="row g-3 align-items-center">
                <div class="col-md-3">
                    <div class="input-group">
                        <span class="input-group-text bg-white"><i class="fa-solid fa-search text-muted"></i></span>
                        <input type="text" id="searchFilter" class="form-control border-start-0 filter-input" placeholder="Search farmers...">
                    </div>
                </div>
                <div class="col-md-2">
                    <select id="locFilter" class="form-select filter-input">
                        <option value="all">All Locations</option>
                        <?php $__currentLoopData = collect($farmers)->pluck('city')->filter()->unique()->sort(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($city); ?>"><?php echo e($city); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <select id="marketFilter" class="form-select filter-input">
                        <option value="all">Select Market</option>
                        <?php $__currentLoopData = $markets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $market): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($market->name); ?>"><?php echo e($market->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <select id="catFilter" class="form-select filter-input">
                        <option value="all">All Categories</option>
                        <?php $__currentLoopData = \App\Models\Category::names(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category); ?>"><?php echo e($category); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <div class="form-check form-switch">
                        <input class="form-check-input filter-input" type="checkbox" id="openTodayFilter">
                        <label class="form-check-label" for="openTodayFilter">Open Today</label>
                    </div>
                </div>
                <div class="col-md-1 text-md-end">
                    <a href="#" id="clearFiltersBtn" class="text-success text-decoration-none small">Clear All</a>
                </div>
            </div>
        </div>
    </section>

    <!-- Main Content -->
    <div class="container my-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h5 class="mb-0 fw-bold" id="resultsCount">Showing <?php echo e(count($farmers)); ?> farmers</h5>
            <div class="d-flex align-items-center gap-2">
                <button id="nearMeBtn" class="btn btn-sm btn-outline-success" title="Sort by distance from your location">
                    <i class="fas fa-location-arrow me-1"></i>Near Me
                </button>
                <span class="me-2 text-muted small">Sort by:</span>
                <select id="farmerSort" class="form-select form-select-sm" style="width: auto;">
                    <option value="rated">Highest Rated</option>
                    <option value="az">A-Z</option>
                    <option value="nearest">Nearest</option>
                </select>
            </div>
        </div>

        <div class="row g-4" id="farmersGrid">
            <?php $__empty_1 = true; $__currentLoopData = $farmers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $farmer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-lg-4 col-md-6 farmer-item"
                     data-name="<?php echo e($farmer['stallName']); ?>"
                     data-loc="<?php echo e($farmer['city']); ?>"
                     data-market="<?php echo e(implode(',', $farmer['markets'])); ?>"
                     data-cat="<?php echo e(implode(',', $farmer['categories'])); ?>"
                     data-rating="<?php echo e($farmer['rating'] ?? 0); ?>"
                     data-lat="<?php echo e($farmer['latitude'] ?? ''); ?>"
                     data-lng="<?php echo e($farmer['longitude'] ?? ''); ?>">
                    <div class="farmer-card">
                        <div class="farmer-img-container">
                            <img src="<?php echo e($farmer['coverImage']); ?>" alt="<?php echo e($farmer['stallName']); ?> cover" class="farmer-cover">
                            <img src="<?php echo e($farmer['image']); ?>" alt="<?php echo e($farmer['stallName']); ?>" class="farmer-avatar img-fluid">
                        </div>
                        <div class="farmer-body">
                            <h3 class="stall-name">
                                <?php echo e($farmer['stallName']); ?>

                                <?php if(in_array(now()->format('l'), $farmer['days'] ?? [])): ?>
                                    <span class="badge bg-success ms-1 align-middle" style="font-size:0.55rem; vertical-align:middle; letter-spacing:0.03em;">
                                        <i class="fas fa-circle me-1" style="font-size:0.45rem;"></i>Open Today
                                    </span>
                                <?php endif; ?>
                                <?php if($farmer['latitude'] && $farmer['longitude']): ?>
                                <span class="ml-dist-badge" style="display:none;"></span>
                                <?php endif; ?>
                            </h3>
                            <div class="farmer-name"><?php echo e($farmer['name']); ?></div>
                            <div class="rating">
                                <?php ($stars = (int) round($farmer['rating'])); ?>
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                    <i class="fa-solid fa-star<?php echo e($i <= $stars ? '' : '-o'); ?>"></i>
                                <?php endfor; ?>
                                <span class="text-muted ms-1 text-dark">
                                    <?php echo e($farmer['rating'] ? number_format($farmer['rating'], 1) : 'New'); ?> (<?php echo e($farmer['reviewCount']); ?>)
                                </span>
                            </div>

                            <div>
                                <span class="market-badge">
                                    <i class="fa-solid fa-location-dot"></i>
                                    <?php echo e($farmer['markets'] ? implode(' • ', array_slice($farmer['markets'], 0, 2)) : 'No market linked'); ?>

                                </span>
                            </div>

                            <div class="days-container mt-2">
                                <?php $__currentLoopData = array_slice($farmer['days'], 0, 4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="day-chip"><?php echo e($day); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php if($farmer['specialties']): ?>
                                    <span class="day-chip"><?php echo e($farmer['specialties']); ?></span>
                                <?php endif; ?>
                            </div>

                            <div class="d-flex justify-content-between align-items-center mt-auto pt-3 border-top">
                                <span class="product-count"><?php echo e($farmer['productCount']); ?> Product<?php echo e($farmer['productCount'] === 1 ? '' : 's'); ?></span>
                                <a href="/farmer-profile?id=<?php echo e($farmer['id']); ?>" class="btn btn-sm btn-success">View Profile</a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12 text-center text-muted py-5">
                    <i class="fa-solid fa-tractor fa-2x mb-3 d-block text-success"></i>
                    No farmer stalls are registered yet.
                    <a href="/farmer-register" class="text-success text-decoration-none fw-semibold">Register the first stall</a>.
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Toast Container -->
    <div class="toast-container position-fixed bottom-0 end-0 p-3">
        <div id="favToast" class="toast align-items-center text-bg-success border-0" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
                <div class="toast-body">
                    Added to favorites!
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
(function () {
    var grid    = document.getElementById('farmersGrid');
    var sortEl  = document.getElementById('farmerSort');
    var nearBtn = document.getElementById('nearMeBtn');

    /* ---- filters ---- */
    function applyFilters() {
        var search  = (document.getElementById('searchFilter')?.value || '').toLowerCase();
        var loc     = document.getElementById('locFilter')?.value || 'all';
        var market  = document.getElementById('marketFilter')?.value || 'all';
        var cat     = document.getElementById('catFilter')?.value || 'all';
        var openNow = document.getElementById('openTodayFilter')?.checked;
        var today   = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'][new Date().getDay()];
        var count   = 0;
        document.querySelectorAll('.farmer-item').forEach(function (el) {
            var name    = (el.dataset.name || '').toLowerCase();
            var elLoc   = el.dataset.loc || '';
            var elMkt   = el.dataset.market || '';
            var elCat   = el.dataset.cat || '';
            var elDays  = el.dataset.days || '';
            var matchS  = !search || name.includes(search);
            var matchL  = loc === 'all' || elLoc === loc;
            var matchM  = market === 'all' || elMkt.includes(market);
            var matchC  = cat === 'all' || elCat.includes(cat);
            var matchO  = !openNow || elDays.includes(today);
            var show    = matchS && matchL && matchM && matchC && matchO;
            el.style.display = show ? '' : 'none';
            if (show) count++;
        });
        var rc = document.getElementById('resultsCount');
        if (rc) rc.textContent = 'Showing ' + count + ' farmers';
    }

    /* ---- sort ---- */
    function doSort(mode) {
        if (!grid) return;
        var items = Array.from(grid.children);
        items.sort(function (a, b) {
            if (mode === 'nearest') {
                var da = parseFloat(a.dataset.dist), db = parseFloat(b.dataset.dist);
                var ha = !isNaN(da), hb = !isNaN(db);
                if (ha && hb) return da - db;
                if (ha) return -1; if (hb) return 1; return 0;
            }
            if (mode === 'az') return (a.dataset.name || '').localeCompare(b.dataset.name || '');
            if (mode === 'rated') return parseFloat(b.dataset.rating || 0) - parseFloat(a.dataset.rating || 0);
            return 0;
        });
        items.forEach(function (c) { grid.appendChild(c); });
    }

    /* ---- geo ---- */
    function activateGeo(lat, lng) {
        if (nearBtn) {
            nearBtn.classList.remove('btn-outline-success');
            nearBtn.classList.add('btn-success');
        }
        window.MLGeo.attachDistanceBadges(lat, lng, {
            items: document.querySelectorAll('.farmer-item'),
            getLat: function (el) { return el.dataset.lat; },
            getLng: function (el) { return el.dataset.lng; },
            badgeClass: 'ml-dist-badge',
            insertInto: function (el, badge) {
                badge.classList.add('ms-2', 'd-inline-block');
                badge.style.display = '';
                var title = el.querySelector('.stall-name');
                if (title) title.appendChild(badge);
            }
        });
        if (sortEl) { sortEl.value = 'nearest'; }
        doSort('nearest');
    }

    if (nearBtn) {
        nearBtn.addEventListener('click', function () {
            nearBtn.disabled = true;
            nearBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>Locating…';
            window.MLGeo.getLocation(
                function (lat, lng) {
                    nearBtn.disabled = false;
                    nearBtn.innerHTML = '<i class="fas fa-location-arrow me-1"></i>Near Me';
                    activateGeo(lat, lng);
                },
                function (code) {
                    nearBtn.disabled = false;
                    nearBtn.innerHTML = '<i class="fas fa-location-arrow me-1"></i>Near Me';
                    if (code === 1) alert('Location permission denied. Please allow location access in your browser.');
                    else alert('Could not get your location. Try again.');
                }
            );
        });
    }

    if (sortEl) {
        sortEl.addEventListener('change', function () { doSort(sortEl.value); });
    }

    ['searchFilter','locFilter','marketFilter','catFilter'].forEach(function (id) {
        document.getElementById(id)?.addEventListener('input', applyFilters);
        document.getElementById(id)?.addEventListener('change', applyFilters);
    });
    document.getElementById('openTodayFilter')?.addEventListener('change', applyFilters);
    document.getElementById('clearFiltersBtn')?.addEventListener('click', function (e) {
        e.preventDefault();
        ['searchFilter','locFilter','marketFilter','catFilter'].forEach(function (id) {
            var el = document.getElementById(id);
            if (el) { el.tagName === 'SELECT' ? el.value = 'all' : el.value = ''; }
        });
        var ot = document.getElementById('openTodayFilter');
        if (ot) ot.checked = false;
        applyFilters();
    });

    /* Auto-activate if location cached or silently request on first visit */
    (function () {
        var cached = null;
        try { cached = JSON.parse(sessionStorage.getItem('ml_user_loc')); } catch (e) {}
        if (cached && cached.lat && cached.lng) {
            activateGeo(cached.lat, cached.lng);
        } else {
            window.MLGeo.getLocation(
                function (lat, lng) { activateGeo(lat, lng); },
                function () { /* denied — user can click Near Me */ }
            );
        }
    })();
})();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\techproject\project\marketlink-final\resources\views/farmers.blade.php ENDPATH**/ ?>