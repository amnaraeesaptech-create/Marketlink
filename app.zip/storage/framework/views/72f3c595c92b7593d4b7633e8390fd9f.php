<?php $__env->startSection('title', 'Admin Reviews - MarketLink'); ?>

<?php $__env->startSection('content'); ?>
<div class="ml-admin-layout">
    <aside class="ml-admin-sidebar" id="adminSidebar">
      <div class="ml-admin-sidebar-header">
        <a href="/" class="ml-admin-brand"><i class="fas fa-seedling"></i> MarketLink</a>
        <span class="ml-admin-badge">Admin</span>
      </div>
      <div class="ml-admin-sidebar-user">
        <img src="<?php echo e(auth()->user()->avatarUrl()); ?>" alt="<?php echo e(auth()->user()->name); ?>">
        <div>
          <div><?php echo e(auth()->user()->name); ?></div>
          <div><?php echo e(auth()->user()->email); ?></div>
        </div>
      </div>
      <nav class="ml-admin-nav">
        <a href="/admin-dashboard" class="ml-admin-nav-link"><i class="fas fa-th-large"></i> Dashboard</a>
        <a href="/admin-farmers" class="ml-admin-nav-link"><i class="fas fa-tractor"></i> Farmers</a>
        <a href="/admin-customers" class="ml-admin-nav-link"><i class="fas fa-users"></i> Customers</a>
        <a href="/admin-markets" class="ml-admin-nav-link"><i class="fas fa-store"></i> Markets</a>
        <a href="/admin-products" class="ml-admin-nav-link"><i class="fas fa-box"></i> Products</a>
        <a href="/admin-orders" class="ml-admin-nav-link"><i class="fas fa-shopping-bag"></i> Orders</a>
        <a href="/admin-reviews" class="ml-admin-nav-link active"><i class="fas fa-star"></i> Reviews</a>
        <a href="/admin-reports" class="ml-admin-nav-link"><i class="fas fa-chart-bar"></i> Reports</a>

        <a href="/admin-categories" class="ml-admin-nav-link"><i class="fas fa-tags"></i> Categories</a>
        <a href="/admin-announcements" class="ml-admin-nav-link"><i class="fas fa-bullhorn"></i> Announcements</a>
        <a href="/notifications" class="ml-admin-nav-link"><i class="fas fa-bell"></i> Notifications</a>
        <hr>
        <form action="/logout" method="POST">
          <?php echo csrf_field(); ?>
          <button type="submit" class="ml-admin-nav-link ml-admin-logout w-100 border-0 bg-transparent text-start"><i class="fas fa-sign-out-alt"></i> Logout</button>
        </form>
      </nav>
    </aside>
    <div class="ml-admin-backdrop" id="adminBackdrop"></div>

    <main class="ml-admin-main">
      <div class="ml-admin-topbar">
        <div class="ml-admin-topbar-left">
          <button class="ml-admin-toggle" type="button" data-admin-menu aria-controls="adminSidebar" aria-expanded="false" aria-label="Toggle navigation"><i class="fas fa-bars"></i></button>
          
          <h4 class="m-0 fw-bold">Review Moderation</h4>
        </div>
      </div>

      <div class="ml-admin-content">
        
        <div class="admin-card mb-4">
          <div class="admin-card-body d-flex gap-3">
            <select class="form-select w-auto" data-card-select>
              <option value="">All Ratings</option>
              <option value="5">5 ★</option>
              <option value="4">4 ★</option>
              <option value="3">3 ★</option>
              <option value="2">2 ★</option>
              <option value="1">1 ★</option>
            </select>
            <input type="text" class="form-control" data-card-search placeholder="Search by client, farmer or comment..." style="max-width: 320px;">
            <span class="text-muted small align-self-center" data-card-count></span>
          </div>
        </div>

        <div class="row g-4">
          <?php $__empty_1 = true; $__currentLoopData = $reviews ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <div class="col-md-6 col-xl-4" data-card-item data-rating="<?php echo e((int) $r->rating); ?>" data-search="<?php echo e(strtolower(($r->customer->name ?? '') . ' ' . ($r->farmer->displayName() ?? '') . ' ' . ($r->comment ?? ''))); ?>">
            <div class="admin-card h-100 p-3">
              <div class="d-flex justify-content-between align-items-start mb-3">
                <div class="d-flex gap-2 align-items-center">
                  <img src="<?php echo e($r->customer ? $r->customer->avatarUrl() : \App\Support\Placeholder::initials('Customer')); ?>" class="rounded-circle" style="width:40px;height:40px;object-fit:cover;">
                  <div>
                    <strong><?php echo e($r->customer ? $r->customer->name : 'Customer'); ?></strong><br>
                    <small class="text-muted">Reviewed: <?php echo e($r->farmer ? $r->farmer->displayName() : 'Farmer'); ?></small>
                  </div>
                </div>
              </div>
              <div class="d-flex justify-content-between align-items-center mb-2">
                <div class="text-warning">
                  <?php for($i = 1; $i <= 5; $i++): ?>
                    <i class="<?php echo e($i <= $r->rating ? 'fas' : 'far'); ?> fa-star"></i>
                  <?php endfor; ?>
                </div>
                <span class="badge bg-light text-dark border">
                  <?php if($r->product): ?>
                    <i class="fas fa-box me-1"></i><?php echo e($r->product->name); ?>

                  <?php else: ?>
                    <i class="fas fa-store me-1"></i>Stall review
                  <?php endif; ?>
                </span>
              </div>
              <p class="mb-3 text-muted">&quot;<?php echo e($r->comment ?? 'No comment.'); ?>&quot;</p>
              <?php if($r->hasReply()): ?>
                <div class="p-2 bg-light rounded-3 mb-2">
                  <small class="fw-bold d-block"><i class="fas fa-reply text-success me-1"></i>Farmer reply</small>
                  <small class="text-muted"><?php echo e(\Illuminate\Support\Str::limit($r->farmer_reply, 120)); ?></small>
                </div>
              <?php endif; ?>
              <small class="text-muted d-block mb-1"><?php echo e($r->created_at->format('M d, Y')); ?></small>
              <?php if($r->order): ?><small class="text-muted d-block mb-2">Order <?php echo e($r->order->code()); ?></small><?php endif; ?>
              <div class="d-flex gap-2 mt-2">
                <a href="/farmer-profile?id=<?php echo e($r->farmer_id); ?>" class="btn btn-sm btn-light"><i class="fas fa-tractor me-1"></i>Stall</a>
                <form action="/admin-reviews/<?php echo e($r->id); ?>" method="POST" onsubmit="return confirm('Remove this review permanently? (SRS content moderation)')">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button class="btn btn-sm btn-outline-danger"><i class="fas fa-trash me-1"></i>Remove review</button>
                </form>
              </div>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <div class="col-12">
            <div class="admin-card p-4 text-center text-muted" data-card-noresult>
              No reviews yet. Reviews are written by clients after a completed pickup, and appear here instantly.
            </div>
          </div>
          <?php endif; ?>
        </div>

      </div>
    </main>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\techproject\project\marketlink-final\resources\views/admin/reviews.blade.php ENDPATH**/ ?>