<?php $__env->startSection('title', 'Announcements — Admin'); ?>

<?php $__env->startSection('content'); ?>
<div class="ml-admin-layout">
  <aside class="ml-admin-sidebar" id="adminSidebar">
    <div class="ml-admin-sidebar-header">
      <a href="/" class="ml-admin-brand"><i class="fas fa-seedling"></i> MarketLink</a>
      <span class="ml-admin-badge">Admin</span>
    </div>
    <div class="ml-admin-sidebar-user">
      <img src="<?php echo e(auth()->user()->avatarUrl()); ?>" alt="<?php echo e(auth()->user()->name); ?>">
      <div>
        <div><?php echo e(auth()->user()->name); ?></div>
        <div><?php echo e(auth()->user()->email); ?></div>
      </div>
    </div>
    <nav class="ml-admin-nav">
      <a href="/admin-dashboard" class="ml-admin-nav-link"><i class="fas fa-th-large"></i> Dashboard</a>
      <a href="/admin-farmers" class="ml-admin-nav-link"><i class="fas fa-tractor"></i> Farmers</a>
      <a href="/admin-customers" class="ml-admin-nav-link"><i class="fas fa-users"></i> Customers</a>
      <a href="/admin-markets" class="ml-admin-nav-link"><i class="fas fa-store"></i> Markets</a>
      <a href="/admin-products" class="ml-admin-nav-link"><i class="fas fa-box"></i> Products</a>
      <a href="/admin-orders" class="ml-admin-nav-link"><i class="fas fa-shopping-bag"></i> Orders</a>
      <a href="/admin-reviews" class="ml-admin-nav-link"><i class="fas fa-star"></i> Reviews</a>
      <a href="/admin-reports" class="ml-admin-nav-link"><i class="fas fa-chart-bar"></i> Reports</a>

      <a href="/admin-categories" class="ml-admin-nav-link"><i class="fas fa-tags"></i> Categories</a>
      <a href="/admin-announcements" class="ml-admin-nav-link active"><i class="fas fa-bullhorn"></i> Announcements</a>
      <a href="/notifications" class="ml-admin-nav-link"><i class="fas fa-bell"></i> Notifications</a>
      <hr>
      <form action="/logout" method="POST">
        <?php echo csrf_field(); ?>
        <button type="submit" class="ml-admin-nav-link ml-admin-logout w-100 border-0 bg-transparent text-start"><i class="fas fa-sign-out-alt"></i> Logout</button>
      </form>
    </nav>
  </aside>
  <div class="ml-admin-backdrop" id="adminBackdrop"></div>

  <main class="ml-admin-main">
    <div class="ml-admin-topbar">
      <div class="ml-admin-topbar-left">
        <button class="ml-admin-toggle" type="button" data-admin-menu aria-controls="adminSidebar" aria-expanded="false" aria-label="Toggle navigation"><i class="fas fa-bars"></i></button>
        <div>
          <h4 class="m-0 fw-bold">Platform Announcements</h4>
          <small class="text-muted">Publish a notice — it appears as a banner for the chosen audience and can also be sent as an alert.</small>
        </div>
      </div>
    </div>

    <div class="ml-admin-content">
      <div class="row g-4 mb-4">
        <div class="col-6 col-lg-3">
          <div class="admin-stat-card">
            <div class="admin-stat-icon icon-blue"><i class="fas fa-bullhorn"></i></div>
            <div class="admin-stat-info"><p>Announcements</p><h3><?php echo e($announcements->count()); ?></h3></div>
          </div>
        </div>
        <div class="col-6 col-lg-3">
          <div class="admin-stat-card">
            <div class="admin-stat-icon icon-green"><i class="fas fa-eye"></i></div>
            <div class="admin-stat-info"><p>Live now</p><h3><?php echo e($announcements->where('is_active', true)->count()); ?></h3></div>
          </div>
        </div>
        <div class="col-6 col-lg-3">
          <div class="admin-stat-card">
            <div class="admin-stat-icon icon-amber"><i class="fas fa-bell"></i></div>
            <div class="admin-stat-info"><p>Alerts Sent</p><h3><?php echo e($sentCount); ?></h3></div>
          </div>
        </div>
        <div class="col-6 col-lg-3">
          <div class="admin-stat-card">
            <div class="admin-stat-icon icon-purple"><i class="fas fa-users"></i></div>
            <div class="admin-stat-info"><p>Accounts</p><h3><?php echo e(\App\Models\User::whereIn('role', ['farmer', 'customer'])->count()); ?></h3></div>
          </div>
        </div>
      </div>

      <div class="admin-card">
        <div class="admin-card-header">
          <h5>All announcements (<?php echo e($announcements->count()); ?>)</h5>
          <button class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#announcementModal" onclick="resetAnnouncementForm()">
            <i class="fas fa-plus"></i> New Announcement
          </button>
        </div>
        <div class="table-responsive">
          <table class="table admin-table table-hover mb-0" id="adminAnnouncementsTable" data-filterable>
            <thead>
              <tr><th>#</th><th>Title</th><th>Message</th><th>Audience</th><th>Published</th><th>Status</th><th>Actions</th></tr>
            </thead>
            <tbody>
              <?php $__empty_1 = true; $__currentLoopData = $announcements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                  <td><?php echo e($loop->iteration); ?></td>
                  <td><strong><?php echo e($a->title); ?></strong></td>
                  <td class="text-muted"><?php echo e(\Illuminate\Support\Str::limit($a->body, 70)); ?></td>
                  <td><span class="badge badge-pending"><?php echo e($a->audienceLabel()); ?></span></td>
                  <td class="text-nowrap"><?php echo e($a->published_at?->format('M j, Y g:i A') ?? '—'); ?></td>
                  <td><span class="badge <?php echo e($a->is_active ? 'badge-active' : 'badge-inactive'); ?>"><?php echo e($a->is_active ? 'Live' : 'Hidden'); ?></span></td>
                  <td class="text-nowrap">
                    <button class="btn btn-sm btn-light" data-bs-toggle="modal" data-bs-target="#announcementModal"
                            data-announcement="<?php echo e(json_encode([
                                'id' => $a->id, 'title' => $a->title, 'body' => $a->body,
                                'audience' => $a->audience, 'is_active' => $a->is_active,
                            ], JSON_HEX_APOS | JSON_HEX_QUOT)); ?>" onclick="fillAnnouncementForm(this)"><i class="fas fa-pen"></i></button>
                    <form action="/admin-announcements/<?php echo e($a->id); ?>" method="POST" class="d-inline" onsubmit="return confirm('Delete this announcement?');">
                      <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                      <button class="btn btn-sm btn-light text-danger"><i class="fas fa-trash"></i></button>
                    </form>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr data-filter-empty="1">
                  <td colspan="7" class="text-center text-muted py-4">
                    Nothing published yet. Use “New Announcement” to broadcast market timings, holidays or platform news.
                  </td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </main>
</div>

<div class="modal fade" id="announcementModal" tabindex="-1">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <form action="/admin-announcements" method="POST" id="announcementForm">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="_method" id="announcementMethod" value="POST">
        <div class="modal-header">
          <h5 class="modal-title" id="announcementModalTitle">New Announcement</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label class="form-label" for="anTitle">Title *</label>
            <input type="text" class="form-control" name="title" id="anTitle" required placeholder="e.g. Friday market moves to 2 PM">
          </div>
          <div class="mb-3">
            <label class="form-label" for="anBody">Message *</label>
            <textarea class="form-control" name="body" id="anBody" rows="3" required placeholder="What should people know?"></textarea>
          </div>
          <div class="row g-3">
            <div class="col-md-6">
              <label class="form-label" for="anAudience">Audience</label>
              <select class="form-select" name="audience" id="anAudience">
                <?php $__currentLoopData = $audiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($value); ?>"><?php echo e($label); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <div class="col-md-6 d-flex flex-column justify-content-center gap-2">
              <div class="form-check">
                <input class="form-check-input" type="checkbox" name="is_active" value="1" id="anActive" checked>
                <label class="form-check-label" for="anActive">Publish banner now</label>
              </div>
              <div class="form-check" id="notifyWrap">
                <input class="form-check-input" type="checkbox" name="notify" value="1" id="anNotify" checked>
                <label class="form-check-label" for="anNotify">Also send as an in-app alert</label>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-success" id="announcementSubmit">Publish</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
  function resetAnnouncementForm() {
    document.getElementById('announcementModalTitle').textContent = 'New Announcement';
    document.getElementById('announcementSubmit').textContent = 'Publish';
    document.getElementById('announcementForm').action = '/admin-announcements';
    document.getElementById('announcementMethod').value = 'POST';
    document.getElementById('anTitle').value = '';
    document.getElementById('anBody').value = '';
    document.getElementById('anAudience').value = 'all';
    document.getElementById('anActive').checked = true;
    document.getElementById('anNotify').checked = true;
    document.getElementById('notifyWrap').style.display = '';
  }
  function fillAnnouncementForm(btn) {
    var d = JSON.parse(btn.dataset.announcement);
    document.getElementById('announcementModalTitle').textContent = 'Edit announcement';
    document.getElementById('announcementSubmit').textContent = 'Save changes';
    document.getElementById('announcementForm').action = '/admin-announcements/' + d.id;
    document.getElementById('announcementMethod').value = 'PUT';
    document.getElementById('anTitle').value = d.title || '';
    document.getElementById('anBody').value = d.body || '';
    document.getElementById('anAudience').value = d.audience || 'all';
    document.getElementById('anActive').checked = !!d.is_active;
    document.getElementById('notifyWrap').style.display = 'none';
  }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\techproject\project\marketlink-final\resources\views/admin/announcements.blade.php ENDPATH**/ ?>