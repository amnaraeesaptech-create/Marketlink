<?php $__env->startSection('title', 'MarketLink - My Reviews'); ?>

<?php $__env->startSection('content'); ?>
<div class="dashboard-layout">
    <!-- Sidebar -->
    <aside class="ml-sidebar ml-sidebar-customer" id="sidebar">
      <div class="ml-sidebar-header">
        <a href="/" class="ml-sidebar-brand"><i class="fas fa-seedling"></i> MarketLink</a>
        <button class="ml-sidebar-close d-lg-none" id="sidebarClose"><i class="fas fa-times"></i></button>
      </div>
      <div class="ml-sidebar-user">
        <img src="<?php echo e(auth()->user()->avatarUrl()); ?>" alt="Customer" class="ml-sidebar-avatar">
        <div>
          <div class="ml-sidebar-username"><?php echo e(auth()->user()->displayName()); ?></div>
          <div class="ml-sidebar-role">Customer</div>
        </div>
      </div>
      <nav class="ml-sidebar-nav">
        <a href="/customer-dashboard" class="ml-sidebar-link"><i class="fas fa-chart-pie"></i> Dashboard</a>
        <a href="/customer-profile" class="ml-sidebar-link"><i class="fas fa-user-edit"></i> My Profile</a>
        <a href="/customer-orders" class="ml-sidebar-link"><i class="fas fa-shopping-bag"></i> My Orders</a>
        <a href="/products" class="ml-sidebar-link"><i class="fas fa-store"></i> Browse Products</a>
        <a href="/customer-favorites" class="ml-sidebar-link"><i class="fas fa-heart"></i> Favorites</a>
        <a href="/customer-reviews" class="ml-sidebar-link active"><i class="fas fa-star"></i> My Reviews</a>
        <a href="/customer-profile" class="ml-sidebar-link"><i class="fas fa-cog"></i> Settings</a>
        <hr class="ml-sidebar-divider">
        <form action="/logout" method="POST">
            <?php echo csrf_field(); ?>
            <button type="submit" class="ml-sidebar-link ml-sidebar-logout w-100 border-0 bg-transparent text-start"><i class="fas fa-sign-out-alt"></i> Logout</button>
        </form>
      </nav>
    </aside>

    <!-- Main Content -->
    <div class="dashboard-main">
      <div class="dashboard-topbar">
        <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
        <div class="d-flex align-items-center gap-3">
          <a href="/cart" class="btn btn-light position-relative"><i class="fas fa-shopping-cart"></i></a>
          <img src="<?php echo e(auth()->user()->avatarUrl()); ?>" alt="User" class="rounded-circle border" width="40" height="40">
        </div>
      </div>

      <div class="dashboard-content">
        <div class="mb-4">
          <h2 class="h4 fw-bold mb-0">My Reviews</h2>
          <p class="text-muted mb-0 small">Farmers you rated after completed pickups.</p>
        </div>

        <?php $__empty_1 = true; $__currentLoopData = $reviews ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <div class="card border-0 shadow-sm rounded-3 mb-3 p-4">
            <div class="d-flex gap-3">
              <img src="<?php echo e($r->farmer ? $r->farmer->avatarUrl() : \App\Support\Placeholder::initials($r->farmer?->displayName() ?? 'Farmer')); ?>" class="rounded-circle flex-shrink-0" width="50" height="50" alt="F" style="object-fit: cover;">
              <div class="flex-grow-1">
                <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
                  <div>
                    <div class="fw-bold"><?php echo e($r->farmer ? $r->farmer->displayName() : 'Farmer'); ?></div>
                    <div class="small text-muted"><?php echo e($r->created_at->diffForHumans()); ?><?php if($r->order): ?> &bull; Order <?php echo e($r->order->code()); ?><?php endif; ?></div>
                  </div>
                  <div class="d-flex align-items-center gap-2">
                    <div class="text-warning">
                      <?php for($i = 1; $i <= 5; $i++): ?>
                        <i class="fas fa-star <?php echo e($i <= $r->rating ? '' : 'text-muted opacity-25'); ?>"></i>
                      <?php endfor; ?>
                    </div>
                    <form action="/reviews/<?php echo e($r->id); ?>" method="POST" class="d-inline" onsubmit="return confirm('Delete this review?')">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field('DELETE'); ?>
                      <button type="submit" class="btn btn-sm btn-light border text-danger" title="Delete review"><i class="fas fa-trash"></i></button>
                    </form>
                  </div>
                </div>
                <?php if($r->comment): ?>
                  <p class="mt-2 mb-0"><?php echo e($r->comment); ?></p>
                <?php endif; ?>
              </div>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <div class="card border-0 shadow-sm rounded-3 mb-3">
            <div class="card-body text-center py-5 text-muted">
              <i class="fas fa-star fa-2x mb-3 d-block"></i>
              You have not written any reviews yet. Completed orders can be reviewed from <a href="/customer-orders" class="text-success fw-medium">My Orders</a>.
            </div>
          </div>
        <?php endif; ?>

      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', () => {
      const sidebar = document.getElementById('sidebar');
      const sidebarToggle = document.getElementById('sidebarToggle');
      const sidebarClose = document.getElementById('sidebarClose');
      if (sidebarToggle) sidebarToggle.addEventListener('click', () => sidebar.classList.add('show'));
      if (sidebarClose) sidebarClose.addEventListener('click', () => sidebar.classList.remove('show'));
    });
  </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/user/marketlink-final/resources/views/customer/reviews.blade.php ENDPATH**/ ?>