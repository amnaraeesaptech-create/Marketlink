<?php $__env->startSection('title', 'Notifications — MarketLink'); ?>

<?php $__env->startSection('content'); ?>
<div class="dashboard-layout">
    <?php if(auth()->guard()->check()): ?>
        <?php if(auth()->user()->isFarmer()): ?>
            <?php echo $__env->make('includes.sidebar-farmer', ['active' => 'notifications'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php elseif(auth()->user()->isCustomer()): ?>
            <?php echo $__env->make('includes.sidebar-customer', ['active' => 'notifications'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php else: ?>
            <aside class="ml-sidebar" id="sidebar">
                <div class="ml-sidebar-header">
                    <a href="/" class="ml-sidebar-brand"><i class="fas fa-seedling"></i> MarketLink</a>
                    <button class="ml-sidebar-close d-lg-none" id="sidebarClose"><i class="fas fa-times"></i></button>
                </div>
                <div class="ml-sidebar-user">
                    <img src="<?php echo e(auth()->user()->avatarUrl()); ?>" alt="Admin" class="ml-sidebar-avatar">
                    <div>
                        <div class="ml-sidebar-username"><?php echo e(auth()->user()->name); ?></div>
                        <div class="ml-sidebar-role">Admin</div>
                    </div>
                </div>
                <nav class="ml-sidebar-nav">
                    <a href="/admin-dashboard" class="ml-sidebar-link"><i class="fas fa-th-large"></i> Dashboard</a>
                    <a href="/admin-farmers" class="ml-sidebar-link"><i class="fas fa-tractor"></i> Farmers</a>
                    <a href="/admin-products" class="ml-sidebar-link"><i class="fas fa-box"></i> Products</a>
                    <a href="/admin-reviews" class="ml-sidebar-link"><i class="fas fa-star"></i> Reviews</a>
                    <a href="/admin-categories" class="ml-sidebar-link"><i class="fas fa-tags"></i> Categories</a>
                    <a href="/admin-announcements" class="ml-sidebar-link"><i class="fas fa-bullhorn"></i> Announcements</a>
                    <a href="/notifications" class="ml-sidebar-link active"><i class="fas fa-bell"></i> Notifications</a>
                    <hr class="ml-sidebar-divider">
                    <form action="/logout" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="ml-sidebar-link ml-sidebar-logout w-100 border-0 bg-transparent text-start"><i class="fas fa-sign-out-alt"></i> Logout</button>
                    </form>
                </nav>
            </aside>
            <div class="ml-sidebar-overlay" id="sidebarOverlay"></div>
        <?php endif; ?>
    <?php endif; ?>

    <div class="dashboard-main">
        <div class="dashboard-topbar">
            <button class="sidebar-toggle" id="sidebarToggle"><i class="fas fa-bars"></i></button>
            <h1 class="ml-topbar-title">Notifications</h1>
            <form action="/notifications/read-all" method="POST">
                <?php echo csrf_field(); ?>
                <button class="btn btn-sm btn-outline-success" <?php echo e($unread ? '' : 'disabled'); ?>>
                    <i class="fas fa-check-double me-1"></i>Mark all read
                </button>
            </form>
        </div>

        <div class="dashboard-content">
            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
                <h2 class="h5 mb-0 fw-bold">
                    Your alerts
                    <?php if($unread): ?><span class="badge bg-danger ms-1"><?php echo e($unread); ?> unread</span><?php endif; ?>
                </h2>
                <span class="text-muted small">Order updates, restock alerts and replies — all stored when they happen.</span>
            </div>

            <?php if($announcements->isNotEmpty()): ?>
                <div class="card border-0 shadow-sm rounded-3 mb-4">
                    <div class="card-header bg-white border-bottom p-3">
                        <h3 class="card-header-title mb-0"><i class="fas fa-bullhorn text-success me-2"></i>Platform announcements</h3>
                    </div>
                    <ul class="list-group list-group-flush">
                        <?php $__currentLoopData = $announcements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item py-3">
                                <div class="d-flex justify-content-between align-items-start gap-2">
                                    <div>
                                        <h6 class="mb-1 fw-bold"><?php echo e($a->title); ?></h6>
                                        <p class="mb-1 small text-muted"><?php echo e($a->body); ?></p>
                                        <small class="text-muted"><?php echo e($a->published_at?->format('M j, Y g:i A')); ?></small>
                                    </div>
                                    <span class="badge bg-success-subtle text-success"><?php echo e($a->audienceLabel()); ?></span>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div class="card border-0 shadow-sm rounded-3">
                <div class="card-body p-0">
                    <ul class="list-group list-group-flush">
                        <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li class="list-group-item py-3 <?php echo e($n->isUnread() ? 'bg-success bg-opacity-10' : ''); ?>">
                                <div class="d-flex gap-3">
                                    <div class="stat-icon bg-success bg-opacity-10 text-success mb-0" style="width:38px;height:38px;font-size:.95rem;">
                                        <i class="fas <?php echo e($n->icon()); ?>"></i>
                                    </div>
                                    <div class="flex-grow-1 min-w-0">
                                        <div class="d-flex justify-content-between gap-2 flex-wrap">
                                            <h6 class="mb-1 fw-semibold"><?php echo e($n->title); ?></h6>
                                            <small class="text-muted"><?php echo e($n->created_at->diffForHumans()); ?></small>
                                        </div>
                                        <?php if($n->body): ?><p class="mb-2 small text-muted"><?php echo e($n->body); ?></p><?php endif; ?>
                                        <div class="d-flex gap-2">
                                            <?php if($n->url): ?>
                                                <form action="/notifications/<?php echo e($n->id); ?>/read" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <button class="btn btn-sm btn-success">Open</button>
                                                </form>
                                            <?php endif; ?>
                                            <?php if($n->isUnread()): ?>
                                                <form action="/notifications/<?php echo e($n->id); ?>/read" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <button class="btn btn-sm btn-outline-secondary">Mark read</button>
                                                </form>
                                            <?php else: ?>
                                                <span class="badge bg-light text-muted align-self-center">Read</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <li class="list-group-item py-4 text-center text-muted">
                                No notifications yet. Placing a pre-order, a farmer accepting it, a restock or a review reply all show up here.
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>

            <div class="mt-3"><?php echo e($notifications->links()); ?></div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/user/marketlink-final/resources/views/notifications.blade.php ENDPATH**/ ?>