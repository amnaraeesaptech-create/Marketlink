<?php $__env->startSection('title', 'MarketLink - Farmer Registration'); ?>

<?php $__env->startSection('no-navbar', '1'); ?>

<?php $__env->startSection('content'); ?>
<div class="split-layout">
    <div class="split-left">
      <div class="mb-auto">
        <h2 class="fw-bold"><i class="fas fa-seedling"></i> MarketLink</h2>
        <span class="badge bg-light text-success mb-3 fs-6">Farmer Portal</span>
      </div>
      <div class="my-5">
        <h2 class="fw-bold mb-3">Join our community of local farmers</h2>
        <p class="mb-4">Set up your digital stall in minutes and start selling directly to customers in your area.</p>
        <div class="d-flex align-items-center mb-3">
          <div class="bg-white text-success rounded-circle p-2 me-3"><i class="fas fa-store"></i></div>
          <span>Create your online stall</span>
        </div>
        <div class="d-flex align-items-center mb-3">
          <div class="bg-white text-success rounded-circle p-2 me-3"><i class="fas fa-box-open"></i></div>
          <span>List your fresh products</span>
        </div>
        <div class="d-flex align-items-center mb-3">
          <div class="bg-white text-success rounded-circle p-2 me-3"><i class="fas fa-hand-holding-usd"></i></div>
          <span>Receive direct orders</span>
        </div>
      </div>
      <div class="mt-auto">
        <p class="mb-0 text-white-50">&copy; 2026 MarketLink</p>
      </div>
    </div>
    
    <div class="split-right">
      <div class="auth-form-container">
        <h3 class="fw-bold mb-1">Register as a Farmer</h3>
        <p class="text-muted mb-4">Fill out the details below to create your digital stall.</p>
        
        <form action="/farmer-register" method="POST" id="farmerRegisterForm" class="needs-validation" novalidate>
          <?php echo csrf_field(); ?>
          
          <div class="form-section-title mt-4">Business Information</div>
          <div class="row g-3">
            <div class="col-md-6">
              <label for="stallName" class="form-label">Stall / Business Name *</label>
              <input type="text" name="stall_name" value="<?php echo e(old('stall_name')); ?>" class="form-control <?php $__errorArgs = ['stall_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="stallName" required>
              <?php $__errorArgs = ['stall_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              <div class="invalid-feedback">Please provide your business name.</div>
            </div>
            <div class="col-md-6">
              <label for="contactPerson" class="form-label">Contact Person Name *</label>
              <input type="text" name="contact_person" value="<?php echo e(old('contact_person')); ?>" class="form-control <?php $__errorArgs = ['contact_person'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="contactPerson" required>
              <?php $__errorArgs = ['contact_person'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              <div class="invalid-feedback">Please provide contact person name.</div>
            </div>
            <div class="col-md-6">
              <label for="contactNumber" class="form-label">Contact Number *</label>
              <input type="tel" name="phone" value="<?php echo e(old('phone')); ?>" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="contactNumber" required>
              <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              <div class="invalid-feedback">Please provide a contact number.</div>
            </div>
            <div class="col-md-6">
              <label for="email" class="form-label">Email Address *</label>
              <input type="email" name="email" value="<?php echo e(old('email')); ?>" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="email" required>
              <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              <div class="invalid-feedback">Please provide a valid email.</div>
            </div>
            <div class="col-12">
              <label for="address" class="form-label">Farm / Business Address *</label>
              <input type="text" name="address" value="<?php echo e(old('address')); ?>" class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="address" required>
              <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              <div class="invalid-feedback">Please provide your address.</div>
            </div>
          </div>
          
          <div class="form-section-title mt-4">Market Details</div>
          <div class="mb-3">
            <label class="form-label">Select Market(s) You Operate In *</label>
            <div class="row g-2">
              <?php $__empty_1 = true; $__currentLoopData = $markets ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $market): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <div class="col-md-6">
                <div class="form-check border p-2 rounded">
                  <input class="form-check-input ms-1" type="checkbox" name="markets[]" value="<?php echo e($market->name); ?>" id="market<?php echo e($market->id); ?>" <?php echo e(in_array($market->name, old('markets', [])) ? 'checked' : ''); ?>>
                  <label class="form-check-label ms-2" for="market<?php echo e($market->id); ?>"><?php echo e($market->name); ?> <span class="text-muted small">— <?php echo e($market->city); ?></span></label>
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <div class="col-12 text-muted small">No markets are open yet — an admin adds them from the Markets page.</div>
              <?php endif; ?>
            </div>
          </div>
          
          <div class="mb-3">
            <label class="form-label">Operating Days</label>
            <div class="d-flex flex-wrap gap-2">
              <div class="form-check form-check-inline m-0">
                <input class="btn-check" type="checkbox" name="operating_days[]" value="Mon" id="dayMon" autocomplete="off" <?php echo e(in_array('Mon', old('operating_days', [])) ? 'checked' : ''); ?>>
                <label class="btn btn-outline-success btn-sm" for="dayMon">Mon</label>
              </div>
              <div class="form-check form-check-inline m-0">
                <input class="btn-check" type="checkbox" name="operating_days[]" value="Tue" id="dayTue" autocomplete="off" <?php echo e(in_array('Tue', old('operating_days', [])) ? 'checked' : ''); ?>>
                <label class="btn btn-outline-success btn-sm" for="dayTue">Tue</label>
              </div>
              <div class="form-check form-check-inline m-0">
                <input class="btn-check" type="checkbox" name="operating_days[]" value="Wed" id="dayWed" autocomplete="off" <?php echo e(in_array('Wed', old('operating_days', [])) ? 'checked' : ''); ?>>
                <label class="btn btn-outline-success btn-sm" for="dayWed">Wed</label>
              </div>
              <div class="form-check form-check-inline m-0">
                <input class="btn-check" type="checkbox" name="operating_days[]" value="Thu" id="dayThu" autocomplete="off" <?php echo e(in_array('Thu', old('operating_days', [])) ? 'checked' : ''); ?>>
                <label class="btn btn-outline-success btn-sm" for="dayThu">Thu</label>
              </div>
              <div class="form-check form-check-inline m-0">
                <input class="btn-check" type="checkbox" name="operating_days[]" value="Fri" id="dayFri" autocomplete="off" <?php echo e(in_array('Fri', old('operating_days', [])) ? 'checked' : ''); ?>>
                <label class="btn btn-outline-success btn-sm" for="dayFri">Fri</label>
              </div>
              <div class="form-check form-check-inline m-0">
                <input class="btn-check" type="checkbox" name="operating_days[]" value="Sat" id="daySat" autocomplete="off" <?php echo e(in_array('Sat', old('operating_days', ['Sat', 'Sun'])) ? 'checked' : ''); ?>>
                <label class="btn btn-outline-success btn-sm" for="daySat">Sat</label>
              </div>
              <div class="form-check form-check-inline m-0">
                <input class="btn-check" type="checkbox" name="operating_days[]" value="Sun" id="daySun" autocomplete="off" <?php echo e(in_array('Sun', old('operating_days', ['Sat', 'Sun'])) ? 'checked' : ''); ?>>
                <label class="btn btn-outline-success btn-sm" for="daySun">Sun</label>
              </div>
            </div>
          </div>
          
          <div class="mb-3">
            <label class="form-label">Product Categories *</label>
            <div class="row g-2">
              <?php $__currentLoopData = \App\Models\Category::names(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-auto">
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" name="categories[]" value="<?php echo e($cat); ?>" id="cat-<?php echo e($loop->index); ?>" <?php echo e(in_array($cat, old('categories', [])) ? 'checked' : ''); ?>>
                  <label class="form-check-label" for="cat-<?php echo e($loop->index); ?>"><?php echo e($cat); ?></label>
                </div>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>

          <div class="form-section-title mt-4">Account Security</div>
          <div class="row g-3">
            <div class="col-md-6">
              <label for="password" class="form-label">Password *</label>
              <input type="password" name="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="password" required>
              <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              <div class="invalid-feedback">Please provide a password.</div>
            </div>
            <div class="col-md-6">
              <label for="confirmPassword" class="form-label">Confirm Password *</label>
              <input type="password" name="password_confirmation" class="form-control" id="confirmPassword" required>
              <div class="invalid-feedback" id="passwordFeedback">Passwords do not match.</div>
            </div>
          </div>
          
          <div class="mb-4 mt-4 form-check">
            <input type="checkbox" name="terms" value="1" class="form-check-input <?php $__errorArgs = ['terms'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="terms" required>
            <label class="form-check-label text-muted" for="terms">I agree to the <a href="/about" class="text-success">Terms of Service</a> and <a href="/about" class="text-success">Privacy Policy</a></label>
            <div class="invalid-feedback">You must agree before submitting.</div>
          </div>
          
          <button type="submit" class="btn btn-farmer w-100 py-2 mb-3 fw-semibold">Register</button>
          
          <p class="text-center text-muted">
            Already have a farmer account? <a href="/farmer-login" class="text-success text-decoration-none fw-semibold">Sign In</a>
          </p>
        </form>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    // Form validation
    (function () {
      'use strict'
      var form = document.getElementById('farmerRegisterForm');
      var password = document.getElementById('password');
      var confirmPassword = document.getElementById('confirmPassword');
      
      form.addEventListener('submit', function (event) {
        if (!form.checkValidity()) {
          event.preventDefault();
          event.stopPropagation();
        }
        
        if (password.value !== confirmPassword.value) {
          confirmPassword.setCustomValidity("Passwords don't match");
          event.preventDefault();
          event.stopPropagation();
        } else {
          confirmPassword.setCustomValidity("");
        }
        
        form.classList.add('was-validated');
      }, false);
      
      confirmPassword.addEventListener('input', function() {
        if (password.value !== confirmPassword.value) {
          confirmPassword.setCustomValidity("Passwords don't match");
        } else {
          confirmPassword.setCustomValidity("");
        }
      });
      
      // Ensure at least one market is checked
      const marketCheckboxes = [document.getElementById('market1'), document.getElementById('market2'), document.getElementById('market3')];
      marketCheckboxes.forEach(cb => {
        cb.addEventListener('change', () => {
          const isChecked = marketCheckboxes.some(c => c.checked);
          marketCheckboxes.forEach(c => {
            if (isChecked) {
              c.removeAttribute('required');
            } else {
              c.setAttribute('required', 'required');
            }
          });
        });
      });
      
      // Ensure at least one category is checked
      const catCheckboxes = [document.getElementById('catVeg'), document.getElementById('catFruit'), document.getElementById('catDairy'), document.getElementById('catMeat'), document.getElementById('catBaked')];
      catCheckboxes.forEach(cb => {
        cb.addEventListener('change', () => {
          const isChecked = catCheckboxes.some(c => c.checked);
          catCheckboxes.forEach(c => {
            if (isChecked) {
              c.removeAttribute('required');
            } else {
              c.setAttribute('required', 'required');
            }
          });
        });
      });
    })()
  </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/user/marketlink-final/resources/views/farmer/register.blade.php ENDPATH**/ ?>