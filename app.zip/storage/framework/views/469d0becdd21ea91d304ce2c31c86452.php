<?php $__env->startSection('title', 'Admin Login - MarketLink'); ?>

<?php $__env->startSection('no-navbar', '1'); ?>

<?php $__env->startSection('content'); ?>
<div class="admin-login-wrapper">
    <div class="admin-login-left">
      <i class="fas fa-shield-alt"></i>
      <h2 class="text-white fw-bold">Admin Portal</h2>
      <p class="mt-3 mb-0 text-white-50">Authorized personnel only. Please ensure you are on a secure connection before proceeding.</p>
    </div>
    
    <div class="admin-login-right">
      <div class="admin-login-form">
        <h3 class="mb-4 fw-bold">Admin Login</h3>
        <form action="/admin-login" method="POST">
          <?php echo csrf_field(); ?>
          <div class="mb-3">
            <label class="form-label">Email Address</label>
            <input type="email" name="email" value="<?php echo e(old('email')); ?>" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="admin@marketlink.com" required>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <div class="text-danger small mt-1"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
          <div class="mb-4">
            <label class="form-label">Password</label>
            <input type="password" name="password" class="form-control" placeholder="••••••••" required>
          </div>
          <button type="submit" class="btn btn-success w-100 py-2">Secure Login</button>
        </form>
        <div class="text-center mt-5 text-muted small">
          &copy; 2026 MarketLink Admin. All rights reserved.
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/user/marketlink-final/resources/views/admin/login.blade.php ENDPATH**/ ?>