<?php $__env->startSection('title', 'Admin Products - MarketLink'); ?>

<?php $__env->startSection('content'); ?>
<div class="ml-admin-layout">
    <aside class="ml-admin-sidebar" id="adminSidebar">
      <div class="ml-admin-sidebar-header">
        <a href="/" class="ml-admin-brand"><i class="fas fa-seedling"></i> MarketLink</a>
        <span class="ml-admin-badge">Admin</span>
      </div>
      <div class="ml-admin-sidebar-user">
        <img src="<?php echo e(auth()->user()->avatarUrl()); ?>" alt="<?php echo e(auth()->user()->name); ?>">
        <div>
          <div><?php echo e(auth()->user()->name); ?></div>
          <div><?php echo e(auth()->user()->email); ?></div>
        </div>
      </div>
      <nav class="ml-admin-nav">
        <a href="/admin-dashboard" class="ml-admin-nav-link"><i class="fas fa-th-large"></i> Dashboard</a>
        <a href="/admin-farmers" class="ml-admin-nav-link"><i class="fas fa-tractor"></i> Farmers</a>
        <a href="/admin-customers" class="ml-admin-nav-link"><i class="fas fa-users"></i> Customers</a>
        <a href="/admin-markets" class="ml-admin-nav-link"><i class="fas fa-store"></i> Markets</a>
        <a href="/admin-products" class="ml-admin-nav-link active"><i class="fas fa-box"></i> Products</a>
        <a href="/admin-orders" class="ml-admin-nav-link"><i class="fas fa-shopping-bag"></i> Orders</a>
        <a href="/admin-reviews" class="ml-admin-nav-link"><i class="fas fa-star"></i> Reviews</a>
        <a href="/admin-reports" class="ml-admin-nav-link"><i class="fas fa-chart-bar"></i> Reports</a>

        <a href="/admin-categories" class="ml-admin-nav-link"><i class="fas fa-tags"></i> Categories</a>
        <a href="/admin-announcements" class="ml-admin-nav-link"><i class="fas fa-bullhorn"></i> Announcements</a>
        <a href="/notifications" class="ml-admin-nav-link"><i class="fas fa-bell"></i> Notifications</a>
        <hr>
        <form action="/logout" method="POST">
          <?php echo csrf_field(); ?>
          <button type="submit" class="ml-admin-nav-link ml-admin-logout w-100 border-0 bg-transparent text-start"><i class="fas fa-sign-out-alt"></i> Logout</button>
        </form>
      </nav>
    </aside>
    <div class="ml-admin-backdrop" id="adminBackdrop"></div>

    <main class="ml-admin-main">
      <div class="ml-admin-topbar">
        <div class="ml-admin-topbar-left">
          <button class="ml-admin-toggle" type="button" data-admin-menu aria-controls="adminSidebar" aria-expanded="false" aria-label="Toggle navigation"><i class="fas fa-bars"></i></button>
          
          <h4 class="m-0 fw-bold">Product Moderation</h4>
        </div>
      </div>

      <div class="ml-admin-content">
        
        <div class="admin-card mb-4">
          <div class="admin-card-body d-flex flex-wrap gap-3 align-items-center">
            <input type="text" class="form-control" data-table-filter="#adminProductsTable" placeholder="Search products or farmers..." style="max-width: 300px;">
            <select class="form-select w-auto" data-table-select="#adminProductsTable" data-col="3">
              <option value="">All Categories</option>
              <?php $__currentLoopData = \App\Models\Category::names(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option><?php echo e($cat); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <select class="form-select w-auto" data-table-select="#adminProductsTable" data-col="5">
              <option value="">All Statuses</option>
              <option>Active</option>
              <option>Unavailable</option>
            </select>
            <span class="text-muted small align-self-center ms-auto" data-table-count="#adminProductsTable"></span>
            <button class="btn btn-outline-secondary btn-sm" type="button" data-export-table="#adminProductsTable" data-export-name="marketlink-products"><i class="fas fa-file-export"></i> Export CSV</button>
          </div>
        </div>

        <div class="admin-card">
          <div class="table-responsive">
            <table class="table admin-table table-hover mb-0" id="adminProductsTable" data-filterable>
              <thead>
                <tr>
                  <th>#</th>
                  <th>Product</th>
                  <th>Farmer</th>
                  <th>Category</th>
                  <th>Price</th>
                  <th>Status</th>
                  <th>Moderation</th>
                </tr>
              </thead>
              <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $products ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                  <td><?php echo e($loop->iteration); ?></td>
                  <td>
                    <div class="farmer-avatar-name">
                      <img src="<?php echo e($p->imageUrl()); ?>" alt="Product">
                      <strong><?php echo e($p->name); ?></strong>
                    </div>
                  </td>
                  <td><?php echo e($p->farmer ? $p->farmer->displayName() : '—'); ?></td>
                  <td><?php echo e($p->category); ?></td>
                  <td>PKR <?php echo e(number_format($p->price, 0)); ?>/<?php echo e($p->unit); ?></td>
                  <td>
                    <span class="badge <?php echo e($p->is_available && $p->stock > 0 ? 'badge-active' : 'badge-removed'); ?>"><?php echo e($p->is_available && $p->stock > 0 ? 'Active' : 'Unavailable'); ?></span>
                    <div class="small text-muted mt-1"><i class="fas fa-cubes me-1"></i><?php echo e((int) $p->stock); ?> <?php echo e($p->unit); ?> in stock</div>
                  </td>
                  <td class="text-nowrap">
                    <a href="/product-details?id=<?php echo e($p->id); ?>" class="btn btn-sm btn-light" title="View"><i class="fas fa-eye"></i></a>
                    <a href="/farmer-profile?id=<?php echo e($p->user_id); ?>" class="btn btn-sm btn-light" title="View stall"><i class="fas fa-tractor"></i></a>
                    <form action="/admin-products/<?php echo e($p->id); ?>/moderate" method="POST" class="d-inline"
                          onsubmit="return confirm('<?php echo e($p->is_available ? 'Unpublish' : 'Publish'); ?> &quot;<?php echo e($p->name); ?>&quot;?')">
                      <?php echo csrf_field(); ?>
                      <button class="btn btn-sm <?php echo e($p->is_available ? 'btn-outline-danger' : 'btn-outline-success'); ?>"
                              title="<?php echo e($p->is_available ? 'Unpublish listing' : 'Publish listing'); ?>">
                        <i class="fas <?php echo e($p->is_available ? 'fa-eye-slash' : 'fa-check'); ?>"></i>
                        <?php echo e($p->is_available ? 'Unpublish' : 'Publish'); ?>

                      </button>
                    </form>
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr data-filter-empty="1">
                  <td colspan="7" class="text-center text-muted py-4">
                    No products listed yet. Farmers add them from
                    <a href="/farmer-add-product" class="text-success text-decoration-none">/farmer-add-product</a>
                    and they show up here instantly.
                  </td>
                </tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </main>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/user/marketlink-final/resources/views/admin/products.blade.php ENDPATH**/ ?>