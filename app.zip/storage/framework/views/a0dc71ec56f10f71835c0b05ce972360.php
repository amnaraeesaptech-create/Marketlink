<?php $__env->startSection('title', 'My Profile — MarketLink'); ?>

<?php $__env->startSection('content'); ?>
<div class="ml-dashboard-wrapper d-flex">
    <?php echo $__env->make('includes.sidebar-customer', ['active' => 'profile'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="ml-dashboard-main flex-grow-1" style="height: 100vh; overflow-y: auto;">
        <div class="ml-topbar">
            <button class="ml-topbar-toggle d-lg-none" id="sidebarToggle"><i class="fas fa-bars"></i></button>
            <h1 class="ml-topbar-title">My Profile</h1>
            <div class="ml-topbar-actions">
                <a href="/" class="btn btn-sm btn-outline-success"><i class="fas fa-store me-1"></i> Storefront</a>
            </div>
        </div>

        <div class="ml-dashboard-content">
            <div class="row g-4">
                <!-- Profile card -->
                <div class="col-lg-4">
                    <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
                        <div class="text-center text-white p-4" style="background: linear-gradient(135deg, #183d26, #2b5b3f);">
                            <img src="<?php echo e($user->avatarUrl()); ?>" alt="avatar" class="rounded-circle border border-3 border-white mb-3" width="110" height="110" style="object-fit: cover;">
                            <h4 class="fw-bold mb-0"><?php echo e($user->name); ?></h4>
                            <p class="mb-0 text-white-50 small"><?php echo e($user->email); ?></p>
                            <span class="badge bg-light text-success mt-2"><i class="fas fa-user me-1"></i>Customer</span>
                        </div>
                        <div class="card-body p-4">
                            <div class="d-flex align-items-center gap-3 mb-3">
                                <span class="stat-icon bg-success bg-opacity-10 text-success mb-0"><i class="fas fa-phone"></i></span>
                                <div><div class="small text-muted">Contact Number</div><div class="fw-semibold"><?php echo e($user->phone ?? '—'); ?></div></div>
                            </div>
                            <div class="d-flex align-items-center gap-3 mb-3">
                                <span class="stat-icon bg-success bg-opacity-10 text-success mb-0"><i class="fas fa-location-dot"></i></span>
                                <div><div class="small text-muted">Address</div><div class="fw-semibold"><?php echo e($user->address ?? '—'); ?></div></div>
                            </div>
                            <div class="d-flex align-items-center gap-3">
                                <span class="stat-icon bg-success bg-opacity-10 text-success mb-0"><i class="fas fa-city"></i></span>
                                <div><div class="small text-muted">City</div><div class="fw-semibold"><?php echo e($user->customer->city ?? '—'); ?></div></div>
                            </div>
                            <hr>
                            <p class="small text-muted mb-0"><i class="fas fa-calendar me-1"></i>Member since <?php echo e($user->created_at->format('M Y')); ?></p>
                        </div>
                    </div>
                </div>

                <!-- Edit forms -->
                <div class="col-lg-8">
                    <div class="card border-0 shadow-sm rounded-4 mb-4">
                        <div class="card-body p-4">
                            <h5 class="fw-bold mb-3"><i class="fas fa-pen me-2 text-success"></i>Edit Profile</h5>
                            <form action="/customer-profile" method="POST" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <label class="form-label fw-medium small" for="name">Full Name *</label>
                                        <input type="text" name="name" id="name" value="<?php echo e(old('name', $user->name)); ?>" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label fw-medium small" for="email">Email Address *</label>
                                        <input type="email" name="email" id="email" value="<?php echo e(old('email', $user->email)); ?>" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label fw-medium small" for="phone">Contact Number *</label>
                                        <input type="text" name="phone" id="phone" value="<?php echo e(old('phone', $user->phone)); ?>" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="form-label fw-medium small" for="city">City</label>
                                        <input type="text" name="city" id="city" value="<?php echo e(old('city', $user->customer->city ?? '')); ?>" class="form-control <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label fw-medium small" for="address">Home Address *</label>
                                        <input type="text" name="address" id="address" value="<?php echo e(old('address', $user->address)); ?>" class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                    <div class="col-12">
                                        <label class="form-label fw-medium small" for="avatar">Profile Photo</label>
                                        <input type="file" name="avatar" id="avatar" accept="image/*" class="form-control <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                        <?php $__errorArgs = ['avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="text-danger small mt-1"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <button type="submit" class="btn ml-btn-primary mt-4"><i class="fas fa-save me-2"></i>Save Changes</button>
                            </form>
                        </div>
                    </div>

                    <div class="card border-0 shadow-sm rounded-4">
                        <div class="card-body p-4">
                            <h5 class="fw-bold mb-3"><i class="fas fa-key me-2 text-success"></i>Change Password</h5>
                            <form action="/customer-password" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="row g-3">
                                    <div class="col-md-4">
                                        <label class="form-label fw-medium small" for="current_password">Current Password</label>
                                        <input type="password" name="current_password" id="current_password" class="form-control" required>
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label fw-medium small" for="password">New Password</label>
                                        <input type="password" name="password" id="password" class="form-control" required>
                                    </div>
                                    <div class="col-md-4">
                                        <label class="form-label fw-medium small" for="password_confirmation">Confirm New</label>
                                        <input type="password" name="password_confirmation" id="password_confirmation" class="form-control" required>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-outline-success mt-3">Update Password</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/user/marketlink-final/resources/views/customer/profile.blade.php ENDPATH**/ ?>