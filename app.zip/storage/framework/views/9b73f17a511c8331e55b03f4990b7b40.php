<?php $__env->startSection('title', ($product?->name ?? 'Product') . ' — MarketLink'); ?>

<?php $__env->startSection('content'); ?>
<?php if(!$product): ?>
    <div class="container py-5 text-center">
        <i class="fas fa-seedling fa-3x text-success mb-3"></i>
        <h1 class="h3 fw-bold">No products in the catalogue yet</h1>
        <p class="text-muted">Farmers haven't listed anything for sale. Check back soon.</p>
        <a href="/products" class="btn btn-success">Back to Products</a>
    </div>
<?php else: ?>
<?php ($farmer = $product->farmer); ?>
<!-- Breadcrumb -->
    <div class="bg-light py-2 border-bottom">
        <div class="container">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="/" class="text-decoration-none">Home</a></li>
                    <li class="breadcrumb-item"><a href="/products" class="text-decoration-none">Products</a></li>
                    <li class="breadcrumb-item"><a href="/products" class="text-decoration-none"><?php echo e($product->category); ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($product->name); ?></li>
                </ol>
            </nav>
        </div>
    </div>

    <!-- Main Section -->
    <div class="container py-5">
        <div class="row mb-5">
            <!-- Left: Images -->
            <div class="col-md-7 mb-4 mb-md-0">
                <div class="main-img-container mb-3 shadow-sm" id="img-container">
                    <img src="<?php echo e($product->imageUrl()); ?>" id="main-product-image" class="main-img" alt="<?php echo e($product->name); ?>">
                </div>
                <div class="row g-2">
                    <div class="col-4">
                        <img src="<?php echo e($product->imageUrl()); ?>" class="img-fluid rounded thumbnail active" onclick="changeImage(this)" alt="<?php echo e($product->name); ?>">
                    </div>
                </div>
            </div>

            <!-- Right: Details -->
            <div class="col-md-5">
                <span class="badge bg-success mb-2 px-3 py-2"><?php echo e($product->category); ?></span>
                <h1 class="fw-bold mb-2"><?php echo e($product->name); ?></h1>

                <div class="d-flex align-items-center mb-3">
                    <div class="text-warning me-2">
                        <?php ($rating = (int) round($product->rating ?? 0)); ?>
                        <?php for($i = 1; $i <= 5; $i++): ?>
                            <i class="fa<?php echo e($i <= $rating ? 's' : 'r'); ?> fa-star"></i>
                        <?php endfor; ?>
                    </div>
                    <a href="#nav-reviews" class="text-muted text-decoration-none small" data-bs-toggle="tab" data-bs-target="#nav-reviews">(<?php echo e($productReviews->count()); ?> product rating<?php echo e($productReviews->count() === 1 ? '' : 's'); ?>)</a>
                </div>

                <div class="d-flex align-items-center mb-4 p-3 bg-light rounded border">
                    <img src="<?php echo e($farmer?->avatarUrl()); ?>" class="rounded-circle me-3" width="50" height="50" alt="<?php echo e($farmer?->displayName()); ?>">
                    <div class="flex-grow-1" style="min-width: 0;">
                        <p class="mb-0 fw-bold text-truncate"><a href="/farmer-profile?id=<?php echo e($product->farmer_id); ?>" class="text-dark text-decoration-none"><?php echo e($farmer?->displayName() ?? 'Local Farm'); ?></a></p>
                        <span class="badge bg-secondary text-wrap text-start" style="max-width: 100%;"><?php echo e($farmer?->marketNames() ? implode(', ', array_slice($farmer->marketNames(), 0, 2)) : 'No market linked'); ?></span>
                    </div>
                </div>

                <div class="mb-3">
                    <span class="display-5 fw-bold text-success">Rs <?php echo e(number_format((float) $product->price, 0)); ?></span>
                    <span class="text-muted fs-5">/ <?php echo e($product->unit); ?></span>
                </div>

                <?php if($product->is_available && $product->stock > 0): ?>
                    <p class="text-success small fw-bold mb-4">
                        <i class="fas fa-check-circle me-1"></i> In Stock (<?php echo e($product->stock); ?> <?php echo e($product->unit); ?> available)
                    </p>
                <?php else: ?>
                    <p class="text-danger small fw-bold mb-4"><i class="fas fa-times-circle me-1"></i> Currently unavailable</p>
                <?php endif; ?>

                <p class="text-muted mb-4">
                    <?php echo e($product->description ?: 'This farmer has not added a description for this product yet.'); ?>

                </p>

                <div class="d-flex align-items-center mb-4">
                    <div class="input-group me-3" style="width: 130px;">
                        <button class="btn btn-outline-secondary" type="button" id="btn-minus">-</button>
                        <input type="number" class="form-control text-center" id="qty-input" value="1" min="1" max="<?php echo e(max(1, (int) $product->stock)); ?>">
                        <button class="btn btn-outline-secondary" type="button" id="btn-plus">+</button>
                    </div>
                </div>

                <div class="d-grid gap-2 d-md-flex mb-4">
                    <?php if($product->is_available && $product->stock > 0): ?>
                        <button class="btn btn-success btn-lg flex-grow-1" id="pdp-add-cart" data-id="<?php echo e($product->id); ?>"><i class="fas fa-shopping-cart me-2"></i>Add to Cart</button>
                    <?php else: ?>
                        <button class="btn btn-secondary btn-lg flex-grow-1" disabled><i class="fas fa-ban me-2"></i>Out of Stock</button>
                    <?php endif; ?>
                    <?php if(auth()->guard()->check()): ?>
                        <?php if(auth()->user()->isCustomer()): ?>
                            <form action="/favorites/toggle" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                                <button class="btn btn-outline-danger btn-lg px-4" type="submit" title="Add to favorites"><i class="far fa-heart"></i></button>
                            </form>
                        <?php endif; ?>
                    <?php else: ?>
                        <a href="/login" class="btn btn-outline-danger btn-lg px-4" title="Login as a client to save favorites"><i class="far fa-heart"></i></a>
                    <?php endif; ?>
                </div>

                <div class="card bg-light border-0">
                    <div class="card-body">
                        <div class="d-flex">
                            <i class="fas fa-store text-success fs-3 me-3 mt-1"></i>
                            <div>
                                <h6 class="fw-bold mb-1">
                                    Pickup: <?php echo e($farmer?->marketNames() ? implode(', ', $farmer->marketNames()) : 'market not set'); ?>

                                </h6>
                                <p class="text-muted small mb-0">
                                    <?php echo e($farmer?->pickup_windows ? implode(' • ', $farmer->pickup_windows) : 'Pickup windows are set by the farmer'); ?>

                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tabs -->
        <div class="row mb-5">
            <div class="col-12">
                <nav>
                    <div class="nav nav-tabs" id="nav-tab" role="tablist">
                        <button class="nav-link active text-success fw-bold" id="nav-desc-tab" data-bs-toggle="tab" data-bs-target="#nav-desc" type="button" role="tab">Description</button>
                        <button class="nav-link text-dark fw-bold" id="nav-pickup-tab" data-bs-toggle="tab" data-bs-target="#nav-pickup" type="button" role="tab">Pickup Info</button>
                        <button class="nav-link text-dark fw-bold" id="nav-reviews-tab" data-bs-toggle="tab" data-bs-target="#nav-reviews" type="button" role="tab">Reviews (<?php echo e($farmerReviews->count() + $productReviews->count()); ?>)</button>
                    </div>
                </nav>
                <div class="tab-content p-4 border border-top-0 rounded-bottom bg-white" id="nav-tabContent">
                    <!-- Description -->
                    <div class="tab-pane fade show active" id="nav-desc" role="tabpanel">
                        <h5 class="fw-bold">Product Information</h5>
                        <p><?php echo e($product->description ?: 'No extra product information has been provided by the farmer.'); ?></p>
                        <ul class="mb-0">
                            <li>Category: <?php echo e($product->category); ?></li>
                            <li>Unit: <?php echo e($product->unit); ?></li>
                            <li>Sold by: <?php echo e($farmer?->displayName() ?? 'Local Farm'); ?></li>
                            <li>Stock on hand: <?php echo e($product->stock); ?> <?php echo e($product->unit); ?></li>
                        </ul>
                    </div>

                    <!-- Pickup Info -->
                    <div class="tab-pane fade" id="nav-pickup" role="tabpanel">
                        <h5 class="fw-bold mb-3">Pickup Locations &amp; Times</h5>
                        <div class="table-responsive">
                            <table class="table table-bordered">
                                <thead class="table-light">
                                    <tr>
                                        <th>Market</th>
                                        <th>City</th>
                                        <th>Days</th>
                                        <th>Pickup windows</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $farmer?->markets()->get() ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $market): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($market->name); ?></td>
                                            <td><?php echo e($market->city ?: '—'); ?></td>
                                            <td><?php echo e($market->daysLabel()); ?></td>
                                            <td><?php echo e($farmer->pickup_windows ? implode(' • ', $farmer->pickup_windows) : '—'); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr><td colspan="4" class="text-muted">No pickup market has been linked by this farmer yet.</td></tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <!-- Reviews -->
                    <div class="tab-pane fade" id="nav-reviews" role="tabpanel">
                        <div class="row">
                            <div class="col-md-4 text-center mb-4 border-end">
                                <h6 class="text-muted text-uppercase small mb-1">This product</h6>
                                <h1 class="display-4 fw-bold text-dark mb-0"><?php echo e($productRating ? number_format($productRating, 1) : '—'); ?></h1>
                                <div class="text-warning mb-2">
                                    <?php ($prStars = (int) round($productRating ?? 0)); ?>
                                    <?php for($i = 1; $i <= 5; $i++): ?>
                                        <i class="fa<?php echo e($i <= $prStars ? 's' : 'r'); ?> fa-star"></i>
                                    <?php endfor; ?>
                                </div>
                                <p class="text-muted small mb-3"><?php echo e($productReviews->count()); ?> rating<?php echo e($productReviews->count() === 1 ? '' : 's'); ?> from completed orders</p>
                                <hr>
                                <h6 class="text-muted text-uppercase small mb-1">The stall</h6>
                                <h3 class="fw-bold text-dark mb-0"><?php echo e($farmer?->averageRating() ? number_format($farmer->averageRating(), 1) : '—'); ?></h3>
                                <p class="text-muted small mb-0"><?php echo e($farmerReviews->count()); ?> stall review<?php echo e($farmerReviews->count() === 1 ? '' : 's'); ?></p>
                            </div>
                            <div class="col-md-8">
                                <h6 class="fw-bold mb-3">Ratings for this product (<?php echo e($productReviews->count()); ?>)</h6>
                                <?php $__empty_1 = true; $__currentLoopData = $productReviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="border-bottom pb-3 mb-3">
                                        <div class="d-flex justify-content-between">
                                            <strong><?php echo e($review->customer?->name ?? 'Client'); ?></strong>
                                            <small class="text-muted"><?php echo e($review->created_at?->format('M d, Y')); ?></small>
                                        </div>
                                        <div class="text-warning small mb-2">
                                            <?php for($i = 1; $i <= 5; $i++): ?>
                                                <i class="fa<?php echo e($i <= $review->rating ? 's' : 'r'); ?> fa-star"></i>
                                            <?php endfor; ?>
                                        </div>
                                        <p class="text-muted mb-1"><?php echo e($review->comment ?: 'No comment left.'); ?></p>
                                        <?php if($review->hasReply()): ?>
                                            <div class="p-2 bg-light rounded-3">
                                                <small class="fw-bold d-block"><i class="fas fa-reply text-success me-1"></i><?php echo e($farmer?->displayName()); ?> replied</small>
                                                <small class="text-muted"><?php echo e($review->farmer_reply); ?></small>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <p class="text-muted">This product has no ratings yet — buyers rate it after a completed pickup.</p>
                                <?php endif; ?>

                                <h6 class="fw-bold mt-4 mb-3">Stall reviews (<?php echo e($farmerReviews->count()); ?>)</h6>
                                <?php $__empty_1 = true; $__currentLoopData = $farmerReviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="border-bottom pb-3 mb-3">
                                        <div class="d-flex justify-content-between">
                                            <strong><?php echo e($review->customer?->name ?? 'Client'); ?></strong>
                                            <small class="text-muted"><?php echo e($review->created_at?->format('M d, Y')); ?></small>
                                        </div>
                                        <div class="text-warning small mb-2">
                                            <?php for($i = 1; $i <= 5; $i++): ?>
                                                <i class="fa<?php echo e($i <= $review->rating ? 's' : 'r'); ?> fa-star"></i>
                                            <?php endfor; ?>
                                        </div>
                                        <p class="text-muted mb-1"><?php echo e($review->comment ?: 'No comment left.'); ?></p>
                                        <?php if($review->hasReply()): ?>
                                            <div class="p-2 bg-light rounded-3">
                                                <small class="fw-bold d-block"><i class="fas fa-reply text-success me-1"></i><?php echo e($farmer?->displayName()); ?> replied</small>
                                                <small class="text-muted"><?php echo e($review->farmer_reply); ?></small>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <p class="text-muted">No reviews for this stall yet.</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Related Products -->
        <div class="row">
            <div class="col-12">
                <h4 class="fw-bold mb-4">More in <?php echo e($product->category); ?></h4>
                <div class="row g-4">
                    <?php $__empty_1 = true; $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-6 col-md-3">
                            <div class="card h-100 border-0 shadow-sm">
                                <img src="<?php echo e($item->imageUrl()); ?>" class="card-img-top" style="height:160px;object-fit:cover" alt="<?php echo e($item->name); ?>">
                                <div class="card-body">
                                    <h6 class="card-title fw-bold"><a href="/product-details?id=<?php echo e($item->id); ?>" class="text-dark text-decoration-none"><?php echo e($item->name); ?></a></h6>
                                    <p class="text-muted small mb-1"><?php echo e($item->farmer?->displayName()); ?></p>
                                    <p class="text-success mb-0">Rs <?php echo e(number_format((float) $item->price, 0)); ?> / <?php echo e($item->unit); ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-12 text-muted">No other products in this category.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    /* Live catalogue for the quick-view widgets (real DB rows only). */
    window.ML = window.ML || {};
    window.ML.products = window.ML.products || <?php echo json_encode($products ?? [], 15, 512) ?>;
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\techproject\project\marketlink-final\resources\views/product-details.blade.php ENDPATH**/ ?>