<?php $__env->startSection('title', 'About Us — MarketLink'); ?>

<?php $__env->startSection('content'); ?>
<main>
        <!-- Page Hero -->
        <section class="ml-page-hero text-white py-5" style="background: linear-gradient(135deg, #183d26 0%, #2b5b3f 100%);">
            <div class="container py-5 text-center">
                <h1 class="display-4 fw-bold mb-3">About MarketLink</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb justify-content-center mb-0">
                        <li class="breadcrumb-item"><a href="/" class="text-white-50 text-decoration-none">Home</a></li>
                        <li class="breadcrumb-item active text-white" aria-current="page">About</li>
                    </ol>
                </nav>
            </div>
        </section>

        <!-- Our Story / Mission -->
        <section class="py-5">
            <div class="container py-4">
                <div class="row g-5 align-items-center">
                    <div class="col-lg-6">
                        <h2 class="fw-bold mb-4">Our Mission & Story</h2>
                        <div class="ml-underline mb-4"></div>
                        <p class="lead text-muted mb-4">MarketLink was founded on a simple belief: access to fresh, local food shouldn't be difficult, and supporting local farmers should be rewarding.</p>
                        <p class="text-muted mb-4">We started in 2023 when a group of market enthusiasts realized how hard it was to know which farmers would be at their local market, and what produce they would have available. By creating a centralized platform, we bridge the gap between hard-working farmers and communities looking for fresh, sustainable, and locally grown food.</p>
                        
                        <div class="row g-3 mt-2">
                            <div class="col-md-6">
                                <div class="bg-light p-4 rounded-4 h-100 border-start border-success border-4">
                                    <h5 class="fw-bold"><i class="fas fa-bullseye text-success me-2"></i> Our Mission</h5>
                                    <p class="small text-muted mb-0">To empower local agriculture by connecting farmers directly with their communities.</p>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="bg-light p-4 rounded-4 h-100 border-start border-success border-4">
                                    <h5 class="fw-bold"><i class="fas fa-eye text-success me-2"></i> Our Vision</h5>
                                    <p class="small text-muted mb-0">A world where every community thrives on sustainable, locally sourced food.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <img src="/images/img1.jpg" alt="Local market produce" class="img-fluid rounded-4 shadow-lg object-fit-cover" style="height: 500px; width: 100%;">
                    </div>
                </div>
            </div>
        </section>

        <!-- Detailed How It Works -->
        <section class="py-5 bg-light">
            <div class="container py-4">
                <div class="text-center mb-5">
                    <h2 class="fw-bold mb-2">How MarketLink Works</h2>
                    <div class="ml-underline mx-auto mb-4"></div>
                    <p class="text-muted max-w-700 mx-auto">Our platform is designed to make shopping locally as convenient as shopping at a supermarket, while keeping the authentic farmers market experience.</p>
                </div>
                
                <div class="row g-4 mt-2">
                    <div class="col-md-6 col-lg-3">
                        <div class="card h-100 border-0 shadow-sm rounded-4 text-center p-4">
                            <div class="bg-success-subtle rounded-circle d-inline-flex align-items-center justify-content-center mx-auto mb-4" style="width: 70px; height: 70px;">
                                <i class="fas fa-search fs-3 text-success"></i>
                            </div>
                            <h5 class="fw-bold mb-3">1. Discover</h5>
                            <p class="text-muted small mb-0">Search for farmers markets near you, browse participating farmers, and view their seasonal products before market day.</p>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <div class="card h-100 border-0 shadow-sm rounded-4 text-center p-4">
                            <div class="bg-success-subtle rounded-circle d-inline-flex align-items-center justify-content-center mx-auto mb-4" style="width: 70px; height: 70px;">
                                <i class="fas fa-shopping-cart fs-3 text-success"></i>
                            </div>
                            <h5 class="fw-bold mb-3">2. Pre-Order</h5>
                            <p class="text-muted small mb-0">Add products to your cart and pre-order them online. This guarantees you get what you want before it sells out.</p>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <div class="card h-100 border-0 shadow-sm rounded-4 text-center p-4">
                            <div class="bg-success-subtle rounded-circle d-inline-flex align-items-center justify-content-center mx-auto mb-4" style="width: 70px; height: 70px;">
                                <i class="fas fa-wallet fs-3 text-success"></i>
                            </div>
                            <h5 class="fw-bold mb-3">3. Farmer Confirms</h5>
                            <p class="text-muted small mb-0">The farmer accepts your pre-order and prepares the items. No online payment — you pay in person at pickup.</p>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <div class="card h-100 border-0 shadow-sm rounded-4 text-center p-4">
                            <div class="bg-success-subtle rounded-circle d-inline-flex align-items-center justify-content-center mx-auto mb-4" style="width: 70px; height: 70px;">
                                <i class="fas fa-box-open fs-3 text-success"></i>
                            </div>
                            <h5 class="fw-bold mb-3">4. Pick Up</h5>
                            <p class="text-muted small mb-0">Head to the market, find the farmer's stall, and simply pick up your prepared order. It's fast and easy!</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Benefits Grid -->
        <section class="py-5">
            <div class="container py-4">
                <div class="row g-5">
                    <!-- For Customers -->
                    <div class="col-lg-6">
                        <h3 class="fw-bold mb-4">Benefits for Customers</h3>
                        <div class="row g-4">
                            <div class="col-sm-6">
                                <div class="d-flex flex-column">
                                    <i class="fas fa-leaf fs-2 text-success mb-3"></i>
                                    <h5 class="fw-bold">Peak Freshness</h5>
                                    <p class="text-muted small">Food doesn't travel thousands of miles. It's usually picked within 24 hours of market day.</p>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="d-flex flex-column">
                                    <i class="fas fa-clock fs-2 text-success mb-3"></i>
                                    <h5 class="fw-bold">Save Time</h5>
                                    <p class="text-muted small">Skip the early morning rush. Your pre-ordered items are reserved and waiting for you.</p>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="d-flex flex-column">
                                    <i class="fas fa-users fs-2 text-success mb-3"></i>
                                    <h5 class="fw-bold">Community Connection</h5>
                                    <p class="text-muted small">Meet the people who grow your food and learn about their farming practices.</p>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="d-flex flex-column">
                                    <i class="fas fa-globe-americas fs-2 text-success mb-3"></i>
                                    <h5 class="fw-bold">Lower Footprint</h5>
                                    <p class="text-muted small">Reduce your carbon footprint by supporting local agriculture and reducing packaging waste.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- For Farmers -->
                    <div class="col-lg-6">
                        <div class="bg-success-subtle p-5 rounded-4 h-100">
                            <h3 class="fw-bold mb-4">Benefits for Farmers</h3>
                            <div class="row g-4">
                                <div class="col-sm-6">
                                    <div class="d-flex flex-column bg-white p-3 rounded-3 h-100 shadow-sm">
                                        <i class="fas fa-chart-line fs-3 text-success mb-2"></i>
                                        <h6 class="fw-bold">Predictable Sales</h6>
                                        <p class="text-muted small mb-0">Pre-orders mean you know exactly how much to harvest, reducing costly food waste.</p>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="d-flex flex-column bg-white p-3 rounded-3 h-100 shadow-sm">
                                        <i class="fas fa-bullhorn fs-3 text-success mb-2"></i>
                                        <h6 class="fw-bold">Wider Reach</h6>
                                        <p class="text-muted small mb-0">Get discovered by customers who might not walk past your physical stall.</p>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="d-flex flex-column bg-white p-3 rounded-3 h-100 shadow-sm">
                                        <i class="fas fa-clipboard-check fs-3 text-success mb-2"></i>
                                        <h6 class="fw-bold">Easy Management</h6>
                                        <p class="text-muted small mb-0">Track inventory and manage incoming pre-orders from one dashboard.</p>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="d-flex flex-column bg-white p-3 rounded-3 h-100 shadow-sm">
                                        <i class="fas fa-handshake fs-3 text-success mb-2"></i>
                                        <h6 class="fw-bold">Customer Loyalty</h6>
                                        <p class="text-muted small mb-0">Build lasting relationships with regular buyers through profile updates and reviews.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- Stats Section -->
        <section class="py-5 bg-dark text-white text-center" style="background: linear-gradient(135deg, #183d26 0%, #2b5b3f 100%);">
            <div class="container py-5">
                <div class="row text-center g-4">
                    <div class="col-6 col-md-3">
                        <h2 class="display-5 fw-bold"><?php echo e($stats['markets']); ?></h2>
                        <h5 class="fw-light">Markets Listed</h5>
                    </div>
                    <div class="col-6 col-md-3">
                        <h2 class="display-5 fw-bold"><?php echo e($stats['farmers']); ?></h2>
                        <h5 class="fw-light">Registered Farmers</h5>
                    </div>
                    <div class="col-6 col-md-3">
                        <h2 class="display-5 fw-bold"><?php echo e($stats['products']); ?></h2>
                        <h5 class="fw-light">Products Available</h5>
                    </div>
                    <div class="col-6 col-md-3">
                        <h2 class="display-5 fw-bold"><?php echo e($stats['orders']); ?></h2>
                        <h5 class="fw-light">Pre-Orders Placed</h5>
                    </div>
                </div>
            </div>
        </section>

        <!-- Team -->
        <section class="py-5">
            <div class="container py-4">
                <div class="text-center mb-5">
                    <h2 class="fw-bold mb-2">Who You'll Meet on MarketLink</h2>
                    <div class="ml-underline mx-auto"></div>
                </div>
                <div class="row g-4 text-center">
                    <div class="col-md-4">
                        <i class="fas fa-tractor fa-2x text-success mb-3"></i>
                        <h5 class="fw-bold"><?php echo e($stats['farmers']); ?> farming families</h5>
                        <p class="text-muted small mb-0">Real stalls with verifiable contact details, markets and operating days — all maintained by the farmers themselves.</p>
                    </div>
                    <div class="col-md-4">
                        <i class="fas fa-store fa-2x text-success mb-3"></i>
                        <h5 class="fw-bold"><?php echo e($stats['markets']); ?> local markets</h5>
                        <p class="text-muted small mb-0">Each market page shows the actual stalls trading there, their products and pickup windows.</p>
                    </div>
                    <div class="col-md-4">
                        <i class="fas fa-star fa-2x text-success mb-3"></i>
                        <h5 class="fw-bold"><?php echo e($stats['reviews']); ?> verified reviews</h5>
                        <p class="text-muted small mb-0">Every review is tied to a completed pickup, so ratings reflect real transactions (average <?php echo e($stats['rating']); ?>/5).</p>
                    </div>
                </div>
            </div>
        </section>

    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/user/marketlink-final/resources/views/about.blade.php ENDPATH**/ ?>