<?php $__env->startSection('title', 'Admin Orders - MarketLink'); ?>

<?php $__env->startSection('content'); ?>
<div class="ml-admin-layout">
    <aside class="ml-admin-sidebar" id="adminSidebar">
      <div class="ml-admin-sidebar-header">
        <a href="/" class="ml-admin-brand"><i class="fas fa-seedling"></i> MarketLink</a>
        <span class="ml-admin-badge">Admin</span>
      </div>
      <div class="ml-admin-sidebar-user">
        <img src="<?php echo e(auth()->user()->avatarUrl()); ?>" alt="<?php echo e(auth()->user()->name); ?>">
        <div>
          <div><?php echo e(auth()->user()->name); ?></div>
          <div><?php echo e(auth()->user()->email); ?></div>
        </div>
      </div>
      <nav class="ml-admin-nav">
        <a href="/admin-dashboard" class="ml-admin-nav-link"><i class="fas fa-th-large"></i> Dashboard</a>
        <a href="/admin-farmers" class="ml-admin-nav-link"><i class="fas fa-tractor"></i> Farmers</a>
        <a href="/admin-customers" class="ml-admin-nav-link"><i class="fas fa-users"></i> Customers</a>
        <a href="/admin-markets" class="ml-admin-nav-link"><i class="fas fa-store"></i> Markets</a>
        <a href="/admin-products" class="ml-admin-nav-link"><i class="fas fa-box"></i> Products</a>
        <a href="/admin-orders" class="ml-admin-nav-link active"><i class="fas fa-shopping-bag"></i> Orders</a>
        <a href="/admin-reviews" class="ml-admin-nav-link"><i class="fas fa-star"></i> Reviews</a>
        <a href="/admin-reports" class="ml-admin-nav-link"><i class="fas fa-chart-bar"></i> Reports</a>

        <a href="/admin-categories" class="ml-admin-nav-link"><i class="fas fa-tags"></i> Categories</a>
        <a href="/admin-announcements" class="ml-admin-nav-link"><i class="fas fa-bullhorn"></i> Announcements</a>
        <a href="/notifications" class="ml-admin-nav-link"><i class="fas fa-bell"></i> Notifications</a>
        <hr>
        <form action="/logout" method="POST">
          <?php echo csrf_field(); ?>
          <button type="submit" class="ml-admin-nav-link ml-admin-logout w-100 border-0 bg-transparent text-start"><i class="fas fa-sign-out-alt"></i> Logout</button>
        </form>
      </nav>
    </aside>
    <div class="ml-admin-backdrop" id="adminBackdrop"></div>

    <main class="ml-admin-main">
      <div class="ml-admin-topbar">
        <div class="ml-admin-topbar-left">
          <button class="ml-admin-toggle" type="button" data-admin-menu aria-controls="adminSidebar" aria-expanded="false" aria-label="Toggle navigation"><i class="fas fa-bars"></i></button>
          
          <h4 class="m-0 fw-bold">Manage Orders</h4>
        </div>
      </div>

      <div class="ml-admin-content">
        
        <!-- Stats -->
        <div class="row g-4 mb-4">
          <div class="col-md-3">
            <div class="admin-stat-card">
              <div class="admin-stat-icon icon-blue"><i class="fas fa-shopping-bag"></i></div>
              <div class="admin-stat-info">
                <p>Total Orders</p>
                <h3><?php echo e($statTotal); ?></h3>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="admin-stat-card">
              <div class="admin-stat-icon icon-amber"><i class="fas fa-clock"></i></div>
              <div class="admin-stat-info">
                <p>Pending</p>
                <h3><?php echo e($statPending); ?></h3>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="admin-stat-card">
              <div class="admin-stat-icon icon-green"><i class="fas fa-check-circle"></i></div>
              <div class="admin-stat-info">
                <p>Completed</p>
                <h3><?php echo e($statCompleted); ?></h3>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="admin-stat-card">
              <div class="admin-stat-icon" style="background:#f8d7da; color:#721c24"><i class="fas fa-times-circle"></i></div>
              <div class="admin-stat-info">
                <p>Cancelled</p>
                <h3><?php echo e($statCancelled); ?></h3>
              </div>
            </div>
          </div>
        </div>

        <div class="admin-card mb-4">
          <div class="admin-card-body d-flex gap-3">
            <input type="text" class="form-control" data-table-filter="#adminOrdersTable" placeholder="Search by order ID, client, farmer..." style="max-width: 340px;">
            <select class="form-select w-auto" data-table-select="#adminOrdersTable" data-col="6">
              <option value="">All Statuses</option>
              <option>Placed</option>
              <option>Accepted</option>
              <option>Ready for Pickup</option>
              <option>Completed</option>
              <option>Cancelled</option>
            </select>
            <span class="text-muted small align-self-center" data-table-count="#adminOrdersTable"></span>
            <button class="btn btn-outline-secondary btn-sm ms-auto" type="button" data-export-table="#adminOrdersTable" data-export-name="marketlink-orders"><i class="fas fa-file-export"></i> Export CSV</button>
          </div>
        </div>

        <div class="admin-card">
          <div class="table-responsive">
            <table class="table admin-table table-hover mb-0" id="adminOrdersTable" data-filterable>
              <thead>
                <tr>
                  <th>Order ID</th>
                  <th>Customer</th>
                  <th>Farmer</th>
                  <th>Products</th>
                  <th>Pickup Date</th>
                  <th>Total</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $orders ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php ($bmap = ['pending' => 'badge-pending', 'confirmed' => 'badge-active', 'ready' => 'badge-active', 'completed' => 'badge-approved', 'cancelled' => 'badge-removed']); ?>
                <tr>
                  <td><strong><?php echo e($o->code()); ?></strong></td>
                  <td><?php echo e($o->customer ? $o->customer->name : '—'); ?></td>
                  <td><?php echo e($o->farmer ? $o->farmer->displayName() : '—'); ?></td>
                  <td title="<?php echo e($o->itemsSummary()); ?>"><?php echo e($o->items->count()); ?> item(s)</td>
                  <td><?php echo e($o->pickup_date ?? '—'); ?></td>
                  <td>PKR <?php echo e(number_format($o->subtotal, 0)); ?></td>
                  <td><span class="badge <?php echo e($bmap[$o->status] ?? 'badge-pending'); ?>"><?php echo e($o->statusLabel()); ?></span></td>
                  <td><button class="btn btn-sm btn-light order-details-btn" data-bs-toggle="modal" data-bs-target="#orderModal" data-code="<?php echo e($o->code()); ?>" data-status="<?php echo e($o->statusLabel()); ?>" data-customer="<?php echo e($o->customer ? $o->customer->name : '—'); ?>" data-farmer="<?php echo e($o->farmer ? $o->farmer->displayName() : '—'); ?>" data-date="<?php echo e($o->pickup_date ?? '—'); ?> <?php echo e($o->pickup_slot ?? ''); ?>" data-total="PKR <?php echo e(number_format($o->subtotal, 0)); ?>" data-items="<?php echo e($o->items->map(fn($i) => $i->qty . ' x ' . $i->name . ' — PKR ' . number_format($i->price * $i->qty, 0))->implode('|')); ?>"><i class="fas fa-eye"></i> Details</button></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr data-filter-empty="1">
                  <td colspan="8" class="text-center text-muted py-4">
                    No orders yet. Pre-orders placed from
                    <a href="/preorder" class="text-success text-decoration-none">/preorder</a>
                    land here the moment a client checks out.
                  </td>
                </tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </main>
  </div>

  <!-- Order Modal -->
  <div class="modal fade" id="orderModal" tabindex="-1">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="orderModalTitle">Order</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <p><strong>Customer:</strong> <span id="omCustomer"></span></p>
          <p><strong>Farmer:</strong> <span id="omFarmer"></span></p>
          <p><strong>Status:</strong> <span id="omStatus"></span></p>
          <p><strong>Pickup:</strong> <span id="omDate"></span></p>
          <hr>
          <h6>Items:</h6>
          <ul class="list-group mb-3" id="omItems"></ul>
          <div class="d-flex justify-content-between fw-bold">
            <span>Total</span>
            <span id="omTotal"></span>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('click', (e) => {
      const btn = e.target.closest('.order-details-btn');
      if (!btn) return;
      const d = btn.dataset;
      document.getElementById('orderModalTitle').textContent = 'Order ' + (d.code || '—');
      document.getElementById('omCustomer').textContent = d.customer || '—';
      document.getElementById('omFarmer').textContent = d.farmer || '—';
      document.getElementById('omStatus').textContent = d.status || '—';
      document.getElementById('omDate').textContent = d.date || '—';
      document.getElementById('omTotal').textContent = d.total || '—';
      const ul = document.getElementById('omItems');
      ul.innerHTML = '';
      const items = (d.items || '').split('|').filter(Boolean);
      if (!items.length) items.push('No line items recorded.');
      items.forEach(t => {
        const li = document.createElement('li');
        li.className = 'list-group-item';
        li.textContent = t;
        ul.appendChild(li);
      });
    });
  </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/user/marketlink-final/resources/views/admin/orders.blade.php ENDPATH**/ ?>