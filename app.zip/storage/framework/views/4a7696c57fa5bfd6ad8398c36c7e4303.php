<?php $__env->startSection('title', 'Local Markets — MarketLink'); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Hero -->
    <section class="hero-section">
        <div class="container">
            <h1>Discover Local Markets</h1>
            <p class="lead mb-4">Find the freshest produce and support local farmers near you.</p>
            <div class="search-wrapper">
                <div class="input-group input-group-lg">
                    <span class="input-group-text bg-white border-end-0"><i class="fa-solid fa-search text-muted"></i></span>
                    <input type="text" id="heroSearch" class="form-control border-start-0" placeholder="Search markets by name or city...">
                    <button class="btn btn-dark px-4" type="button" onclick="document.getElementById('searchInput').value = document.getElementById('heroSearch').value; document.getElementById('searchInput').dispatchEvent(new Event('input'));">Search</button>
                </div>
            </div>
        </div>
    </section>

    <!-- Main Content -->
    <div class="container my-5">
        <div class="row g-4">
            <!-- Left Sidebar (Filters) -->
            <div class="col-lg-3">
                <div class="card border-0 shadow-sm sticky-top" style="top: 100px; z-index: 10;">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h5 class="card-title mb-0 fw-bold">Filters</h5>
                            <button class="btn btn-sm btn-link text-muted text-decoration-none p-0" id="clearFiltersBtn">Clear all</button>
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label fw-semibold">Search</label>
                            <input type="text" class="form-control form-control-sm" id="searchInput" placeholder="Search by name...">
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label fw-semibold">Location</label>
                            <select class="form-select form-select-sm" id="locationFilter">
                                <option value="all">All Locations</option>
                                <?php $__currentLoopData = $markets->pluck('city')->filter()->unique()->sort(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($city); ?>"><?php echo e($city); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label fw-semibold">Operating Days</label>
                            <?php $__currentLoopData = \App\Models\Market::DAYS; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="form-check mb-2">
                                    <input class="form-check-input day-filter" type="checkbox" value="<?php echo e($day); ?>" id="day<?php echo e(substr($day, 0, 3)); ?>">
                                    <label class="form-check-label" for="day<?php echo e(substr($day, 0, 3)); ?>"><?php echo e($day); ?></label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        
                        <button class="btn btn-success w-100" id="applyFiltersBtn">Apply Filters</button>
                    </div>
                </div>
            </div>
            
            <!-- Right Content (Market Cards) -->
            <div class="col-lg-9">
                <div class="d-flex justify-content-between align-items-center mb-4 pb-2 border-bottom">
                    <h6 class="mb-0 text-muted" id="resultsCount">Showing <?php echo e($markets->count()); ?> markets</h6>
                    <div class="d-flex align-items-center">
                        <span class="me-2 text-muted small">Sort by:</span>
                        <select id="marketSort" class="form-select form-select-sm border-0 bg-light" style="width: auto;">
                            <option value="nearest">Nearest</option>
                            <option value="az">A-Z</option>
                            <option value="farmers">Most Farmers</option>
                        </select>
                    </div>
                </div>
                
                <div class="row g-4" id="marketsGrid">
                    <?php $__empty_1 = true; $__currentLoopData = $markets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $market): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-md-6 market-item"
                             data-name="<?php echo e($market->name); ?>"
                             data-location="<?php echo e($market->city); ?>"
                             data-days="<?php echo e(implode(',', $market->days ?? [])); ?>">
                            <div class="market-card">
                                <img src="<?php echo e($market->imageUrl()); ?>" alt="<?php echo e($market->name); ?>">
                                <div class="market-card-body">
                                    <h3 class="market-title"><?php echo e($market->name); ?></h3>
                                    <div class="market-meta">
                                        <div class="mb-1"><i class="fa-solid fa-location-dot"></i> <?php echo e($market->address ?: 'Address not set'); ?><?php if($market->city): ?>, <?php echo e($market->city); ?><?php endif; ?></div>
                                        <div class="mb-1"><i class="fa-regular fa-clock"></i> <?php echo e($market->hoursLabel()); ?></div>
                                        <div><i class="fa-solid fa-users"></i> <?php echo e($market->farmers_count); ?> Farmer<?php echo e($market->farmers_count === 1 ? '' : 's'); ?></div>
                                    </div>
                                    <div class="mb-3">
                                        <?php $__currentLoopData = $market->days ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="chip"><?php echo e($day); ?></span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <div class="mt-auto">
                                        <a href="/market-details?id=<?php echo e($market->id); ?>" class="btn btn-outline-success w-100">View Market</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-12 text-center text-muted py-5">
                            <i class="fa-solid fa-store fa-2x mb-3 d-block text-success"></i>
                            No markets have been added yet.
                        </div>
                    <?php endif; ?>
                </div>


            </div>
        </div>
    </div>

    <!-- Map Section -->
    <section class="map-section">
        <div class="container">
            <div class="text-center mb-4">
                <h2 class="fw-bold">Markets on the Map</h2>
                <p class="text-muted">Find a market conveniently located near you.</p>
            </div>
            <div class="map-container">
                <div class="text-center text-success fw-bold fs-4 position-absolute" style="z-index: 1;">
                    <i class="fa-solid fa-map-location-dot fs-1 mb-2"></i><br>
                    <span class="fs-6"><?php echo e($markets->count()); ?> market<?php echo e($markets->count() === 1 ? '' : 's'); ?> registered</span>
                </div>
                <?php $__currentLoopData = $markets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $market): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="/market-details?id=<?php echo e($market->id); ?>" class="map-marker"
                       style="top: <?php echo e(15 + ($loop->index * 19) % 70); ?>%; left: <?php echo e(18 + ($loop->index * 27) % 68); ?>%; text-decoration: none;"
                       title="<?php echo e($market->name); ?> — <?php echo e($market->farmers_count); ?> stall(s)"><?php echo e($loop->iteration); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                <div class="position-absolute bottom-0 start-50 translate-middle-x mb-3" style="z-index: 2;">
                    <button class="btn btn-light shadow-sm"><i class="fa-solid fa-location-arrow text-success me-2"></i>Use My Location</button>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/user/marketlink-final/resources/views/markets.blade.php ENDPATH**/ ?>