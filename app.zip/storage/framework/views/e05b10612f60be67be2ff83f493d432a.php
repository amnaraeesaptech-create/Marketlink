<?php $__env->startSection('title', ($farmerUser->displayName() ?? 'Stall') . ' — MarketLink'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $firstMarket = $farmerUser->markets()->first();
    $mapLat = ($farmer?->latitude ?? null) ?: ($firstMarket->latitude ?? null);
    $mapLng = ($farmer?->longitude ?? null) ?: ($firstMarket->longitude ?? null);
    $mapLabel = ($farmer?->latitude ?? null) ? 'Stall pin' : 'Market pin';
?>
<!-- Profile Header -->
    <section class="profile-header" style="background-image: url('<?php echo e($farmerUser->farmer?->avatar ? (str_starts_with($farmerUser->farmer->avatar, 'http') ? $farmerUser->farmer->avatar : '/storage/' . $farmerUser->farmer->avatar) : \App\Support\Placeholder::cover($farmerUser->displayName(), 'farmer-' . $farmerUser->id, 1600, 400)); ?>'); background-size: cover; background-position: center;">
        <div class="profile-overlay">
            <div class="container">
                <div class="row align-items-end">
                    <div class="col-md-auto text-center text-md-start mb-3 mb-md-0">
                        <img src="<?php echo e($farmerUser->avatarUrl()); ?>" alt="<?php echo e($farmerUser->displayName()); ?>" class="profile-avatar shadow">
                    </div>
                    <div class="col-md">
                        <h1 class="fw-bold mb-1"><?php echo e($farmerUser->displayName()); ?></h1>
                        <p class="fs-5 text-light mb-2">
                            <?php echo e($farmerUser->name); ?>

                            <?php if($farmer?->address): ?> &bull; <i class="fa-solid fa-location-dot ms-1"></i> <?php echo e($farmer->address); ?><?php endif; ?>
                        </p>
                        <div class="d-flex align-items-center mb-0 gap-3 flex-wrap">
                            <span class="text-warning">
                                <?php ($stars = (int) round($avgRating ?? 0)); ?>
                                <?php for($i = 1; $i <= 5; $i++): ?>
                                    <i class="fa-solid fa-star<?php echo e($i <= $stars ? '' : '-o'); ?>"></i>
                                <?php endfor; ?>
                                <span class="text-light ms-1">
                                    <?php echo e($avgRating ? number_format($avgRating, 1) : 'New'); ?> (<?php echo e($reviewCount); ?> review<?php echo e($reviewCount === 1 ? '' : 's'); ?>)
                                </span>
                            </span>
                            <?php $__currentLoopData = array_slice($farmer?->categories ?? [], 0, 2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="badge bg-success"><?php echo e($category); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="col-md-auto mt-3 mt-md-0 d-flex gap-2 justify-content-center">
                        <?php if($isOwner): ?>
                            <a href="/farmer-profile/edit" class="btn btn-warning"><i class="fas fa-pen me-2"></i>Edit Profile</a>
                            <a href="/farmer-dashboard" class="btn btn-outline-light"><i class="fas fa-chart-pie me-2"></i>Dashboard</a>
                        <?php else: ?>
                            <a href="/products" class="btn btn-success"><i class="fa-solid fa-basket-shopping me-2"></i>Pre-Order Products</a>
                            <?php if(auth()->guard()->check()): ?>
                              <?php if(auth()->user()->isCustomer()): ?>
                                <?php ($isFavFarmer = auth()->user()->favorites()->where('farmer_id', $farmerUser->id)->exists()); ?>
                                <form action="/favorites/toggle" method="POST" class="d-inline">
                                  <?php echo csrf_field(); ?>
                                  <input type="hidden" name="farmer_id" value="<?php echo e($farmerUser->id); ?>">
                                  <button type="submit" class="btn <?php echo e($isFavFarmer ? 'btn-danger' : 'btn-outline-light'); ?>">
                                    <i class="fa<?php echo e($isFavFarmer ? 's' : 'r'); ?> fa-heart me-2"></i><?php echo e($isFavFarmer ? 'Saved' : 'Favourite'); ?>

                                  </button>
                                </form>
                              <?php endif; ?>
                            <?php endif; ?>
                            <a href="/farmers" class="btn btn-outline-light"><i class="fa-solid fa-arrow-left me-2"></i>All Farmers</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Breadcrumb -->
    <div class="bg-light py-2 border-bottom">
        <div class="container">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="/" class="text-success text-decoration-none">Home</a></li>
                    <li class="breadcrumb-item"><a href="/farmers" class="text-success text-decoration-none">Farmers</a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($farmerUser->displayName()); ?></li>
                </ol>
            </nav>
        </div>
    </div>

    <!-- Main Content -->
    <div class="container my-5">
        <div class="row g-5">
            <!-- Left Column -->
            <div class="col-lg-8">
                <div class="card border-0 shadow-sm mb-5">
                    <div class="card-body p-4">
                        <h3 class="fw-bold mb-3">About the Farm</h3>
                        <p class="text-muted">
                            <?php echo e($farmer?->description ?: 'This farmer has not written a farm description yet.'); ?>

                        </p>
                        <h6 class="fw-bold mb-2">Specialties</h6>
                        <?php $__empty_1 = true; $__currentLoopData = $farmer?->categories ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <span class="badge bg-light text-dark border me-1"><?php echo e($category); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <span class="text-muted small">No categories selected yet.</span>
                        <?php endif; ?>
                    </div>
                </div>

                <h3 class="fw-bold mb-4">Available Products (<?php echo e($products->count()); ?>)</h3>
                <div class="row g-4 mb-5">
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-sm-6">
                            <div class="card border-0 shadow-sm h-100">
                                <img src="<?php echo e($product->imageUrl()); ?>" class="card-img-top" style="height:180px;object-fit:cover" alt="<?php echo e($product->name); ?>">
                                <div class="card-body">
                                    <h5 class="fw-bold mb-1">
                                        <a href="/product-details?id=<?php echo e($product->id); ?>" class="text-dark text-decoration-none"><?php echo e($product->name); ?></a>
                                    </h5>
                                    <p class="text-muted small mb-2"><?php echo e($product->category); ?></p>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <span class="fw-bold text-success">PKR <?php echo e(number_format((float) $product->price, 0)); ?> / <?php echo e($product->unit); ?></span>
                                        <span class="badge bg-light text-dark"><?php echo e($product->stock); ?> in stock</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-12 text-muted">This stall has no products listed for sale right now.</div>
                    <?php endif; ?>
                </div>

                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h3 class="fw-bold mb-0">Customer Reviews</h3>
                    <span class="text-muted small"><?php echo e($reviewCount); ?> total &bull; average <?php echo e($avgRating ? number_format($avgRating, 1) : '—'); ?>/5</span>
                </div>
                <?php $__empty_1 = true; $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="card border-0 shadow-sm mb-3">
                        <div class="card-body">
                            <div class="d-flex align-items-center gap-3 mb-2">
                                <img src="<?php echo e($review->customer?->avatarUrl()); ?>" class="rounded-circle" width="44" height="44" alt="<?php echo e($review->customer?->name); ?>">
                                <div>
                                    <h6 class="fw-bold mb-0"><?php echo e($review->customer?->name ?? 'Client'); ?></h6>
                                    <small class="text-muted"><?php echo e($review->created_at?->format('M d, Y')); ?></small>
                                </div>
                                <div class="ms-auto text-warning">
                                    <?php for($i = 1; $i <= 5; $i++): ?>
                                        <i class="fa<?php echo e($i <= $review->rating ? 's' : 'r'); ?> fa-star"></i>
                                    <?php endfor; ?>
                                </div>
                            </div>
                            <p class="text-muted mb-0"><?php echo e($review->comment ?: 'No comment left.'); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-muted">No reviews written for this stall yet.</p>
                <?php endif; ?>
            </div>

            <!-- Right Column -->
            <div class="col-lg-4">
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-body">
                        <h5 class="card-title fw-bold mb-3"><i class="fa-solid fa-store text-success me-2"></i>Where to find us</h5>
                        <?php $__empty_1 = true; $__currentLoopData = $farmerUser->markets()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $market): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="mb-3">
                                <a href="/market-details?id=<?php echo e($market->id); ?>" class="fw-semibold text-success text-decoration-none"><?php echo e($market->name); ?></a>
                                <div class="small text-muted"><?php echo e($market->daysLabel()); ?> &bull; <?php echo e($market->hoursLabel()); ?></div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-muted small mb-0">No market linked yet.</p>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-body">
                        <h5 class="card-title fw-bold mb-3"><i class="fa-solid fa-box-open text-success me-2"></i>Pickup Windows</h5>
                        <?php $__empty_1 = true; $__currentLoopData = $farmer?->pickup_windows ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $window): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <span class="badge bg-light text-dark border mb-1"><?php echo e($window); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-muted small mb-0">Not set yet.</p>
                        <?php endif; ?>
                        <?php if($farmer?->operating_days): ?>
                            <hr>
                            <div class="small text-muted mb-0">Operating days: <?php echo e(implode(', ', $farmer->operating_days)); ?></div>
                        <?php endif; ?>
                    </div>
                </div>

                <?php if($mapLat && $mapLng): ?>
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-body">
                        <h5 class="card-title fw-bold mb-3"><i class="fa-solid fa-map-location-dot text-success me-2"></i>Pickup Location</h5>
                        <div class="rounded-3 overflow-hidden border" style="height:220px;">
                            <iframe title="Map — <?php echo e($farmerUser->displayName()); ?>" width="100%" height="220" style="border:0;display:block"
                                    loading="lazy" referrerpolicy="no-referrer-when-downgrade" src="https://www.openstreetmap.org/export/embed.html?bbox=<?php echo e((float) $mapLng - 0.01); ?>%2C<?php echo e((float) $mapLat - 0.01); ?>%2C<?php echo e((float) $mapLng + 0.01); ?>%2C<?php echo e((float) $mapLat + 0.01); ?>&amp;layer=mapnik&amp;marker=<?php echo e((float) $mapLat); ?>%2C<?php echo e((float) $mapLng); ?>"></iframe>
                        </div>
                        <div class="small text-muted mt-2"><?php echo e($mapLabel); ?>: <?php echo e(number_format((float) $mapLat, 5)); ?>, <?php echo e(number_format((float) $mapLng, 5)); ?></div>
                        <div class="d-grid gap-2 mt-2">
                          <a class="btn btn-outline-success btn-sm" target="_blank" rel="noopener"
                             href="https://www.openstreetmap.org/directions?engine=fossgis_osrm_car&amp;route=<?php echo e((float) $mapLat); ?>%2C<?php echo e((float) $mapLng); ?>">
                            <i class="fa-solid fa-diamond-turn-right me-1"></i>Directions to pickup
                          </a>
                          <a class="btn btn-outline-secondary btn-sm" target="_blank" rel="noopener"
                             href="https://www.openstreetmap.org/?mlat=<?php echo e((float) $mapLat); ?>&amp;mlon=<?php echo e((float) $mapLng); ?>#map=16/<?php echo e((float) $mapLat); ?>/<?php echo e((float) $mapLng); ?>">
                            <i class="fa-solid fa-up-right-from-square me-1"></i>Open larger map
                          </a>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-body">
                        <h5 class="card-title fw-bold mb-3"><i class="fa-solid fa-address-card text-success me-2"></i>Contact</h5>
                        <p class="small mb-1"><i class="fa-solid fa-user text-muted me-2"></i><?php echo e($farmerUser->name); ?></p>
                        <p class="small mb-1"><i class="fa-solid fa-phone text-muted me-2"></i><?php echo e($farmerUser->phone ?: '—'); ?></p>
                        <p class="small mb-0"><i class="fa-solid fa-envelope text-muted me-2"></i><?php echo e($farmerUser->email); ?></p>
                    </div>
                </div>

                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <h5 class="card-title fw-bold mb-3"><i class="fa-solid fa-chart-simple text-success me-2"></i>Stall Stats</h5>
                        <div class="d-flex justify-content-between mb-2"><span class="text-muted">Products (total)</span><span class="fw-bold"><?php echo e($productCount); ?></span></div>
                        <div class="d-flex justify-content-between mb-2"><span class="text-muted">On sale now</span><span class="fw-bold"><?php echo e($products->count()); ?></span></div>
                        <div class="d-flex justify-content-between mb-0"><span class="text-muted">Reviews</span><span class="fw-bold"><?php echo e($reviewCount); ?></span></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/user/marketlink-final/resources/views/farmer/profile.blade.php ENDPATH**/ ?>