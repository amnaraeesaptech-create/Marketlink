<?php $__env->startSection('title', $market->name . ' — MarketLink'); ?>

<?php $__env->startSection('content'); ?>
<!-- Market Hero -->
    <section class="market-hero" style="background-image: url('<?php echo e($market->imageUrl()); ?>'); background-size: cover; background-position: center;">
        <div class="market-hero-overlay text-white">
            <div class="container">
                <div class="d-flex flex-wrap justify-content-between align-items-end">
                    <div>
                        <?php if(in_array(now()->format('l'), $market->days ?? [], true)): ?>
                            <div class="badge bg-success mb-2">Open Today</div>
                        <?php else: ?>
                            <div class="badge bg-secondary mb-2"><?php echo e($market->daysLabel()); ?></div>
                        <?php endif; ?>
                        <h1 class="display-4 fw-bold mb-2"><?php echo e($market->name); ?></h1>
                        <p class="fs-5 mb-0">
                            <i class="fa-solid fa-location-dot me-2"></i><?php echo e($market->address ?: 'Address not set'); ?><?php if($market->city): ?>, <?php echo e($market->city); ?><?php endif; ?>
                            &nbsp;&bull;&nbsp; <i class="fa-regular fa-clock me-2"></i><?php echo e($market->hoursLabel()); ?>

                        </p>
                    </div>
                    <div class="text-end mt-3 mt-md-0">
                        <div class="bg-white text-dark rounded px-3 py-2 d-inline-block">
                            <span class="fw-bold"><?php echo e($market->farmers_count); ?></span> registered stall<?php echo e($market->farmers_count === 1 ? '' : 's'); ?><br>
                            <small class="text-muted"><?php echo e($products->count()); ?> product<?php echo e($products->count() === 1 ? '' : 's'); ?> available</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Breadcrumb -->
    <div class="bg-light py-2 mb-4 border-bottom">
        <div class="container">
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="/" class="text-success text-decoration-none">Home</a></li>
                    <li class="breadcrumb-item"><a href="/markets" class="text-success text-decoration-none">Markets</a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e($market->name); ?></li>
                </ol>
            </nav>
        </div>
    </div>

    <!-- Main Content -->
    <div class="container my-5">
        <div class="row g-5">
            <!-- Left Column (Tabs Content) -->
            <div class="col-lg-8">
                <!-- Tabs Nav -->
                <ul class="nav nav-tabs mb-4 border-bottom-0 shadow-sm rounded-top" id="marketTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="overview-tab" data-bs-toggle="tab" data-bs-target="#overview" type="button" role="tab">Overview</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="farmers-tab" data-bs-toggle="tab" data-bs-target="#farmers" type="button" role="tab">Farmers (<?php echo e($farmers->count()); ?>)</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="products-tab" data-bs-toggle="tab" data-bs-target="#products" type="button" role="tab">Products (<?php echo e($products->count()); ?>)</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="location-tab" data-bs-toggle="tab" data-bs-target="#location" type="button" role="tab">Location</button>
                    </li>
                </ul>

                <!-- Tabs Content -->
                <div class="tab-content" id="marketTabsContent">

                    <!-- Overview Tab -->
                    <div class="tab-pane fade show active" id="overview" role="tabpanel">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h3 class="fw-bold mb-0">About This Market</h3>
                            <a href="/products" class="btn btn-success"><i class="fa-solid fa-basket-shopping me-2"></i>Shop Products</a>
                        </div>
                        <p class="lead text-muted mb-4">
                            <?php echo e($market->description ?: 'This market has no description yet — an administrator can add one from the admin panel.'); ?>

                        </p>

                        <div class="info-grid mb-5">
                            <div class="info-item">
                                <i class="fa-solid fa-map-location-dot"></i>
                                <h5 class="fw-bold">Address</h5>
                                <p class="mb-0 text-muted"><?php echo e($market->address ?: 'Not set'); ?><br><?php echo e($market->city ?: '—'); ?></p>
                            </div>
                            <div class="info-item">
                                <i class="fa-regular fa-clock"></i>
                                <h5 class="fw-bold">Hours</h5>
                                <p class="mb-0 text-muted"><?php echo e($market->daysLabel()); ?><br><?php echo e($market->hoursLabel()); ?></p>
                            </div>
                            <div class="info-item">
                                <i class="fa-solid fa-tractor"></i>
                                <h5 class="fw-bold">Stalls</h5>
                                <p class="mb-0 text-muted"><?php echo e($market->farmers_count); ?> farmer<?php echo e($market->farmers_count === 1 ? '' : 's'); ?><br><?php echo e($products->count()); ?> live product<?php echo e($products->count() === 1 ? '' : 's'); ?></p>
                            </div>
                            <?php if($market->latitude && $market->longitude): ?>
                            <div class="info-item">
                                <i class="fa-solid fa-diamond-turn-right"></i>
                                <h5 class="fw-bold">Directions</h5>
                                <p class="mb-0 text-muted">
                                    <a href="https://www.openstreetmap.org/directions?to=<?php echo e((float) $market->latitude); ?>%2C<?php echo e((float) $market->longitude); ?>"
                                       target="_blank" rel="noopener" class="text-success text-decoration-none">Navigate with OpenStreetMap &rarr;</a><br>
                                    <?php echo e(number_format((float) $market->latitude, 4)); ?>, <?php echo e(number_format((float) $market->longitude, 4)); ?>

                                </p>
                            </div>
                            <?php endif; ?>
                            <div class="info-item">
                                <i class="fa-solid fa-clipboard-list"></i>
                                <h5 class="fw-bold">Pre-Orders</h5>
                                <p class="mb-0 text-muted"><?php echo e($ordersCount); ?> order<?php echo e($ordersCount === 1 ? '' : 's'); ?> with this pickup market</p>
                            </div>
                        </div>

                        <h4 class="fw-bold mb-3">Upcoming Pickups Here</h4>
                        <?php if($upcoming->isEmpty()): ?>
                            <p class="text-muted">No upcoming pickups scheduled at this market.</p>
                        <?php else: ?>
                            <ul class="list-group mb-4">
                                <?php $__currentLoopData = $upcoming; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        <span><?php echo e($order->code()); ?> &bull; <?php echo e($order->farmer?->displayName() ?? '—'); ?></span>
                                        <span class="text-muted small"><?php echo e($order->pickup_date?->format('M d, Y')); ?> <?php echo e($order->pickup_slot); ?></span>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                    </div>

                    <!-- Farmers Tab -->
                    <div class="tab-pane fade" id="farmers" role="tabpanel">
                        <h3 class="fw-bold mb-4">Meet the Farmers</h3>
                        <div class="row g-3">
                            <?php $__empty_1 = true; $__currentLoopData = $farmers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stall): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="col-md-6">
                                    <div class="card border-0 shadow-sm h-100">
                                        <div class="card-body d-flex align-items-center">
                                            <img src="<?php echo e($stall->avatarUrl()); ?>" class="rounded-circle me-3" width="56" height="56" alt="<?php echo e($stall->displayName()); ?>">
                                            <div>
                                                <h6 class="mb-1 fw-bold">
                                                    <a href="/farmer-profile?id=<?php echo e($stall->id); ?>" class="text-dark text-decoration-none"><?php echo e($stall->displayName()); ?></a>
                                                </h6>
                                                <small class="text-muted d-block"><?php echo e($stall->products_count); ?> product<?php echo e($stall->products_count === 1 ? '' : 's'); ?>

                                                    <?php if($stall->averageRating()): ?> &bull; <?php echo e(number_format($stall->averageRating(), 1)); ?>/5 <?php endif; ?>
                                                </small>
                                                <small class="text-muted"><?php echo e($stall->phone); ?></small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="col-12 text-muted">No stalls are linked to this market yet.</div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Products Tab -->
                    <div class="tab-pane fade" id="products" role="tabpanel">
                        <h3 class="fw-bold mb-4">Products at This Market</h3>
                        <div class="row g-3">
                            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="col-md-6 col-lg-4">
                                    <div class="card border-0 shadow-sm h-100">
                                        <img src="<?php echo e($product->imageUrl()); ?>" class="card-img-top" style="height:150px;object-fit:cover" alt="<?php echo e($product->name); ?>">
                                        <div class="card-body">
                                            <h6 class="fw-bold mb-1">
                                                <a href="/product-details?id=<?php echo e($product->id); ?>" class="text-dark text-decoration-none"><?php echo e($product->name); ?></a>
                                            </h6>
                                            <p class="text-muted small mb-1"><?php echo e($product->farmer?->displayName()); ?></p>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <span class="text-success fw-bold">PKR <?php echo e(number_format((float) $product->price, 0)); ?>/<?php echo e($product->unit); ?></span>
                                                <span class="badge bg-light text-dark"><?php echo e($product->stock); ?> left</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <div class="col-12 text-muted">No products listed by this market's stalls right now.</div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Location Tab -->
                    <div class="tab-pane fade" id="location" role="tabpanel">
                        <h3 class="fw-bold mb-4">Location</h3>
                        <div class="card border-0 shadow-sm">
                            <div class="card-body">
                                <p class="mb-2"><i class="fa-solid fa-location-dot text-success me-2"></i><?php echo e($market->address ?: 'Address not set'); ?><?php if($market->city): ?>, <?php echo e($market->city); ?><?php endif; ?></p>
                                <p class="mb-3"><i class="fa-regular fa-clock text-success me-2"></i><?php echo e($market->daysLabel()); ?> &bull; <?php echo e($market->hoursLabel()); ?></p>
                                <?php if($market->latitude && $market->longitude): ?>
                                    <div class="rounded-3 overflow-hidden border mb-3" style="height:300px;">
                                        <iframe title="Map of <?php echo e($market->name); ?>" width="100%" height="300" style="border:0;display:block" loading="lazy"
                                                referrerpolicy="no-referrer-when-downgrade"
                                                src="https://www.openstreetmap.org/export/embed.html?bbox=<?php echo e((float) $market->longitude - 0.012); ?>%2C<?php echo e((float) $market->latitude - 0.012); ?>%2C<?php echo e((float) $market->longitude + 0.012); ?>%2C<?php echo e((float) $market->latitude + 0.012); ?>&amp;layer=mapnik&amp;marker=<?php echo e((float) $market->latitude); ?>%2C<?php echo e((float) $market->longitude); ?>"></iframe>
                                    </div>
                                    <p class="text-muted small">Pin: <?php echo e(number_format((float) $market->latitude, 5)); ?>, <?php echo e(number_format((float) $market->longitude, 5)); ?></p>
                                <?php else: ?>
                                    <p class="text-muted small">No map coordinates saved for this market yet — an administrator can add latitude/longitude from the admin panel.</p>
                                <?php endif; ?>
                                <div class="d-flex flex-wrap gap-2">
                                    <?php if($market->latitude && $market->longitude): ?>
                                      <a href="https://www.openstreetmap.org/directions?to=<?php echo e((float) $market->latitude); ?>%2C<?php echo e((float) $market->longitude); ?>" target="_blank" rel="noopener" class="btn btn-success">
                                          <i class="fa-solid fa-diamond-turn-right me-2"></i>Directions to this market
                                      </a>
                                    <?php endif; ?>
                                    <?php if($market->google_maps_url): ?>
                                        <a href="<?php echo e($market->google_maps_url); ?>" target="_blank" rel="noopener" class="btn btn-outline-success">
                                            <i class="fa-solid fa-map-location-dot me-2"></i>Open in Google Maps
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right Column (Sidebar) -->
            <div class="col-lg-4">
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-body">
                        <h5 class="fw-bold mb-3">Quick Facts</h5>
                        <ul class="list-unstyled mb-0 text-muted">
                            <li class="mb-2"><i class="fa-solid fa-users text-success me-2"></i><?php echo e($market->farmers_count); ?> stall<?php echo e($market->farmers_count === 1 ? '' : 's'); ?> registered</li>
                            <li class="mb-2"><i class="fa-solid fa-box text-success me-2"></i><?php echo e($products->count()); ?> product<?php echo e($products->count() === 1 ? '' : 's'); ?> available</li>
                            <li class="mb-2"><i class="fa-solid fa-calendar-days text-success me-2"></i><?php echo e($market->daysLabel()); ?></li>
                            <li><i class="fa-solid fa-clock text-success me-2"></i><?php echo e($market->hoursLabel()); ?></li>
                        </ul>
                    </div>
                </div>

                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <h5 class="fw-bold mb-3">Browse Other Markets</h5>
                        <a href="/markets" class="btn btn-outline-success w-100"><i class="fa-solid fa-arrow-left me-2"></i>All Markets</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\techproject\project\marketlink-final\resources\views/market-details.blade.php ENDPATH**/ ?>