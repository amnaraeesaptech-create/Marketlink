<?php $__env->startSection('title', 'Farm-Fresh Products — MarketLink'); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Hero -->
    <div class="bg-light py-4 border-bottom">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h1 class="fw-bold mb-1">Farm-Fresh Products</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item"><a href="/" class="text-decoration-none">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Products</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
    </div>

    
    <div id="market-picker-section">
        <div class="container py-5">
            <div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-3">
                <div>
                    <h2 class="fw-bold mb-1">Shop by Market</h2>
                    <p class="text-muted mb-0">Choose a market first to see what's available today.</p>
                </div>
                <button id="nearMeProductsBtn" class="btn btn-outline-success">
                    <i class="fas fa-location-arrow me-1"></i>Near Me
                </button>
            </div>

            <div class="row g-4" id="productMarketGrid">
                <?php $__currentLoopData = $markets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $market): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 col-lg-4 product-market-item"
                     data-market-name="<?php echo e($market->name); ?>"
                     data-lat="<?php echo e($market->latitude ?? ''); ?>"
                     data-lng="<?php echo e($market->longitude ?? ''); ?>"
                     data-farmers="<?php echo e($market->farmers_count); ?>">
                    <div class="card border-0 shadow-sm h-100 rounded-3 overflow-hidden"
                         style="cursor:pointer; transition: transform .15s, box-shadow .15s;"
                         onmouseenter="this.style.transform='translateY(-3px)';this.style.boxShadow='0 8px 24px rgba(0,0,0,.12)'"
                         onmouseleave="this.style.transform='';this.style.boxShadow=''"
                         onclick="window.selectShoppingMarket('<?php echo e(addslashes($market->name)); ?>')">
                        <img src="<?php echo e($market->imageUrl()); ?>" class="card-img-top"
                             style="height:140px;object-fit:cover;" alt="<?php echo e($market->name); ?>">
                        <div class="card-body pb-2">
                            <div class="d-flex justify-content-between align-items-start mb-1">
                                <h5 class="fw-bold mb-0"><?php echo e($market->name); ?></h5>
                                <?php if(in_array(now()->format('l'), $market->days ?? [])): ?>
                                    <span class="badge bg-success ms-2 flex-shrink-0">Open Today</span>
                                <?php endif; ?>
                            </div>
                            <p class="text-muted small mb-2">
                                <i class="fas fa-map-marker-alt me-1 text-success"></i><?php echo e($market->city ?: $market->address); ?>

                            </p>
                            <div class="mb-2">
                                <?php $__currentLoopData = $market->days ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <span class="badge bg-light text-dark border me-1"><?php echo e($day); ?></span>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <p class="text-muted small mb-1">
                                <i class="fas fa-store me-1 text-success"></i>
                                <?php echo e($market->farmers_count); ?> stall<?php echo e($market->farmers_count===1?'':'s'); ?>

                                <span class="ml-dist-badge ms-2 fw-medium text-success" style="display:none;"></span>
                            </p>
                        </div>
                        <div class="card-footer bg-white border-0 pb-3 px-3">
                            <button class="btn btn-success w-100 btn-sm" onclick="event.stopPropagation(); window.selectShoppingMarket('<?php echo e(addslashes($market->name)); ?>')">
                                Shop here <i class="fas fa-arrow-right ms-1"></i>
                            </button>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <p class="text-center text-muted small mt-4">
                Or <a href="#" id="browseAllProductsLink" class="text-success fw-medium">browse all products without picking a market</a>
            </p>
        </div>
    </div>

    
    <div id="selected-market-banner" class="bg-success text-white py-2" style="display:none;">
        <div class="container d-flex justify-content-between align-items-center flex-wrap gap-2">
            <span>
                <i class="fas fa-store me-2"></i>Shopping at:
                <strong id="selected-market-name-banner"></strong>
            </span>
            <button class="btn btn-sm btn-outline-light" onclick="window.clearShoppingMarket()">
                <i class="fas fa-times me-1"></i>Change market
            </button>
        </div>
    </div>

    
    <div id="products-section" style="display:none;">
    <!-- Main Content -->
    <div class="container py-5">
        <div class="row">
            <!-- Left Filter Sidebar -->
            <div class="col-lg-3 mb-4">
                <div class="card border-0 shadow-sm">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-center mb-3">
                            <h5 class="card-title mb-0 fw-bold">Filters</h5>
                            <a href="#" class="text-decoration-none text-muted small" id="clear-filters">Clear All</a>
                        </div>
                        
                        <!-- Search -->
                        <div class="mb-4">
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Search products..." id="search-input">
                                <button class="btn btn-outline-secondary" type="button"><i class="fas fa-search"></i></button>
                            </div>
                        </div>

                        <!-- Categories -->
                        <div class="mb-4">
                            <h6 class="fw-bold mb-2">Categories</h6>
                            <div class="form-check">
                                <input class="form-check-input category-filter" type="checkbox" value="Vegetables" id="cat-veg">
                                <label class="form-check-label d-flex justify-content-between" for="cat-veg">
                                    Vegetables <span class="text-muted small" data-cat-count="Vegetables">(<?php echo e($categoryCounts['Vegetables'] ?? 0); ?>)</span>
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input category-filter" type="checkbox" value="Fruits" id="cat-fruits">
                                <label class="form-check-label d-flex justify-content-between" for="cat-fruits">
                                    Fruits <span class="text-muted small" data-cat-count="Fruits">(<?php echo e($categoryCounts['Fruits'] ?? 0); ?>)</span>
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input category-filter" type="checkbox" value="Dairy" id="cat-dairy">
                                <label class="form-check-label d-flex justify-content-between" for="cat-dairy">
                                    Dairy <span class="text-muted small" data-cat-count="Dairy">(<?php echo e($categoryCounts['Dairy'] ?? 0); ?>)</span>
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input category-filter" type="checkbox" value="Baked Goods" id="cat-baked">
                                <label class="form-check-label d-flex justify-content-between" for="cat-baked">
                                    Baked Goods <span class="text-muted small" data-cat-count="Baked Goods">(<?php echo e($categoryCounts['Baked Goods'] ?? 0); ?>)</span>
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input category-filter" type="checkbox" value="Other" id="cat-other">
                                <label class="form-check-label d-flex justify-content-between" for="cat-other">
                                    Other <span class="text-muted small" data-cat-count="Other">(<?php echo e($categoryCounts['Other'] ?? 0); ?>)</span>
                                </label>
                            </div>
                        </div>

                        <!-- Price Range -->
                        <div class="mb-4">
                            <h6 class="fw-bold mb-2">Price Range (Rs)</h6>
                            <div class="d-flex align-items-center">
                                <input type="number" class="form-control form-control-sm" id="min-price" placeholder="Min" min="0">
                                <span class="mx-2">-</span>
                                <input type="number" class="form-control form-control-sm" id="max-price" placeholder="Max" min="0">
                            </div>
                        </div>

                        <!-- Availability -->
                        <div class="mb-4">
                            <div class="form-check form-switch">
                                <input class="form-check-input" type="checkbox" role="switch" id="in-stock-only">
                                <label class="form-check-label fw-bold" for="in-stock-only">In Stock Only</label>
                            </div>
                        </div>

                        <!-- Markets -->
                        <div class="mb-4">
                            <h6 class="fw-bold mb-2">Markets</h6>
                            <?php $__empty_1 = true; $__currentLoopData = $markets ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $market): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="form-check"><input class="form-check-input market-filter" type="checkbox" value="<?php echo e($market->name); ?>" id="mkt-<?php echo e($market->id); ?>"><label class="form-check-label" for="mkt-<?php echo e($market->id); ?>"><?php echo e($market->name); ?></label></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <p class="text-muted small mb-0">No markets listed yet.</p>
                            <?php endif; ?>
                        </div>

                        <!-- Days -->
                        <div class="mb-4">
                            <h6 class="fw-bold mb-2">Pickup Days</h6>
                            <div class="d-flex flex-wrap gap-2">
                                <div class="form-check form-check-inline m-0"><input class="form-check-input d-none" type="checkbox" name="day-filter" value="Monday" id="day-mon"><label class="btn btn-outline-secondary btn-sm" for="day-mon">M</label></div>
                                <div class="form-check form-check-inline m-0"><input class="form-check-input d-none" type="checkbox" name="day-filter" value="Tuesday" id="day-tue"><label class="btn btn-outline-secondary btn-sm" for="day-tue">T</label></div>
                                <div class="form-check form-check-inline m-0"><input class="form-check-input d-none" type="checkbox" name="day-filter" value="Wednesday" id="day-wed"><label class="btn btn-outline-secondary btn-sm" for="day-wed">W</label></div>
                                <div class="form-check form-check-inline m-0"><input class="form-check-input d-none" type="checkbox" name="day-filter" value="Thursday" id="day-thu"><label class="btn btn-outline-secondary btn-sm" for="day-thu">T</label></div>
                                <div class="form-check form-check-inline m-0"><input class="form-check-input d-none" type="checkbox" name="day-filter" value="Friday" id="day-fri"><label class="btn btn-outline-secondary btn-sm" for="day-fri">F</label></div>
                                <div class="form-check form-check-inline m-0"><input class="form-check-input d-none" type="checkbox" name="day-filter" value="Saturday" id="day-sat"><label class="btn btn-outline-secondary btn-sm" for="day-sat">S</label></div>
                                <div class="form-check form-check-inline m-0"><input class="form-check-input d-none" type="checkbox" name="day-filter" value="Sunday" id="day-sun"><label class="btn btn-outline-secondary btn-sm" for="day-sun">S</label></div>
                            </div>
                        </div>

                        <!-- Rating -->
                        <div>
                            <h6 class="fw-bold mb-2">Minimum Rating</h6>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="rating-filter" id="rate-4" value="4">
                                <label class="form-check-label text-warning" for="rate-4">
                                    <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="far fa-star"></i> & Up
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="rating-filter" id="rate-3" value="3">
                                <label class="form-check-label text-warning" for="rate-3">
                                    <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="far fa-star"></i><i class="far fa-star"></i> & Up
                                </label>
                            </div>
                        </div>

                    </div>
                </div>
            </div>

            <!-- Right Content -->
            <div class="col-lg-9">
                <!-- Top Bar -->
                <div class="d-flex flex-column flex-md-row justify-content-between align-items-center mb-4 p-3 bg-white rounded shadow-sm border">
                    <p class="mb-2 mb-md-0 fw-medium">Showing <span id="product-count"><?php echo e($products->count()); ?></span> products</p>
                    <div class="d-flex align-items-center">
                        <select class="form-select form-select-sm me-3 w-auto" id="sort-select">
                            <option value="newest">Newest</option>
                            <option value="price-asc">Price: Low to High</option>
                            <option value="price-desc">Price: High to Low</option>
                            <option value="rating">Highest Rated</option>
                            <option value="name">Name: A to Z</option>
                        </select>
                        <div class="btn-group" role="group">
                            <button type="button" class="btn btn-sm btn-outline-secondary active" id="btn-grid"><i class="fas fa-th"></i></button>
                            <button type="button" class="btn btn-sm btn-outline-secondary" id="btn-list"><i class="fas fa-list"></i></button>
                        </div>
                    </div>
                </div>

                <!-- Product Grid -->
                <div class="row g-4" id="product-grid">
                    <!-- Products will be generated here -->
                </div>
                
                <!-- Product List (hidden by default) -->
                <div class="d-none" id="product-list">
                    <!-- List items will be generated here -->
                </div>

                <!-- Pagination -->
                <nav class="mt-5" aria-label="Products info">
                    <p class="text-center text-muted small mb-0">
                        Showing all <?php echo e($products->count()); ?> live product<?php echo e($products->count() === 1 ? '' : 's'); ?> &bull; updated as farmers publish stock
                    </p>
                </nav>
            </div>
        </div>
    </div>

    <!-- Quick View Modal -->
    <div class="modal fade" id="quickViewModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header border-0 pb-0">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body pt-0" id="quick-view-content">
                    <!-- Content populated by JS -->
                </div>
            </div>
        </div>
    </div>

    <!-- Toast for Add to Cart -->
    <div class="toast-container position-fixed bottom-0 end-0 p-3">
        <div id="cartToast" class="toast align-items-center text-bg-success border-0" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="d-flex">
                <div class="toast-body">
                    Item added to cart successfully!
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
/* window.ML is served by /data-feed.js — no inline mock data here. */

(function () {
    var MARKET_KEY = 'ml_shopping_market';

    window.selectShoppingMarket = function (marketName) {
        try { sessionStorage.setItem(MARKET_KEY, marketName); } catch (e) {}
        showProductsForMarket(marketName);
    };

    window.clearShoppingMarket = function () {
        try { sessionStorage.removeItem(MARKET_KEY); } catch (e) {}
        window.ML_SELECTED_MARKET = null;
        document.getElementById('market-picker-section').style.display = '';
        document.getElementById('selected-market-banner').style.display = 'none';
        document.getElementById('products-section').style.display = 'none';
    };

    function showProductsForMarket(marketName) {
        window.ML_SELECTED_MARKET = marketName;

        document.getElementById('market-picker-section').style.display = 'none';
        var banner = document.getElementById('selected-market-banner');
        banner.style.display = '';
        var nameEl = document.getElementById('selected-market-name-banner');
        if (nameEl) nameEl.textContent = marketName;
        document.getElementById('products-section').style.display = '';

        // Pre-tick the matching market checkbox filter
        document.querySelectorAll('.market-filter').forEach(function (cb) {
            cb.checked = (cb.value === marketName);
        });

        // Trigger a re-render of the product grid
        document.querySelectorAll('.market-filter').forEach(function (cb) {
            cb.dispatchEvent(new Event('change', { bubbles: true }));
        });
    }

    // Near Me button on market picker
    var nearBtn = document.getElementById('nearMeProductsBtn');
    if (nearBtn) {
        nearBtn.addEventListener('click', function () {
            nearBtn.disabled = true;
            nearBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>Locating…';
            window.MLGeo.getLocation(function (lat, lng) {
                nearBtn.disabled = false;
                nearBtn.classList.remove('btn-outline-success');
                nearBtn.classList.add('btn-success');
                nearBtn.innerHTML = '<i class="fas fa-location-arrow me-1"></i>Near Me';
                window.MLGeo.attachDistanceBadges(lat, lng, {
                    items: document.querySelectorAll('.product-market-item'),
                    getLat: function (el) { return el.dataset.lat; },
                    getLng: function (el) { return el.dataset.lng; },
                    badgeClass: 'ml-dist-badge',
                    insertInto: function (el, badge) {
                        var slot = el.querySelector('.ml-dist-badge');
                        if (slot) { slot.textContent = badge.textContent; slot.style.display = ''; }
                    }
                });
                window.MLGeo.sortByNearest(document.getElementById('productMarketGrid'));
            }, function () {
                nearBtn.disabled = false;
                nearBtn.innerHTML = '<i class="fas fa-location-arrow me-1"></i>Near Me';
            });
        });
    }

    // "Browse all" escape hatch
    var browseAll = document.getElementById('browseAllProductsLink');
    if (browseAll) {
        browseAll.addEventListener('click', function (e) {
            e.preventDefault();
            window.ML_SELECTED_MARKET = null;
            document.getElementById('market-picker-section').style.display = 'none';
            document.getElementById('selected-market-banner').style.display = 'none';
            document.getElementById('products-section').style.display = '';
        });
    }

    // On page load — restore from sessionStorage or auto-sort by distance
    (function () {
        var cached = null;
        try { cached = sessionStorage.getItem(MARKET_KEY); } catch (e) {}
        if (cached) {
            showProductsForMarket(cached);
            return;
        }
        // Auto-attach distance badges if location cached from another page
        var loc = null;
        try { loc = JSON.parse(sessionStorage.getItem('ml_user_loc')); } catch (e) {}
        if (loc && loc.lat && loc.lng) {
            setTimeout(function () {
                window.MLGeo.attachDistanceBadges(loc.lat, loc.lng, {
                    items: document.querySelectorAll('.product-market-item'),
                    getLat: function (el) { return el.dataset.lat; },
                    getLng: function (el) { return el.dataset.lng; },
                    badgeClass: 'ml-dist-badge',
                    insertInto: function (el, badge) {
                        var slot = el.querySelector('.ml-dist-badge');
                        if (slot) { slot.textContent = badge.textContent; slot.style.display = ''; }
                    }
                });
                window.MLGeo.sortByNearest(document.getElementById('productMarketGrid'));
                var nb = document.getElementById('nearMeProductsBtn');
                if (nb) { nb.classList.remove('btn-outline-success'); nb.classList.add('btn-success'); }
            }, 200);
        } else {
            // First visit — silently request location
            window.MLGeo.getLocation(function (lat, lng) {
                setTimeout(function () {
                    window.MLGeo.attachDistanceBadges(lat, lng, {
                        items: document.querySelectorAll('.product-market-item'),
                        getLat: function (el) { return el.dataset.lat; },
                        getLng: function (el) { return el.dataset.lng; },
                        badgeClass: 'ml-dist-badge',
                        insertInto: function (el, badge) {
                            var slot = el.querySelector('.ml-dist-badge');
                            if (slot) { slot.textContent = badge.textContent; slot.style.display = ''; }
                        }
                    });
                    window.MLGeo.sortByNearest(document.getElementById('productMarketGrid'));
                    var nb = document.getElementById('nearMeProductsBtn');
                    if (nb) { nb.classList.remove('btn-outline-success'); nb.classList.add('btn-success'); }
                }, 200);
            }, function () { /* denied — market picker still works */ });
        }
    })();
})();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\techproject\project\marketlink-final\resources\views/products.blade.php ENDPATH**/ ?>