# AI Tool Acknowledgment — MarketLink

This document acknowledges all AI-powered tools used during the design, development, and documentation of the MarketLink web application, in compliance with the SRS requirement:

> *"Acknowledge all the AI tool(s) used (for example, Copilot, Canva AI, Figma AI, Uizard, or similar) in your project documentation or submission."*

---

## Tools Used

### 1. Claude (Anthropic) / Claude Code
**Used for:** Code assistance, debugging, code review, and documentation drafting.

**Specific uses:**
- Suggesting controller method structures for Laravel
- Helping debug migration errors and Eloquent relationship issues
- Reviewing security patterns (CSRF, input validation, password hashing)
- Drafting initial Blade template structures that were then customized
- Generating boilerplate for repetitive CRUD patterns (subsequently modified)
- Identifying gaps in SRS compliance and suggesting fixes
- Reviewing logic in `PreorderController` (cutoff enforcement, stock rebalancing)
- Drafting sections of this README and conformance documentation

**Not used for:** Final business logic decisions, database design choices, UI/UX design direction, or the core architectural decisions of the application.

---

### 2. GitHub Copilot
**Used for:** In-editor code completion suggestions while writing PHP and JavaScript.

**Specific uses:**
- Auto-completing repetitive Eloquent query patterns
- Suggesting variable names and method signatures
- Completing boilerplate HTML/Blade structures

**Not used for:** Generating complete features end-to-end without developer review and modification.

---

### 3. Canva (Design / Image Generation)
**Used for:** Generating placeholder product and market cover images used in the demo dataset.

**Specific uses:**
- Creating demo product images (tomatoes, herbs, dairy products etc.) for the seeded database
- Market cover images

**Not used for:** Application UI design or layout decisions.

---

## Developer Statement

All AI-generated suggestions, code snippets, and content were:

1. **Reviewed** by the developer before inclusion
2. **Modified** to fit the project's architecture, coding style, and specific requirements
3. **Understood** — the developer can explain every design decision, every controller method, every migration, and every piece of logic in this application

The application's architecture (Laravel MVC with role-based middleware, pre-order flow with per-farmer grouping, cutoff enforcement logic, stock rebalancing on cancel/modify, in-app notification system) was designed by the developer. AI was used as a productivity aid, not as a substitute for developer knowledge and judgment.

As required by the SRS: *"AI is your assistant, not your developer. Your knowledge, creativity, and coding skills should drive the project."*

---

## Summary Table

| Tool | Category | Extent of Use |
|---|---|---|
| Claude / Claude Code | Code assistant | Moderate — suggestions reviewed and modified |
| GitHub Copilot | Code completion | Light — inline completions only |
| Canva AI | Image generation | Light — demo images only |

---

*This acknowledgment was prepared in accordance with Section 1.6 (Important Note Regarding AI Usage) of the MarketLink Software Requirements Specification v1.0.*
