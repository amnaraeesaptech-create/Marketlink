<?php

namespace App\Models;

use App\Support\Placeholder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

/**
 * A physical farmers' market where stalls trade.
 *
 * Markets are real records (created/edited/deleted from the admin panel and
 * linked to farmers through the farmer_market pivot) — not hardcoded strings.
 */
class Market extends Model
{
    protected $fillable = [
        'name', 'city', 'address', 'days', 'open_time', 'close_time',
        'description', 'image', 'google_maps_url', 'is_active',
        'latitude',
        'longitude',
    ];

    protected $casts = [
        'days' => 'array',
        'is_active' => 'boolean',
    ];

    public const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];

    public function farmers(): BelongsToMany
    {
        return $this->belongsToMany(User::class, 'farmer_market', 'market_id', 'farmer_id')
            ->withTimestamps();
    }

    public function farmersCount(): int
    {
        return $this->farmers()->count();
    }

    public function daysLabel(): string
    {
        $days = $this->days ?: [];

        if ($days === []) {
            return 'Days not set';
        }

        if (count($days) === 7) {
            return 'Daily';
        }

        return implode(', ', array_map(fn ($d) => ucfirst((string) $d), $days));
    }

    public function hoursLabel(): string
    {
        if (! $this->open_time || ! $this->close_time) {
            return 'Timings not set';
        }

        return date('g:i A', strtotime($this->open_time)) . ' - ' . date('g:i A', strtotime($this->close_time));
    }

    public function imageUrl(): string
    {
        if ($this->image) {
            return str_starts_with($this->image, 'http') ? $this->image : '/storage/' . $this->image;
        }

        return Placeholder::image($this->name ?? 'Market', 'market-' . $this->id, 800, 400);
    }

    /**
     * Keep the farmer pivot in sync with the market names a farmer selected.
     * Unknown names are created as new (real) market rows.
     *
     * @param  array<int, string>  $names
     */
    public static function syncForFarmer(User $farmer, array $names, ?string $city = null, array $days = []): void
    {
        $ids = [];

        foreach (array_values(array_unique(array_filter(array_map('trim', $names)))) as $name) {
            $market = static::firstOrCreate(
                ['name' => $name],
                [
                    'city' => $city,
                    'days' => array_values(array_filter($days)),
                    'is_active' => true,
                ]
            );
            $ids[] = $market->id;
        }

        $farmer->markets()->sync($ids);
    }
}
