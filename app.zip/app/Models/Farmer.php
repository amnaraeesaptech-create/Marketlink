<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Farmer extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'stall_name',
        'contact_person',
        'phone',
        'address',
        'description',
        'markets',
        'operating_days',
        'pickup_windows',
        'categories',
        'latitude',
        'longitude',
        'avatar',
        'is_approved',
        'cutoff_hours',
    ];

    protected function casts(): array
    {
        return [
            'markets' => 'array',
            'operating_days' => 'array',
            'pickup_windows' => 'array',
            'categories' => 'array',
            'latitude' => 'decimal:8',
            'longitude' => 'decimal:8',
            'is_approved' => 'boolean',
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Returns pickup windows as structured arrays {day, label, start, end}.
     * Backward-compatible: parses legacy free-text like "Sat 8:00 AM - 1:00 PM".
     */
    public function normalizedPickupWindows(): array
    {
        $windows = [];
        foreach ($this->pickup_windows ?? [] as $w) {
            if (is_array($w) && !empty($w['day'])) {
                $windows[] = [
                    'day'   => $w['day'],
                    'label' => $w['label'] ?? trim(($w['day'] ?? '') . ' ' . ($w['start'] ?? '') . ' - ' . ($w['end'] ?? '')),
                    'start' => $w['start'] ?? null,
                    'end'   => $w['end']   ?? null,
                ];
            } elseif (is_string($w) && trim($w)) {
                $day = null;
                foreach (['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday',
                          'Mon','Tue','Wed','Thu','Fri','Sat','Sun'] as $d) {
                    if (stripos(trim($w), $d) === 0) {
                        $day = substr($d, 0, 3);
                        break;
                    }
                }
                $windows[] = ['day' => $day, 'label' => trim($w), 'start' => null, 'end' => null];
            }
        }
        return $windows;
    }
}
