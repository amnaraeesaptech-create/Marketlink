<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Announcement extends Model
{
    protected $fillable = ['title', 'body', 'audience', 'is_active', 'published_at'];

    protected $casts = ['is_active' => 'boolean', 'published_at' => 'datetime'];

    public const AUDIENCES = ['all' => 'Everyone', 'customers' => 'Clients', 'farmers' => 'Farmers'];

    public function audienceLabel(): string
    {
        return self::AUDIENCES[$this->audience] ?? 'Everyone';
    }

    /** Active announcements for a visitor, newest first. */
    public static function liveFor(?string $role = null)
    {
        return static::where('is_active', true)
            ->where(fn ($q) => $q->where('audience', 'all')->orWhere('audience', $role))
            ->latest()
            ->get();
    }
}
