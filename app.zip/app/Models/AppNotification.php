<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AppNotification extends Model
{
    protected $table = 'app_notifications';

    protected $fillable = ['user_id', 'type', 'title', 'body', 'url', 'read_at'];

    protected $casts = ['read_at' => 'datetime'];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function isUnread(): bool
    {
        return $this->read_at === null;
    }

    public function icon(): string
    {
        return match ($this->type) {
            'order_placed' => 'fa-cart-plus',
            'order_status' => 'fa-truck',
            'order_cancelled' => 'fa-times-circle',
            'review' => 'fa-star',
            'review_reply' => 'fa-reply',
            'restock' => 'fa-box-open',
            'announcement' => 'fa-bullhorn',
            default => 'fa-bell',
        };
    }
}
