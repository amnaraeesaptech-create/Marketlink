<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use App\Support\Placeholder;

class User extends Authenticatable
{
    /** @use HasFactory<\Database\Factories\UserFactory> */
    use HasFactory, Notifiable;

    public const ROLE_CUSTOMER = 'customer';
    public const ROLE_FARMER = 'farmer';
    public const ROLE_ADMIN = 'admin';

    protected $fillable = [
        'name',
        'email',
        'password',
        'role',
        'phone',
        'address',
        'avatar',
        'is_active',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
            'is_active' => 'boolean',
        ];
    }

    /** In-app alerts (SRS: order confirmations, ready-for-pickup, restock…). */
    public function alerts(): HasMany
    {
        return $this->hasMany(AppNotification::class);
    }

    public function unreadNotificationsCount(): int
    {
        return $this->alerts()->whereNull('read_at')->count();
    }

    public function farmer(): HasOne
    {
        return $this->hasOne(Farmer::class);
    }

    public function customer(): HasOne
    {
        return $this->hasOne(Customer::class);
    }

    public function products(): HasMany
    {
        return $this->hasMany(Product::class, 'farmer_id');
    }

    public function customerOrders(): HasMany
    {
        return $this->hasMany(Order::class, 'customer_id');
    }

    /** Markets this farmer trades at (real pivot rows). */
    public function markets(): BelongsToMany
    {
        return $this->belongsToMany(Market::class, 'farmer_market', 'farmer_id', 'market_id')
            ->withTimestamps();
    }

    /** Market names for display (falls back to the profile's saved names). */
    public function marketNames(): array
    {
        $names = $this->markets()->pluck('name')->all();

        if ($names === [] && $this->isFarmer()) {
            $names = $this->farmer?->markets ?? [];
        }

        return array_values($names);
    }

    /** Total money collected on this farmer's completed orders. */
    public function completedRevenue(): float
    {
        return (float) $this->farmerOrders()->where('status', Order::ST_COMPLETED)->sum('subtotal');
    }

    public function farmerOrders(): HasMany
    {
        return $this->hasMany(Order::class, 'farmer_id');
    }

    public function favorites(): HasMany
    {
        return $this->hasMany(Favorite::class, 'customer_id');
    }

    public function reviewsGiven(): HasMany
    {
        return $this->hasMany(Review::class, 'customer_id');
    }

    public function reviewsReceived(): HasMany
    {
        return $this->hasMany(Review::class, 'farmer_id');
    }

    public function averageRating(): ?float
    {
        // Product-level ratings are shown on the product; the stall score is built
        // from the reviews left on the order itself.
        $avg = $this->reviewsReceived()->stall()->avg('rating');

        return $avg === null ? null : round((float) $avg, 1);
    }

    public function hasRole(string ...$roles): bool
    {
        return in_array($this->role, $roles, true);
    }

    public function isCustomer(): bool
    {
        return $this->role === self::ROLE_CUSTOMER;
    }

    public function isFarmer(): bool
    {
        return $this->role === self::ROLE_FARMER;
    }

    public function isAdmin(): bool
    {
        return $this->role === self::ROLE_ADMIN;
    }

    /** Where to send the user right after login / registration. */
    public function dashboardUrl(): string
    {
        return match ($this->role) {
            self::ROLE_FARMER => '/farmer-dashboard',
            self::ROLE_ADMIN => '/admin-dashboard',
            default => '/customer-dashboard',
        };
    }

    /** Profile photo URL with a graceful, offline-safe fallback. */
    public function avatarUrl(): string
    {
        if ($this->avatar) {
            return str_starts_with($this->avatar, 'http') ? $this->avatar : '/storage/' . $this->avatar;
        }
        if ($this->isFarmer() && $this->farmer?->avatar) {
            return str_starts_with($this->farmer->avatar, 'http')
                ? $this->farmer->avatar
                : '/storage/' . $this->farmer->avatar;
        }

        return Placeholder::image($this->displayName(), 'user-' . $this->id, 200, 200);
    }

    /** Display name: stall name for farmers, full name otherwise. */
    public function displayName(): string
    {
        if ($this->isFarmer() && $this->farmer?->stall_name) {
            return $this->farmer->stall_name;
        }
        return $this->name;
    }
}
