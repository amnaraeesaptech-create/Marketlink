<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Review extends Model
{
    protected $fillable = [
        'customer_id', 'farmer_id', 'order_id', 'product_id',
        'rating', 'comment', 'farmer_reply', 'replied_at',
    ];

    protected $casts = [
        'rating' => 'integer',
        'replied_at' => 'datetime',
    ];

    public function customer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'customer_id');
    }

    public function farmer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'farmer_id');
    }

    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class);
    }

    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }

    /** Farmer/stall reviews only (no single product attached). */
    public function scopeStall($q)
    {
        return $q->whereNull('product_id');
    }

    public function scopeProductLevel($q)
    {
        return $q->whereNotNull('product_id');
    }

    public function hasReply(): bool
    {
        return filled($this->farmer_reply);
    }
}
