<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    protected $fillable = ['name', 'description', 'is_active', 'sort_order'];

    protected $casts = ['is_active' => 'boolean'];

    /** Names shown in product forms / filters (DB first, constant as fallback). */
    public static function names(): array
    {
        $names = static::where('is_active', true)->orderBy('sort_order')->orderBy('name')->pluck('name')->all();

        return $names ?: Product::CATEGORIES;
    }

    public static function all_names(): array
    {
        $names = static::orderBy('sort_order')->orderBy('name')->pluck('name')->all();

        return $names ?: Product::CATEGORIES;
    }

    public function productCount(): int
    {
        return Product::where('category', $this->name)->count();
    }
}
