<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Product extends Model
{
    protected $fillable = [
        'farmer_id', 'name', 'category', 'price', 'unit', 'stock',
        'description', 'image', 'markets', 'is_available', 'rating',
    ];

    protected $casts = [
        'price' => 'decimal:2',
        'rating' => 'decimal:2',
        'is_available' => 'boolean',
        'markets' => 'array',
    ];

    public const CATEGORIES = ['Vegetables', 'Fruits', 'Dairy', 'Meat', 'Baked Goods', 'Other'];
    public const UNITS = ['kg', 'g', 'litre', 'dozen', 'piece', 'bunch', 'pack'];

    /** SRS admin farmer approval: unapproved stalls stay out of the storefront. */
    public function scopeFromApprovedStall($q)
    {
        return $q->whereHas('farmer.farmer', fn ($sub) => $sub->where('is_approved', true));
    }

    public function stallIsApproved(): bool
    {
        return (bool) ($this->farmer?->farmer?->is_approved ?? false);
    }

    public function farmer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'farmer_id');
    }

    public function imageUrl(): string
    {
        if ($this->image) {
            // Local uploads are served from /storage; external URLs kept as-is.
            if (str_starts_with($this->image, 'http')) {
                return $this->image;
            }

            return '/storage/' . ltrim($this->image, '/');
        }

        // No photo uploaded: render a deterministic tile from the real product name.
        return \App\Support\Placeholder::image($this->name ?? 'Product', 'product-' . $this->id, 400, 400);
    }

    /** Small square used inside cart/order tables. */
    public function thumbUrl(): string
    {
        return $this->imageUrl();
    }

    public function stockState(): string
    {
        if (!$this->is_available || $this->stock <= 0) {
            return 'out';
        }
        return $this->stock < 5 ? 'low' : 'ok';
    }
}
