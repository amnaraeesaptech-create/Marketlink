<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

class Order extends Model
{
    public const ST_PENDING = 'pending';
    public const ST_CONFIRMED = 'confirmed';
    public const ST_READY = 'ready';
    public const ST_COMPLETED = 'completed';
    public const ST_CANCELLED = 'cancelled';

    public const STATUSES = [
        self::ST_PENDING => ['Placed', 'warning'],
        self::ST_CONFIRMED => ['Accepted', 'primary'],
        self::ST_READY => ['Ready for Pickup', 'info'],
        self::ST_COMPLETED => ['Completed', 'success'],
        self::ST_CANCELLED => ['Cancelled', 'danger'],
    ];

    protected $fillable = [
        'customer_id', 'farmer_id', 'market', 'pickup_date',
        'pickup_slot', 'status', 'subtotal', 'notes',
    ];

    protected $casts = [
        'pickup_date' => 'date',
        'subtotal' => 'decimal:2',
    ];

    public function customer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'customer_id');
    }

    public function farmer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'farmer_id');
    }

    public function items(): HasMany
    {
        return $this->hasMany(OrderItem::class);
    }

    /** Stake: per-item reviews written for this order. */
    public function reviews()
    {
        return $this->hasMany(Review::class);
    }

    public function productReviews()
    {
        return $this->hasMany(Review::class)->whereNotNull('product_id');
    }

    public function review(): HasOne
    {
        return $this->hasOne(Review::class);
    }

    public function code(): string
    {
        return '#ML-' . str_pad((string) $this->id, 5, '0', STR_PAD_LEFT);
    }

    public function statusLabel(): string
    {
        return self::STATUSES[$this->status][0] ?? ucfirst((string) $this->status);
    }

    public function statusBadge(): string
    {
        return self::STATUSES[$this->status][1] ?? 'secondary';
    }

    public function itemsSummary(): string
    {
        return $this->items->map(fn ($i) => $i->qty . 'x ' . $i->name)->implode(', ');
    }

    public function canBeCancelledByCustomer(): bool
    {
        return in_array($this->status, [self::ST_PENDING, self::ST_CONFIRMED], true)
            && ! $this->isPastCutoff();
    }

    /** Same window as cancelling — SRS: "cancel or modify an order before the cutoff time". */
    public function canBeModifiedByCustomer(): bool
    {
        return $this->canBeCancelledByCustomer();
    }

    /** Pickup moment = pickup date + the start time of the chosen slot. */
    public function pickupAt(): ?\Illuminate\Support\Carbon
    {
        if (! $this->pickup_date) {
            return null;
        }

        $at = $this->pickup_date->copy()->startOfDay();
        if (preg_match('/(\d{1,2}):(\d{2})\s*(am|pm)?/i', (string) $this->pickup_slot, $m)) {
            $hour = (int) $m[1];
            $minute = (int) $m[2];
            $meridiem = strtolower($m[3] ?? '');
            if ($meridiem === 'pm' && $hour < 12) {
                $hour += 12;
            }
            if ($meridiem === 'am' && $hour === 12) {
                $hour = 0;
            }
            $at->setTime($hour, $minute);
        } else {
            $at->setTime(8, 0);
        }

        return $at;
    }

    /** Farmer's own cut-off (hours before pickup); default 12h. */
    public function cutoffHours(): int
    {
        $hours = (int) optional(optional($this->farmer)->farmer)->cutoff_hours;

        return $hours > 0 ? $hours : 12;
    }

    public function cutoffAt(): ?\Illuminate\Support\Carbon
    {
        return $this->pickupAt()?->subHours($this->cutoffHours());
    }

    public function isPastCutoff(): bool
    {
        $cutoff = $this->cutoffAt();

        return $cutoff ? now()->greaterThanOrEqualTo($cutoff) : false;
    }
}
