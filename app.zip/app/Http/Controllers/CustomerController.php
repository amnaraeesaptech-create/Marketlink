<?php

namespace App\Http\Controllers;

use App\Models\Order;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;
use Symfony\Component\HttpFoundation\Response;

class CustomerController extends Controller
{
    /**
     * Client dashboard — orders, pickups, favorites and notifications are all
     * read from this user's own rows. Nothing here is sample content.
     */
    public function dashboard(): View
    {
        $user = request()->user();
        $orders = $user->customerOrders();

        $favorites = $user->favorites()->with('product.farmer.farmer')->latest()->get();

        // Distinct stalls behind the favorited products.
        $favoriteFarmers = $favorites
            ->map(fn ($f) => $f->product?->farmer)
            ->filter()
            ->unique('id')
            ->values();

        return view('customer.dashboard', [
            'user' => $user,
            'ordersCount' => (clone $orders)->count(),
            'pendingOrders' => (clone $orders)->where('status', \App\Models\Order::ST_PENDING)->count(),
            'readyOrders' => (clone $orders)->where('status', \App\Models\Order::ST_READY)->count(),
            'completedOrders' => (clone $orders)->where('status', \App\Models\Order::ST_COMPLETED)->count(),
            'spendFmt' => number_format((float) (clone $orders)
                ->whereNotIn('status', [\App\Models\Order::ST_CANCELLED])
                ->sum('subtotal'), 0),
            'recentOrders' => $user->customerOrders()->with(['farmer', 'items'])->latest()->limit(5)->get(),
            'upcomingPickups' => $user->customerOrders()
                ->with('farmer')
                ->whereIn('status', [\App\Models\Order::ST_PENDING, \App\Models\Order::ST_CONFIRMED, \App\Models\Order::ST_READY])
                ->whereDate('pickup_date', '>=', now()->toDateString())
                ->orderBy('pickup_date')
                ->limit(4)
                ->get(),
            'favorites' => $favorites,
            'favoriteFarmers' => $favoriteFarmers,
            'unreadAlerts' => request()->user()->unreadNotificationsCount(),
            'favoritesCount' => $favorites->count(),
            'reviewsCount' => $user->reviewsGiven()->count(),
            'pendingReviews' => $user->customerOrders()
                ->where('status', \App\Models\Order::ST_COMPLETED)
                ->whereDoesntHave('review')
                ->count(),
        ]);
    }

    public function orders(): View
    {
        $user = request()->user();
        $q = $user->customerOrders()->with(['farmer', 'items.product', 'review'])->latest();

        if (request()->filled('status')) {
            $q->where('status', request()->input('status'));
        }
        if (request()->filled('search')) {
            $q->where('id', request()->input('search'));
        }
        if (request()->filled('date')) {
            $q->whereDate('pickup_date', request()->input('date'));
        }

        $base = $user->customerOrders();

        return view('customer.orders', [
            'orders' => $q->get(),
            'countsAll' => (clone $base)->count(),
            'countsPending' => (clone $base)->where('status', \App\Models\Order::ST_PENDING)->count(),
            'countsConfirmed' => (clone $base)->where('status', \App\Models\Order::ST_CONFIRMED)->count(),
            'countsReady' => (clone $base)->where('status', \App\Models\Order::ST_READY)->count(),
            'countsCompleted' => (clone $base)->where('status', \App\Models\Order::ST_COMPLETED)->count(),
            'countsCancelled' => (clone $base)->where('status', \App\Models\Order::ST_CANCELLED)->count(),
            'status' => request()->input('status', ''),
            'search' => request()->input('search', ''),
            'date' => request()->input('date', ''),
        ]);
    }

    /** Single order (?id=) with items, timeline, cancel + review actions. */
    public function orderDetails(Request $request): Response
    {
        $id = $request->query('id');
        $user = $request->user();
        $isFarmer = $user->isFarmer();

        if (!$id) {
            return redirect()->away($isFarmer ? '/farmer-orders' : '/customer-orders');
        }

        $order = $isFarmer
            ? $user->farmerOrders()->with(['customer', 'items.product', 'review'])->findOrFail($id)
            : $user->customerOrders()->with(['farmer', 'items.product', 'review'])->findOrFail($id);

        return response()->view('order-details', [
            'order' => $order,
            'backUrl' => $isFarmer ? '/farmer-orders' : '/customer-orders',
            'canReview' => !$isFarmer && $order->status === \App\Models\Order::ST_COMPLETED && !$order->review,
            'canCancel' => !$isFarmer && $order->canBeCancelledByCustomer(),
            'canModify' => !$isFarmer && $order->canBeModifiedByCustomer(),
            'productReviews' => $order->productReviews()->get()->keyBy('product_id'),
            'reviewedProductIds' => $order->productReviews()->pluck('product_id')->all(),
            // Market record for the OSM pickup-point map (SRS: route-friendly pickup details)
            'pickupMarket' => $order->market
                ? \App\Models\Market::where('name', $order->market)->first()
                : null,
        ]);
    }

    /**
     * SRS: "order history + reorder". Stock is re-checked against the live
     * catalogue and the surviving items are handed to the browser cart.
     */
    public function reorder(Request $request, int $id): RedirectResponse
    {
        $order = Order::with('items.product')->findOrFail($id);

        abort_unless($order->customer_id === $request->user()->id, 403);

        $seed = [];
        $skipped = [];

        foreach ($order->items as $item) {
            $product = $item->product;

            if (! $product || ! $product->is_available) {
                $skipped[] = $item->name;
                continue;
            }

            $qty = min($item->qty, max(0, (int) $product->stock));
            if ($qty < 1) {
                $skipped[] = $item->name;
                continue;
            }

            $seed[] = [
                'id' => (string) $product->id,
                'name' => $product->name,
                'price' => (float) $product->price,
                'image' => $product->imageUrl(),
                'quantity' => $qty,
                'unit' => $product->unit,
                'farmer' => $product->farmer?->displayName(),
                'farmer_id' => $product->farmer_id,
                'stock' => (int) $product->stock,
            ];
        }

        if (! $seed) {
            return redirect('/order-details?id=' . $order->id)
                ->with('error', 'None of these items are available right now'
                    . ($skipped ? ' (' . implode(', ', $skipped) . ')' : '') . '.');
        }

        session()->flash('ml_reorder_seed', $seed);
        session()->flash('ml_reorder_meta', [
            'order' => $order->code(),
            'skipped' => $skipped,
        ]);

        return redirect('/cart')->with('success', count($seed) . ' item(s) from order ' . $order->code() . ' added to your cart.');
    }

    public function favorites(): View
    {
        $favorites = request()->user()->favorites()->latest()->get();

        return view('customer.favorites', [
            'favorites' => $favorites->whereNotNull('product_id')->load('product.farmer'),
            'farmerFavorites' => $favorites->whereNotNull('farmer_id')->load('farmer.farmer'),
            'marketFavorites' => $favorites->whereNotNull('market_id')->load('market'),
        ]);
    }

    public function reviews(): View
    {
        return view('customer.reviews', [
            'reviews' => request()->user()->reviewsGiven()->with(['farmer', 'order'])->latest()->get(),
        ]);
    }

    /** Customer profile (view + edit on one page). */
    public function profile(): View
    {
        return view('customer.profile', [
            'user' => request()->user()->load('customer'),
        ]);
    }

    public function updateProfile(Request $request): RedirectResponse
    {
        $user = $request->user();

        $data = $request->validate([
            'name' => 'required|string|max:255',
            'phone' => 'required|string|max:30',
            'email' => 'required|email|max:255|unique:users,email,' . $user->id,
            'address' => 'required|string|max:255',
            'city' => 'nullable|string|max:100',
            'avatar' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
        ]);

        if ($request->hasFile('avatar')) {
            $data['avatar'] = $request->file('avatar')->store('avatars', 'public');
        }

        $user->update([
            'name' => $data['name'],
            'phone' => $data['phone'],
            'email' => $data['email'],
            'address' => $data['address'],
            'avatar' => $data['avatar'] ?? $user->avatar,
        ]);

        $user->customer()->updateOrCreate(
            ['user_id' => $user->id],
            [
                'phone' => $data['phone'],
                'address' => $data['address'],
                'city' => $data['city'] ?? null,
            ]
        );

        return back()->with('success', 'Profile updated successfully.');
    }

    public function updatePassword(Request $request): RedirectResponse
    {
        $request->validate([
            'current_password' => 'required|current_password',
            'password' => 'required|string|min:8|confirmed',
        ]);

        $request->user()->update(['password' => $request->input('password')]);

        return back()->with('success', 'Password changed successfully.');
    }
}
