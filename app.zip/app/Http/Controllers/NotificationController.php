<?php

namespace App\Http\Controllers;

use App\Models\AppNotification;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

/**
 * In-app alerts (SRS: order confirmations, ready-for-pickup, restock alerts,
 * review replies, announcements). Every row here is real.
 */
class NotificationController extends Controller
{
    public function index(Request $request): View
    {
        $notifications = AppNotification::where('user_id', $request->user()->id)
            ->latest()
            ->paginate(20);

        return view('notifications', [
            'notifications' => $notifications,
            'unread' => AppNotification::where('user_id', $request->user()->id)->whereNull('read_at')->count(),
            'announcements' => \App\Models\Announcement::liveFor($request->user()->role)->take(3),
        ]);
    }

    public function read(Request $request, $id): RedirectResponse
    {
        $notification = AppNotification::where('user_id', $request->user()->id)->findOrFail($id);
        $notification->update(['read_at' => now()]);

        return $notification->url
            ? redirect()->away($notification->url)
            : back()->with('success', 'Marked as read.');
    }

    public function readAll(Request $request): RedirectResponse
    {
        AppNotification::where('user_id', $request->user()->id)
            ->whereNull('read_at')
            ->update(['read_at' => now()]);

        return back()->with('success', 'All notifications marked as read.');
    }
}
