<?php

namespace App\Http\Controllers;

use App\Models\Announcement;
use App\Models\AppNotification;
use App\Models\Category;
use App\Models\Market;
use App\Models\Order;
use App\Models\Product;
use App\Models\Review;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use App\Support\Notifier;
use Illuminate\Support\Facades\Storage;
use Illuminate\View\View;

class AdminController extends Controller
{
    /** SRS: dashboard summarizes total farmers, customers, markets, orders. */
    public function dashboard(): View
    {
        $daily = Order::where('created_at', '>=', now()->subDays(13)->startOfDay())
            ->get(['created_at', 'subtotal']);

        $revenue = (float) Order::where('status', Order::ST_COMPLETED)->sum('subtotal');

        return view('admin.dashboard', [
            'totalFarmers' => User::where('role', User::ROLE_FARMER)->count(),
            'totalCustomers' => User::where('role', User::ROLE_CUSTOMER)->count(),
            'totalMarkets' => Market::where('is_active', true)->count(),
            'totalOrders' => Order::count(),
            'totalProducts' => Product::count(),
            'pendingFarmers' => User::where('role', User::ROLE_FARMER)->where('is_active', false)->count(),
            'pendingOrders' => Order::where('status', Order::ST_PENDING)->count(),
            'revenueFmt' => number_format($revenue, 0),
            'avgRating' => ($avg = Review::avg('rating')) === null ? '—' : number_format((float) $avg, 1),
            'recentUsers' => User::with('farmer')->latest()->limit(5)->get(),
            'recentOrders' => Order::with(['customer', 'farmer'])->latest()->limit(5)->get(),
            'topFarmers' => User::where('role', User::ROLE_FARMER)
                ->with('farmer')
                ->withCount('products')
                ->get()
                ->sortByDesc(fn ($u) => $u->completedRevenue())
                ->take(4)
                ->values(),
            'salesTrend' => $daily,
        ]);
    }

    public function farmers(): View
    {
        $farmers = User::where('role', User::ROLE_FARMER)->with('farmer')->withCount(['products', 'farmerOrders'])->latest()->get();

        return view('admin.farmers', [
            'farmers' => $farmers,
            'statTotal' => $farmers->count(),
            'statApproved' => $farmers->filter(fn ($f) => (bool) ($f->farmer->is_approved ?? false))->count(),
            'statPending' => $farmers->filter(fn ($f) => ! ($f->farmer->is_approved ?? false))->count(),
            'statProducts' => $farmers->sum('products_count'),
            'statSuspended' => $farmers->where('is_active', false)->count(),
        ]);
    }

    public function customers(): View
    {
        $customers = User::where('role', User::ROLE_CUSTOMER)->with('customer')->withCount('customerOrders')->latest()->get();

        return view('admin.customers', [
            'customers' => $customers,
            'statTotal' => $customers->count(),
            'statActive' => $customers->where('is_active', true)->count(),
            'statInactive' => $customers->where('is_active', false)->count(),
        ]);
    }

    /** Real markets + create/edit/delete (no prototype cards). */
    public function markets(): View
    {
        $markets = Market::withCount('farmers')->orderBy('name')->get();

        return view('admin.markets', [
            'markets' => $markets,
            'statTotal' => $markets->count(),
            'statActive' => $markets->where('is_active', true)->count(),
            'statStalls' => (int) $markets->sum('farmers_count'),
        ]);
    }

    public function storeMarket(Request $request): RedirectResponse
    {
        $data = $this->validateMarket($request);

        Market::create($data);

        return back()->with('success', 'Market "' . $data['name'] . '" created.');
    }

    public function updateMarket(Request $request, Market $market): RedirectResponse
    {
        $data = $this->validateMarket($request, $market);
        $oldName = $market->name;

        $market->update($data);

        // Keep existing orders pointing at the renamed market.
        if ($oldName !== $market->name) {
            Order::where('market', $oldName)->update(['market' => $market->name]);
        }

        return back()->with('success', 'Market "' . $market->name . '" updated.');
    }

    public function destroyMarket(Market $market): RedirectResponse
    {
        $name = $market->name;
        $market->delete();

        return back()->with('success', 'Market "' . $name . '" deleted.');
    }

    private function validateMarket(Request $request, ?Market $market = null): array
    {
        $data = $request->validate([
            'name' => 'required|string|max:150|unique:markets,name' . ($market ? ',' . $market->id : ''),
            'city' => 'nullable|string|max:100',
            'address' => 'nullable|string|max:255',
            'days' => 'nullable|array',
            'days.*' => 'string|in:' . implode(',', Market::DAYS),
            'open_time' => 'nullable|date_format:H:i',
            'close_time' => 'nullable|date_format:H:i',
            'description' => 'nullable|string|max:1000',
            'google_maps_url' => 'nullable|url|max:255',
            'latitude' => 'nullable|numeric|between:-90,90',
            'longitude' => 'nullable|numeric|between:-180,180',
            'is_active' => 'nullable|boolean',
        ]);

        $data['days'] = $data['days'] ?? [];
        $data['is_active'] = $request->boolean('is_active', true);

        return $data;
    }

    public function products(): View
    {
        return view('admin.products', [
            'products' => Product::with('farmer')->latest()->get(),
        ]);
    }

    public function orders(): View
    {
        $orders = Order::with(['customer', 'farmer', 'items'])->latest()->get();

        return view('admin.orders', [
            'orders' => $orders,
            'statTotal' => $orders->count(),
            'statPending' => $orders->where('status', Order::ST_PENDING)->count(),
            'statCompleted' => $orders->where('status', Order::ST_COMPLETED)->count(),
            'statCancelled' => $orders->where('status', Order::ST_CANCELLED)->count(),
        ]);
    }

    public function reviews(): View
    {
        return view('admin.reviews', [
            'reviews' => Review::with(['customer', 'farmer', 'order', 'product'])->latest()->get(),
        ]);
    }

    /** Reports built from live aggregates (orders, revenue, categories). */
    public function reports(): View
    {
        $orders = Order::all();
        $revenue = (float) $orders->where('status', Order::ST_COMPLETED)->sum('subtotal');

        $monthly = [];
        for ($i = 11; $i >= 0; $i--) {
            $month = now()->subMonths($i);
            $monthly[$month->format('M')] = (float) $orders
                ->filter(fn ($o) => $o->created_at && $o->created_at->format('Y-m') === $month->format('Y-m'))
                ->sum('subtotal');
        }

        $categoryShare = [];
        $totalSold = 0;
        foreach (Category::names() as $category) {
            $qty = (int) \App\Models\OrderItem::whereHas('product', fn ($q) => $q->where('category', $category))->sum('qty');
            $categoryShare[$category] = $qty;
            $totalSold += $qty;
        }

        $topFarmers = User::where('role', User::ROLE_FARMER)
            ->with('farmer')
            ->withCount('farmerOrders')
            ->get()
            ->map(fn ($u) => [
                'name' => $u->displayName(),
                'orders' => $u->farmer_orders_count,
                'revenue' => $u->completedRevenue(),
                'rating' => $u->averageRating(),
            ])
            ->sortByDesc('revenue')
            ->take(5)
            ->values();

        return view('admin.reports', [
            'totalFarmers' => User::where('role', User::ROLE_FARMER)->count(),
            'totalCustomers' => User::where('role', User::ROLE_CUSTOMER)->count(),
            'totalOrders' => $orders->count(),
            'totalProducts' => Product::count(),
            'totalMarkets' => Market::count(),
            'revenueFmt' => number_format($revenue, 0),
            'avgOrderFmt' => $orders->count() ? number_format($revenue / max(1, $orders->where('status', Order::ST_COMPLETED)->count()), 0) : '0',
            'monthly' => $monthly,
            'categoryShare' => $categoryShare,
            'totalSold' => $totalSold,
            'topFarmers' => $topFarmers,
        ]);
    }

    public function approveFarmer(User $user): RedirectResponse
    {
        abort_unless($user->isFarmer(), 404);

        $pending = ! optional($user->farmer)->is_approved;

        optional($user->farmer)->update(['is_approved' => $pending]);
        $user->update(['is_active' => $pending ? true : $user->is_active]);

        if ($pending) {
            Notifier::send(
                $user,
                'announcement',
                'Your stall is approved',
                'You can now list products and take pre-orders on MarketLink.',
                '/farmer-add-product'
            );
        }

        return back()->with('success', $pending
            ? 'Farmer "' . $user->displayName() . '" approved — they can list products now.'
            : 'Approval revoked for "' . $user->displayName() . '".');
    }

    /** SRS content moderation: unpublish an inappropriate listing. */
    public function moderateProduct(Product $product): RedirectResponse
    {
        $product->update(['is_available' => ! $product->is_available]);

        return back()->with('success', '"' . $product->name . '" is now '
            . ($product->is_available ? 'live again.' : 'unpublished (hidden from the storefront).'));
    }

    /** SRS content moderation: remove a review that breaks the guidelines. */
    public function destroyReview(Review $review): RedirectResponse
    {
        $label = $review->product?->name ?? ($review->farmer?->displayName() ?? 'stall');
        $review->delete();

        return back()->with('success', 'Review on "' . $label . '" removed.');
    }

    // ------------------------------------------------------------------
    //  System configuration (SRS): categories + announcements
    // ------------------------------------------------------------------

    public function categories(): View
    {
        return view('admin.categories', [
            'categories' => Category::orderBy('sort_order')->orderBy('name')->get(),
            'unlisted' => Product::select('category')
                ->distinct()
                ->pluck('category')
                ->reject(fn ($c) => Category::where('name', $c)->exists())
                ->values(),
        ]);
    }

    public function storeCategory(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'name' => 'required|string|max:60|unique:categories,name',
            'description' => 'nullable|string|max:255',
            'sort_order' => 'nullable|integer|min:0|max:999',
            'is_active' => 'nullable|boolean',
        ]);

        Category::create([
            'name' => $data['name'],
            'description' => $data['description'] ?? null,
            'sort_order' => $data['sort_order'] ?? 0,
            'is_active' => $request->boolean('is_active', true),
        ]);

        return back()->with('success', 'Category "' . $data['name'] . '" added — it appears in product forms and filters.');
    }

    public function updateCategory(Request $request, Category $category): RedirectResponse
    {
        $data = $request->validate([
            'name' => 'required|string|max:60|unique:categories,name,' . $category->id,
            'description' => 'nullable|string|max:255',
            'sort_order' => 'nullable|integer|min:0|max:999',
            'is_active' => 'nullable|boolean',
        ]);

        $oldName = $category->name;

        $category->update([
            'name' => $data['name'],
            'description' => $data['description'] ?? null,
            'sort_order' => $data['sort_order'] ?? 0,
            'is_active' => $request->boolean('is_active', true),
        ]);

        $moved = 0;
        if ($oldName !== $data['name']) {
            // rename cascade: products keep their listing, the category label moves
            $moved = Product::where('category', $oldName)->update(['category' => $data['name']]);
        }

        return back()->with('success', 'Category updated' . ($moved ? ' — ' . $moved . ' product(s) moved to "' . $data['name'] . '".' : '.'));
    }

    public function destroyCategory(Category $category): RedirectResponse
    {
        $inUse = Product::where('category', $category->name)->count();
        if ($inUse > 0) {
            return back()->with('error', '"' . $category->name . '" is still used by ' . $inUse
                . ' product(s). Move or rename those listings first.');
        }

        $name = $category->name;
        $category->delete();

        return back()->with('success', 'Category "' . $name . '" removed.');
    }

    public function announcements(): View
    {
        return view('admin.announcements', [
            'announcements' => Announcement::latest()->get(),
            'audiences' => Announcement::AUDIENCES,
            'sentCount' => AppNotification::where('type', 'announcement')->count(),
        ]);
    }

    public function storeAnnouncement(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'title' => 'required|string|max:150',
            'body' => 'required|string|max:2000',
            'audience' => 'required|in:' . implode(',', array_keys(Announcement::AUDIENCES)),
            'is_active' => 'nullable|boolean',
            'notify' => 'nullable|boolean',
        ]);

        $announcement = Announcement::create([
            'title' => $data['title'],
            'body' => $data['body'],
            'audience' => $data['audience'],
            'is_active' => $request->boolean('is_active', true),
            'published_at' => now(),
        ]);

        $sent = 0;
        if ($request->boolean('notify')) {
            $roles = $data['audience'] === 'farmers' ? [User::ROLE_FARMER]
                : ($data['audience'] === 'customers' ? [User::ROLE_CUSTOMER] : [User::ROLE_FARMER, User::ROLE_CUSTOMER]);

            foreach (User::whereIn('role', $roles)->get() as $user) {
                Notifier::send($user, 'announcement', $announcement->title, $announcement->body, '/notifications');
                $sent++;
            }
        }

        return back()->with('success', 'Announcement published'
            . ($sent ? ' — alert sent to ' . $sent . ' account(s).' : '.'));
    }

    public function updateAnnouncement(Request $request, Announcement $announcement): RedirectResponse
    {
        $data = $request->validate([
            'title' => 'required|string|max:150',
            'body' => 'required|string|max:2000',
            'audience' => 'required|in:' . implode(',', array_keys(Announcement::AUDIENCES)),
            'is_active' => 'nullable|boolean',
        ]);

        $announcement->update([
            'title' => $data['title'],
            'body' => $data['body'],
            'audience' => $data['audience'],
            'is_active' => $request->boolean('is_active', true),
        ]);

        return back()->with('success', 'Announcement updated.');
    }

    public function destroyAnnouncement(Announcement $announcement): RedirectResponse
    {
        $announcement->delete();

        return back()->with('success', 'Announcement removed.');
    }

    public function toggleFarmer(User $user): RedirectResponse
    {
        abort_unless($user->isFarmer(), 404);
        $user->update(['is_active' => !$user->is_active]);

        return back()->with('success', $user->is_active ? 'Farmer activated.' : 'Farmer suspended.');
    }

    public function destroyFarmer(User $user): RedirectResponse
    {
        abort_unless($user->isFarmer(), 404);
        foreach ($user->products as $product) {
            $this->deletePublicFile($product->image);
        }
        $this->deletePublicFile($user->avatar);
        $name = $user->name;
        $user->delete();

        return back()->with('success', 'Farmer "' . $name . '" and all their products removed.');
    }

    public function toggleCustomer(User $user): RedirectResponse
    {
        abort_unless($user->isCustomer(), 404);
        $user->update(['is_active' => !$user->is_active]);

        return back()->with('success', $user->is_active ? 'Customer activated.' : 'Customer suspended.');
    }

    public function destroyCustomer(User $user): RedirectResponse
    {
        abort_unless($user->isCustomer(), 404);
        $this->deletePublicFile($user->avatar);
        $name = $user->name;
        $user->delete();

        return back()->with('success', 'Customer "' . $name . '" and all their data removed.');
    }

    private function deletePublicFile(?string $path): void
    {
        if ($path && !str_starts_with($path, 'http')) {
            Storage::disk('public')->delete($path);
        }
    }
}
