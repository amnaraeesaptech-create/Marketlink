<?php

namespace App\Http\Controllers;

use App\Models\Farmer;
use App\Models\Market;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\View\View;

class FarmerController extends Controller
{
    /**
     * Farmer dashboard — every figure is computed from this farmer's own rows
     * (orders, order items, products). No placeholders, no demo values.
     */
    public function dashboard(): View
    {
        $user = request()->user();
        $orders = $user->farmerOrders();
        $revenue = $user->completedRevenue();

        $recentOrders = $user->farmerOrders()
            ->with(['customer', 'items'])
            ->latest()
            ->limit(5)
            ->get();

        $lowStock = $user->products()
            ->where('stock', '>', 0)
            ->where('stock', '<', 5)
            ->orderBy('stock')
            ->get();

        $outOfStock = $user->products()
            ->where(fn ($q) => $q->where('stock', '<=', 0)->orWhere('is_available', false))
            ->get();

        // Units sold + money earned per product, from the real order lines.
        $topProducts = \App\Models\OrderItem::query()
            ->join('orders', 'orders.id', '=', 'order_items.order_id')
            ->where('orders.farmer_id', $user->id)
            ->whereNotIn('orders.status', [\App\Models\Order::ST_CANCELLED])
            ->selectRaw('order_items.name as name, SUM(order_items.qty) as qty_sold, SUM(order_items.qty * order_items.price) as money')
            ->groupBy('order_items.name')
            ->orderByDesc('qty_sold')
            ->limit(3)
            ->get();

        // Last 7 days of order value, straight from the orders table.
        $weekly = [];
        for ($i = 6; $i >= 0; $i--) {
            $day = now()->subDays($i);
            $weekly[] = [
                'label' => $day->format('D'),
                'date' => $day->format('M j'),
                'value' => (float) $user->farmerOrders()
                    ->whereNotIn('status', [\App\Models\Order::ST_CANCELLED])
                    ->whereDate('created_at', $day->toDateString())
                    ->sum('subtotal'),
            ];
        }
        $weeklyMax = max(1, max(array_column($weekly, 'value')));

        return view('farmer.dashboard', [
            'user' => $user->load('farmer'),
            'productsCount' => $user->products()->count(),
            'activeProducts' => $user->products()->where('is_available', true)->where('stock', '>', 0)->count(),
            'pendingOrders' => (clone $orders)->where('status', \App\Models\Order::ST_PENDING)->count(),
            'confirmedOrders' => (clone $orders)->where('status', \App\Models\Order::ST_CONFIRMED)->count(),
            'readyOrders' => (clone $orders)->where('status', \App\Models\Order::ST_READY)->count(),
            'completedOrders' => (clone $orders)->where('status', \App\Models\Order::ST_COMPLETED)->count(),
            'totalOrders' => (clone $orders)->count(),
            'monthOrders' => (clone $orders)->where('created_at', '>=', now()->startOfMonth())->count(),
            'revenue' => $revenue,
            'revenueFmt' => number_format($revenue, 0),
            'recentOrders' => $recentOrders,
            'lowStock' => $lowStock,
            'outOfStock' => $outOfStock,
            'topProducts' => $topProducts,
            'weekly' => $weekly,
            'weeklyMax' => $weeklyMax,
            'avgRating' => $user->averageRating(),
            'reviewCount' => $user->reviewsReceived()->stall()->count(),
            'marketNames' => $user->marketNames(),
            'customersServed' => (clone $orders)->distinct('customer_id')->count('customer_id'),
        ]);
    }

    public function reviews(): View
    {
        $user = request()->user();

        $reviews = $user->reviewsReceived()->with(['customer', 'order', 'product'])->latest()->get();
        $dist = [5 => 0, 4 => 0, 3 => 0, 2 => 0, 1 => 0];
        foreach ($reviews as $r) {
            if (isset($dist[$r->rating])) $dist[$r->rating]++;
        }
        $total = $reviews->count();
        $avg = $user->averageRating();
        $pct = fn ($s) => $total > 0 ? round(($dist[$s] ?? 0) * 100 / $total) : 0;

        return view('farmer.reviews', [
            'reviews' => $reviews,
            'repliedCount' => $reviews->filter->hasReply()->count(),
            'awaitingReply' => $reviews->reject->hasReply()->count(),
            'avg' => $avg,
            'avgFmt' => number_format($avg, 1),
            'total' => $total,
            'dist' => $dist,
            'posPct' => $total > 0 ? round((($dist[4] ?? 0) + ($dist[5] ?? 0)) * 100 / $total) : 0,
            'pct5' => $pct(5), 'pct4' => $pct(4), 'pct3' => $pct(3),
            'pct2' => $pct(2), 'pct1' => $pct(1),
            'n5' => $dist[5], 'n4' => $dist[4], 'n3' => $dist[3],
            'n2' => $dist[2], 'n1' => $dist[1],
        ]);
    }

    /**
     * Real stall profile: ?id= shows any farmer's public page (linked from the
     * farmers directory), a logged-in farmer sees their own without an id.
     */
    /** SRS: "farmers can respond to customer reviews". */
    public function replyReview(Request $request, $id): RedirectResponse
    {
        $review = \App\Models\Review::where('farmer_id', $request->user()->id)->findOrFail($id);

        $data = $request->validate(['farmer_reply' => 'required|string|max:1000']);

        $review->update(['farmer_reply' => $data['farmer_reply'], 'replied_at' => now()]);

        \App\Support\Notifier::reviewReply($review);

        return back()->with('success', 'Reply posted — the client has been notified.');
    }

    /** SRS: "recurring weekly stock template" — one page to set the whole week's stock. */
    public function stockTemplate(): View
    {
        $user = request()->user();

        return view('farmer.stock-template', [
            'products' => $user->products()->orderBy('name')->get(),
            'lastUpdated' => optional($user->products()->orderByDesc('updated_at')->first())->updated_at,
        ]);
    }

    public function saveStockTemplate(Request $request): RedirectResponse
    {
        $user = $request->user();

        $data = $request->validate([
            'stock' => 'required|array',
            'stock.*' => 'nullable|integer|min:0|max:1000000',
            'available' => 'nullable|array',
        ]);

        $updated = 0;
        $restocked = [];

        foreach ($user->products()->get() as $product) {
            if (! array_key_exists($product->id, $data['stock'])) {
                continue;
            }

            $newStock = (int) $data['stock'][$product->id];
            $newAvailable = (bool) in_array((string) $product->id, array_map('strval', $data['available'] ?? []), true);
            $wasOut = $product->stock <= 0;

            if ($newStock !== (int) $product->stock || $newAvailable !== (bool) $product->is_available) {
                $product->update(['stock' => $newStock, 'is_available' => $newAvailable]);
                $updated++;

                if ($wasOut && $newStock > 0 && $newAvailable) {
                    $restocked[] = $product;
                }
            }
        }

        foreach ($restocked as $product) {
            \App\Support\Notifier::productRestocked($product);
        }

        return back()->with('success', $updated . ' product(s) updated for this week'
            . ($restocked ? ' — ' . count($restocked) . ' restock alert(s) sent to clients who saved them.' : '.'));
    }

    public function profile(Request $request): View|RedirectResponse
    {
        $user = null;

        if ($request->filled('id')) {
            $user = User::where('role', User::ROLE_FARMER)->with('farmer')->findOrFail($request->integer('id'));
        } elseif (Auth::check() && Auth::user()->isFarmer()) {
            $user = Auth::user()->load('farmer');
        }

        if (! $user) {
            return redirect()->away('/farmers')->with('error', 'Pick a stall to view its public profile.');
        }

        return view('farmer.profile', [
            'farmer' => $user->farmer,
            'farmerUser' => $user,
            'isOwner' => Auth::check() && Auth::id() === $user->id,
            'products' => $user->products()->where('is_available', true)->latest()->get(),
            'reviews' => $user->reviewsReceived()->with('customer')->stall()->latest()->limit(5)->get(),
            'reviewCount' => $user->reviewsReceived()->stall()->count(),
            'avgRating' => $user->averageRating(),
            'productCount' => $user->products()->count(),
            'markets' => $user->marketNames(),
        ]);
    }

    /** SRS: enhance profile — markets, days, pickup windows, map pin. */
    public function editProfile(): View
    {
        return view('farmer.profile-edit', [
            'user' => request()->user()->load('farmer'),
            'allMarkets' => Market::where('is_active', true)->orderBy('name')->get(),
            'selectedMarkets' => request()->user()->marketNames(),
        ]);
    }

    public function updateProfile(Request $request): RedirectResponse
    {
        $user = $request->user();

        $data = $request->validate([
            'stall_name' => 'required|string|max:100',
            'contact_person' => 'required|string|max:100',
            'phone' => 'required|string|max:30',
            'email' => 'required|email|max:255|unique:users,email,' . $user->id,
            'address' => 'required|string|max:255',
            'description' => 'nullable|string|max:2000',
            'markets' => 'nullable|array',
            'markets.*' => 'string|max:100',
            'operating_days' => 'nullable|array',
            'operating_days.*' => 'string|max:10',
            'pickup_windows' => 'nullable|array',
            'pickup_windows.*.day'   => 'nullable|string|in:Mon,Tue,Wed,Thu,Fri,Sat,Sun',
            'pickup_windows.*.start' => 'nullable|date_format:H:i',
            'pickup_windows.*.end'   => 'nullable|date_format:H:i',
            'categories' => 'nullable|array',
            'categories.*' => 'string|max:50',
            'latitude' => 'nullable|numeric|between:-90,90',
            'longitude' => 'nullable|numeric|between:-180,180',
            'cutoff_hours' => 'nullable|integer|min:1|max:168',
            'avatar' => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
        ]);

        if ($request->hasFile('avatar')) {
            $data['avatar'] = $request->file('avatar')->store('avatars', 'public');
        }

        $user->update([
            'name' => $data['contact_person'],
            'phone' => $data['phone'],
            'email' => $data['email'],
            'address' => $data['address'],
        ]);

        // Keep the real market pivot in sync with the ticked/typed markets.
        Market::syncForFarmer(
            $user,
            $data['markets'] ?? [],
            \App\Support\Catalog::cityOf($data['address']),
            $data['operating_days'] ?? []
        );

        Farmer::updateOrCreate(
            ['user_id' => $user->id],
            [
                'stall_name' => $data['stall_name'],
                'contact_person' => $data['contact_person'],
                'phone' => $data['phone'],
                'address' => $data['address'],
                'description' => $data['description'] ?? null,
                'markets' => $data['markets'] ?? [],
                'operating_days' => $data['operating_days'] ?? [],
                'pickup_windows' => array_values(array_filter(
                    array_map(function ($w) {
                        if (!is_array($w) || empty($w['day'])) return null;
                        $label = trim($w['day']
                            . ($w['start'] ? ' ' . $w['start'] : '')
                            . ($w['end']   ? ' - ' . $w['end'] : ''));
                        return [
                            'day'   => $w['day'],
                            'label' => $label,
                            'start' => $w['start'] ?? null,
                            'end'   => $w['end']   ?? null,
                        ];
                    }, $data['pickup_windows'] ?? []),
                    fn ($w) => $w !== null
                )),
                'categories' => $data['categories'] ?? [],
                'cutoff_hours' => $data['cutoff_hours'] ?? 12,
                'latitude' => $data['latitude'] ?? null,
                'longitude' => $data['longitude'] ?? null,
                'avatar' => $data['avatar'] ?? $user->farmer?->avatar,
            ]
        );

        return redirect()->away('/farmer-profile')->with('success', 'Profile updated successfully.');
    }

    public function updatePassword(Request $request): RedirectResponse
    {
        $request->validate([
            'current_password' => 'required|current_password',
            'password' => 'required|string|min:8|confirmed',
        ]);

        $request->user()->update(['password' => $request->input('password')]);

        return back()->with('success', 'Password changed successfully.');
    }
}
