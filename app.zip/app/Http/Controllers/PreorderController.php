<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Product;
use App\Support\Notifier;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class PreorderController extends Controller
{
    /**
     * Place pre-order(s). Cart items arrive as JSON, are grouped per
     * farmer (one order per stall), stock is decremented.
     */
    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'market' => 'nullable|string|max:150',
            'pickup_date' => 'required|date|after_or_equal:today',
            'pickup_slot' => 'nullable|string|max:100',
            'notes' => 'nullable|string|max:1000',
            'items_json' => 'required|string',
        ]);

        $items = json_decode($data['items_json'], true);
        if (!is_array($items) || count($items) === 0) {
            return back()->with('error', 'Your cart is empty. Add some products first.');
        }

        $ids = array_values(array_unique(array_filter(array_map(
            fn ($i) => is_numeric($i['id'] ?? null) ? (int) $i['id'] : null, $items
        ))));
        $dbProducts = Product::with('farmer.farmer')->whereIn('id', $ids)->get()->keyBy('id');

        // Every cart item must exist in the live catalogue.
        foreach ($items as $i) {
            if (!isset($i['id']) || !$dbProducts->has((int) $i['id'])) {
                return back()->with('error', 'Some cart items are no longer available. Please re-add them from the Products page.');
            }
        }

        // Group items per farmer.
        $groups = [];
        foreach ($items as $i) {
            $p = $dbProducts[(int) $i['id']];
            $qty = max(1, (int) ($i['qty'] ?? $i['quantity'] ?? 1));
            if ($qty > $p->stock || !$p->is_available) {
                return back()->with('error', '"' . $p->name . '" only has ' . $p->stock . ' ' . $p->unit . ' left in stock.');
            }
            $groups[$p->farmer_id][] = ['product' => $p, 'qty' => $qty, 'price' => (float) $p->price];
        }

        // SRS: farmers set an order cut-off time — pre-orders must clear it.
        foreach ($groups as $farmerId => $lines) {
            $hours = (int) optional(optional($lines[0]['product']->farmer)->farmer)->cutoff_hours ?: 12;
            $pickupAt = $this->pickupMoment($data['pickup_date'], $data['pickup_slot'] ?? null);
            if ($pickupAt && now()->greaterThanOrEqualTo($pickupAt->copy()->subHours($hours))) {
                $stall = $lines[0]['product']->farmer?->displayName() ?? 'This stall';

                return back()->with('error', $stall . ' closes pre-orders ' . $hours
                    . ' hours before pickup. Please choose a later pickup date or slot.');
            }
        }

        $count = 0;
        $orders = [];
        foreach ($groups as $farmerId => $lines) {
            $subtotal = 0;
            foreach ($lines as $l) {
                $subtotal += $l['price'] * $l['qty'];
            }
            $order = Order::create([
                'customer_id' => $request->user()->id,
                'farmer_id' => $farmerId,
                'market' => $data['market'] ?? null,
                'pickup_date' => $data['pickup_date'],
                'pickup_slot' => $data['pickup_slot'] ?? null,
                'status' => Order::ST_PENDING,
                'subtotal' => $subtotal,
                'notes' => $data['notes'] ?? null,
            ]);
            foreach ($lines as $l) {
                $order->items()->create([
                    'product_id' => $l['product']->id,
                    'name' => $l['product']->name,
                    'unit' => $l['product']->unit,
                    'qty' => $l['qty'],
                    'price' => $l['price'],
                ]);
                $l['product']->decrement('stock', $l['qty']);
            }
            $orders[] = $order;
            $count++;
        }

        // In-app alerts: farmer gets the new pre-order, client gets a receipt.
        foreach ($orders as $order) {
            Notifier::orderPlaced($order);
        }

        // Tell the next page (one-time flash) to clear the browser cart.
        session()->flash('ml_cart_clear', true);

        return redirect()->away('/customer-orders')->with(
            'success',
            $count > 1 ? $count . ' pre-orders placed (one per stall)!' : 'Pre-order placed successfully!'
        );
    }

    /**
     * SRS: "customers can cancel OR MODIFY an order before the farmer's cutoff".
     * Quantities are re-validated against live stock; stock is re-balanced.
     */
    public function updateItems(Request $request, $id): RedirectResponse
    {
        $order = $request->user()->customerOrders()->with('items.product')->findOrFail($id);

        if (!$order->canBeModifiedByCustomer()) {
            return back()->with('error', 'This order can no longer be changed — it is past the stall cutoff or already on its way.');
        }

        $data = $request->validate([
            'qty' => 'required|array',
            'qty.*' => 'nullable|integer|min:0|max:999',
            'pickup_date' => 'nullable|date|after_or_equal:today',
            'pickup_slot' => 'nullable|string|max:60',
            'notes' => 'nullable|string|max:1000',
        ]);

        if ($order->items->isEmpty()) {
            return back()->with('error', 'This order has no line items.');
        }

        // Validate first, mutate after (so a rejected qty changes nothing).
        foreach ($order->items as $item) {
            $qty = (int) ($data['qty'][$item->id] ?? $item->qty);
            if ($qty === 0) {
                continue;
            }
            $available = $item->product ? $item->product->stock + $item->qty : $qty;
            if (!$item->product || !$item->product->is_available) {
                return back()->with('error', '"' . $item->name . '" is no longer listed by the farmer.');
            }
            if ($qty > $available) {
                return back()->with('error', '"' . $item->name . '" only has ' . $available . ' ' . $item->unit . ' available for this order.');
            }
        }

        $subtotal = 0;
        foreach ($order->items as $item) {
            $qty = (int) ($data['qty'][$item->id] ?? $item->qty);
            $diff = $qty - $item->qty;

            if ($qty === 0 && $item->product) {
                $item->product->increment('stock', $item->qty);
                $item->delete();
                continue;
            }
            if ($qty === 0) {
                $item->delete();
                continue;
            }

            if ($diff !== 0 && $item->product) {
                $diff > 0
                    ? $item->product->decrement('stock', $diff)
                    : $item->product->increment('stock', abs($diff));
            }
            $item->update(['qty' => $qty]);
            $subtotal += (float) $item->price * $qty;
        }

        if ($order->items()->count() === 0) {
            $order->update(['status' => Order::ST_CANCELLED]);
            Notifier::send($order->fresh()->farmer, 'order_cancelled', 'Order ' . $order->code() . ' cancelled', 'The client removed every item, all stock was returned.', '/farmer-orders');

            return back()->with('success', 'All items were removed, so order ' . $order->code() . ' was cancelled and stock returned.');
        }

        $order->update(['subtotal' => $subtotal]);

        if (array_key_exists('notes', $data)) {
            $order->update(['notes' => $data['notes']]);
        }

        // SRS: the client may move the pickup date/time slot before the cut-off.
        $slot = array_filter([
            'pickup_date' => $data['pickup_date'] ?? null,
            'pickup_slot' => $data['pickup_slot'] ?? null,
        ], fn ($v) => $v !== null && $v !== '');
        if ($slot) {
            $order->update($slot);
        }

        Notifier::send(
            $order->farmer,
            'order_status',
            'Order ' . $order->code() . ' updated by the client',
            'New total PKR ' . number_format($subtotal, 0) . '.',
            '/farmer-orders'
        );

        return back()->with('success', 'Order ' . $order->code() . ' updated — new total PKR ' . number_format($subtotal, 0) . '.');
    }

    /** Customer cancels their own pending/confirmed order; stock is restored. */
    public function cancel(Request $request, $id): RedirectResponse
    {
        $order = $request->user()->customerOrders()->with('items.product')->findOrFail($id);

        if (!$order->canBeCancelledByCustomer()) {
            return back()->with('error', 'This order can no longer be cancelled'
                . ($order->cutoffAt() ? ' (stall cutoff was ' . $order->cutoffAt()->format('M j, g:i A') . ').' : '.'));
        }

        foreach ($order->items as $item) {
            if ($item->product) {
                $item->product->increment('stock', $item->qty);
            }
        }
        $order->update(['status' => Order::ST_CANCELLED]);

        Notifier::send(
            $order->farmer,
            'order_cancelled',
            'Order ' . $order->code() . ' cancelled by the client',
            'Reserved stock has been returned to your inventory.',
            '/farmer-orders'
        );

        return back()->with('success', 'Order ' . $order->code() . ' cancelled.');
    }

    private function pickupMoment(string $date, ?string $slot): ?\Illuminate\Support\Carbon
    {
        $at = \Illuminate\Support\Carbon::parse($date)->startOfDay();

        if ($slot && preg_match('/(\d{1,2}):(\d{2})\s*(am|pm)?/i', $slot, $m)) {
            $hour = (int) $m[1];
            $min = (int) $m[2];
            $meridiem = strtolower($m[3] ?? '');
            if ($meridiem === 'pm' && $hour < 12) {
                $hour += 12;
            }
            if ($meridiem === 'am' && $hour === 12) {
                $hour = 0;
            }

            return $at->setTime($hour, $min);
        }

        return $at->setTime(8, 0);
    }
}
