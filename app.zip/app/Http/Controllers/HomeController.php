<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Support\Catalog;
use Illuminate\Http\Request;
use Illuminate\View\View;

/** Storefront pages: home, farmers directory, product catalogue + details. */
class HomeController extends Controller
{
    public function index(): View
    {
        return view('index', [
            'stats' => Catalog::stats(),
            'featuredProducts' => Catalog::featuredProducts(4),
            'farmers' => Catalog::farmers(),
            'markets' => Catalog::markets()->take(3),
            'testimonials' => Catalog::testimonials(3),
        ]);
    }

    public function farmers(): View
    {
        return view('farmers', [
            'farmers' => Catalog::farmers(),
            'markets' => Catalog::markets(),
        ]);
    }

    public function products(): View
    {
        return view('products', [
            'products' => Product::with('farmer.farmer')->fromApprovedStall()
                ->where('is_available', true)
                ->where('stock', '>', 0)
                ->latest()
                ->get(),
            'farmers' => Catalog::farmers(),
            'markets' => Catalog::markets(),
            'categoryCounts' => Catalog::categoryCounts(),
        ]);
    }

    /** Product page: ?id= selects the product, otherwise the top rated one. */
    public function productDetails(Request $request): View
    {
        $product = $request->filled('id')
            ? Product::with('farmer.farmer')->fromApprovedStall()->findOrFail($request->integer('id'))
            : Product::with('farmer.farmer')->where('is_available', true)->orderByDesc('rating')->first();

        // Stall reviews (left on the order) + reviews written against this product.
        $farmerReviews = $product
            ? ($product->farmer?->reviewsReceived()->with('customer')->stall()->latest()->get() ?? collect())
            : collect();

        $productReviews = $product
            ? \App\Models\Review::with('customer')->where('product_id', $product->id)->latest()->get()
            : collect();

        $related = $product
            ? Product::with('farmer.farmer')
                ->fromApprovedStall()
                ->where('category', $product->category)
                ->where('id', '!=', $product->id)
                ->where('is_available', true)
                ->where('stock', '>', 0)
                ->limit(4)
                ->get()
            : collect();

        return view('product-details', [
            'product' => $product,
            'farmerReviews' => $farmerReviews,
            'productReviews' => $productReviews,
            'productRating' => $productReviews->count() ? round($productReviews->avg('rating'), 1) : null,
            'related' => $related,
            'products' => Catalog::products(),
        ]);
    }
}
