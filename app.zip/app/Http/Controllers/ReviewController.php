<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Review;
use App\Support\Notifier;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class ReviewController extends Controller
{
    /** Customer rates a farmer after a completed pickup. */
    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate([
            'order_id' => 'required|exists:orders,id',
            'product_id' => 'nullable|integer|exists:products,id',
            'rating' => 'required|integer|min:1|max:5',
            'comment' => 'nullable|string|max:1000',
        ]);

        $order = $request->user()->customerOrders()->with('items')->findOrFail($data['order_id']);

        if ($order->status !== Order::ST_COMPLETED) {
            return back()->with('error', 'You can review this order once it is completed.');
        }
        if (!$order->farmer_id) {
            return back()->with('error', 'This order has no farmer attached.');
        }

        $productId = $data['product_id'] ?? null;

        if ($productId) {
            // SRS: rate individual products — one review per product per order.
            if (!$order->items->contains('product_id', (int) $productId)) {
                return back()->with('error', 'That product was not part of this order.');
            }
            if (Review::where('order_id', $order->id)->where('product_id', $productId)->exists()) {
                return back()->with('error', 'You have already reviewed this product for this order.');
            }
        } elseif ($order->review) {
            return back()->with('error', 'You have already reviewed this stall for this order.');
        }

        $review = Review::create([
            'customer_id' => $request->user()->id,
            'farmer_id' => $order->farmer_id,
            'order_id' => $order->id,
            'product_id' => $productId,
            'rating' => $data['rating'],
            'comment' => $data['comment'] ?? null,
        ]);

        // Keep the stored product rating column in sync with real reviews
        if ($productId) {
            $avg = Review::where('product_id', $productId)->avg('rating');
            \App\Models\Product::where('id', $productId)
                ->update(['rating' => round((float) $avg, 1)]);
        }

        Notifier::send(
            $order->farmer,
            'review',
            $productId
                ? 'New ' . $data['rating'] . '-star review on ' . ($review->product->name ?? 'a product')
                : 'New ' . $data['rating'] . '-star stall review',
            $data['comment'] ?? 'No comment left.',
            '/farmer-reviews'
        );

        return back()->with('success', $productId
            ? 'Thanks! Your product review was submitted.'
            : 'Thank you! Your stall review was submitted.');
    }

    public function destroy(Request $request, $id): RedirectResponse
    {
        $review = Review::where('customer_id', $request->user()->id)->findOrFail($id);
        $review->delete();

        return back()->with('success', 'Review deleted.');
    }

    /** Farmer replies to a review left on their stall / products. */
    public function reply(Request $request, $id): RedirectResponse
    {
        $review = Review::where('farmer_id', $request->user()->id)->findOrFail($id);

        $data = $request->validate([
            'farmer_reply' => 'required|string|max:1000',
        ]);

        $review->update([
            'farmer_reply' => $data['farmer_reply'],
            'replied_at' => now(),
        ]);

        Notifier::reviewReply($review);

        return back()->with('success', 'Your reply was posted.');
    }
}
