<?php

namespace App\Http\Controllers;

use App\Models\Market;
use App\Models\Order;
use App\Support\Catalog;
use Illuminate\Http\Request;
use Illuminate\View\View;

/** Public market directory — reads the real markets table. */
class MarketController extends Controller
{
    public function index(Request $request): View
    {
        $markets = Catalog::markets();

        if ($request->filled('city')) {
            $markets = $markets->where('city', $request->input('city'));
        }

        return view('markets', [
            'markets' => $markets,
            'cities' => Catalog::markets()->pluck('city')->filter()->unique()->sort()->values(),
        ]);
    }

    /** Single market: its stalls, their products and the pre-orders heading there. */
    public function show(Request $request): View
    {
        $market = $request->filled('id')
            ? Market::withCount('farmers')->findOrFail($request->integer('id'))
            : Catalog::markets()->firstOrFail();

        $farmers = $market->farmers()
            ->with(['farmer'])
            ->withCount('products')
            ->get();

        $products = \App\Models\Product::with('farmer.farmer')->fromApprovedStall()
            ->whereIn('farmer_id', $farmers->pluck('id'))
            ->where('is_available', true)
            ->where('stock', '>', 0)
            ->latest()
            ->get();

        $orders = Order::where('market', $market->name)->count();
        $upcoming = Order::with('farmer')
            ->where('market', $market->name)
            ->whereDate('pickup_date', '>=', now()->toDateString())
            ->orderBy('pickup_date')
            ->limit(5)
            ->get();

        return view('market-details', [
            'market' => $market,
            'farmers' => $farmers,
            'products' => $products,
            'ordersCount' => $orders,
            'upcoming' => $upcoming,
        ]);
    }
}
