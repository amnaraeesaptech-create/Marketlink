<?php

namespace App\Http\Controllers;

use App\Models\Favorite;
use App\Models\Market;
use App\Models\Product;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class FavoriteController extends Controller
{
    /**
     * Toggle a favourite. SRS asks for favourite Farmers, preferred market
     * locations and products, so the same endpoint takes any of the three.
     */
    public function toggle(Request $request): Response
    {
        $data = $request->validate([
            'product_id' => 'nullable|integer|exists:products,id',
            'farmer_id' => 'nullable|integer|exists:users,id',
            'market_id' => 'nullable|integer|exists:markets,id',
        ]);

        $column = collect(['product_id', 'farmer_id', 'market_id'])
            ->first(fn ($c) => ! empty($data[$c]));

        if (! $column) {
            return $request->expectsJson()
                ? response()->json(['favorited' => false, 'message' => 'Nothing to save.'], 422)
                : back()->with('error', 'Nothing to save.');
        }

        $id = (int) $data[$column];
        $query = Favorite::where('customer_id', $request->user()->id)->where($column, $id);
        $existing = $query->first();

        if ($existing) {
            $existing->delete();
            $favorited = false;
            $message = 'Removed from favourites.';
        } else {
            Favorite::create(['customer_id' => $request->user()->id, $column => $id]);
            $favorited = true;
            $message = match ($column) {
                'farmer_id' => 'Farmer saved to favourites!',
                'market_id' => 'Market saved — you will see it on your dashboard.',
                default => 'Added to favourites!',
            };
        }

        $counts = [
            'products' => Favorite::where('customer_id', $request->user()->id)->whereNotNull('product_id')->count(),
            'farmers' => Favorite::where('customer_id', $request->user()->id)->whereNotNull('farmer_id')->count(),
            'markets' => Favorite::where('customer_id', $request->user()->id)->whereNotNull('market_id')->count(),
        ];

        if ($request->expectsJson() || $request->ajax()) {
            return response()->json([
                'favorited' => $favorited,
                'message' => $message,
                'count' => array_sum($counts),
                'counts' => $counts,
            ]);
        }

        return back()->with('success', $message);
    }
}
