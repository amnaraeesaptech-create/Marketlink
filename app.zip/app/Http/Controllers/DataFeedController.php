<?php

namespace App\Http\Controllers;

use App\Support\Catalog;
use Illuminate\Http\Response;

/**
 * Live storefront feed.
 *
 * Replaces the old static public/assets/js/data.js mock. Every number and
 * record in window.ML now comes from the database, so anything a farmer or
 * admin creates/updates/deletes is reflected instantly.
 */
class DataFeedController extends Controller
{
    public function js(): Response
    {
        $payload = [
            'products' => Catalog::products(),
            'farmers' => Catalog::farmers(),
            'markets' => Catalog::markets()->map(fn ($m) => [
                'id' => $m->id,
                'name' => $m->name,
                'address' => $m->address,
                'city' => $m->city,
                'days' => $m->days ?? [],
                'openTime' => $m->open_time,
                'closeTime' => $m->close_time,
                'farmerCount' => $m->farmers_count,
                'image' => $m->imageUrl(),
                'description' => $m->description,
            ])->values()->all(),
            'categories' => \App\Models\Category::names(),
            'stats' => Catalog::stats(),
        ];

        $json = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

        return response(
            'window.ML = ' . $json . ";\n",
            200,
            [
                'Content-Type' => 'application/javascript; charset=utf-8',
                'Cache-Control' => 'no-store, max-age=0',
            ]
        );
    }
}
