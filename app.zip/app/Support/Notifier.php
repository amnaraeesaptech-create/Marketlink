<?php

namespace App\Support;

use App\Models\AppNotification;
use App\Models\Order;
use App\Models\Product;
use App\Models\User;

/**
 * In-app notifications (SRS: "customers should receive in-app alerts for order
 * confirmations and orders ready for pickup").
 *
 * Every alert is a real row in `app_notifications`, shown in the navbar bell
 * and on /notifications. Nothing is faked client-side.
 */
class Notifier
{
    public static function send(?User $user, string $type, string $title, ?string $body = null, ?string $url = null): ?AppNotification
    {
        if (! $user) {
            return null;
        }

        return AppNotification::create([
            'user_id' => $user->id,
            'type' => $type,
            'title' => $title,
            'body' => $body,
            'url' => $url,
        ]);
    }

    /** New pre-order landed → tell the farmer. Confirm to the client. */
    public static function orderPlaced(Order $order): void
    {
        $order->loadMissing(['farmer', 'customer', 'items']);

        self::send(
            $order->farmer,
            'order_placed',
            'New pre-order ' . $order->code(),
            $order->customer?->name . ' ordered ' . $order->items->sum('qty') . ' item(s) — PKR '
                . number_format((float) $order->subtotal, 0) . ' for ' . ($order->pickup_date ?? 'pickup'),
            '/farmer-orders'
        );

        self::send(
            $order->customer,
            'order_placed',
            'Pre-order ' . $order->code() . ' placed',
            'Waiting for ' . ($order->farmer?->displayName() ?? 'the farmer') . ' to confirm.',
            '/order-details?id=' . $order->id
        );
    }

    /** Status moved along by the farmer → tell the client what to do next. */
    public static function orderStatusChanged(Order $order): void
    {
        $order->loadMissing(['farmer']);

        $title = match ($order->status) {
            Order::ST_CONFIRMED => 'Order ' . $order->code() . ' accepted',
            Order::ST_READY => 'Order ' . $order->code() . ' is ready for pickup',
            Order::ST_COMPLETED => 'Order ' . $order->code() . ' completed',
            Order::ST_CANCELLED => 'Order ' . $order->code() . ' cancelled',
            default => 'Order ' . $order->code() . ' updated',
        };

        $body = match ($order->status) {
            Order::ST_READY => 'Collect at ' . ($order->market ?: 'the market')
                . ($order->pickup_slot ? ' — ' . $order->pickup_slot : ''),
            Order::ST_CONFIRMED => ($order->farmer?->displayName() ?? 'The farmer') . ' will have it ready on ' . ($order->pickup_date ?? 'pickup day') . '.',
            Order::ST_CANCELLED => 'Any reserved stock has been returned to the stall.',
            default => $order->statusLabel() . ' — ' . ($order->pickup_date ?? ''),
        };

        self::send($order->customer, 'order_status', $title, $body, '/order-details?id=' . $order->id);
    }

    /** Farmer replied to a review → tell the reviewer. */
    public static function reviewReply(\App\Models\Review $review): void
    {
        $review->loadMissing(['customer', 'farmer']);

        self::send(
            $review->customer,
            'review_reply',
            ($review->farmer?->displayName() ?? 'The farmer') . ' replied to your review',
            mb_strimwidth((string) $review->farmer_reply, 0, 140, '…'),
            '/customer-reviews'
        );
    }

    /** A favourited product is back in stock → restock alert. */
    public static function productRestocked(Product $product): void
    {
        $customers = User::whereIn('id', function ($q) use ($product) {
            $q->select('customer_id')->from('favorites')->where('product_id', $product->id);
        })->get();

        foreach ($customers as $customer) {
            self::send(
                $customer,
                'restock',
                $product->name . ' is back in stock',
                'A product you saved has ' . $product->stock . ' ' . $product->unit . ' available at PKR ' . number_format((float) $product->price, 0) . '.',
                '/product-details?id=' . $product->id
            );
        }
    }
}
