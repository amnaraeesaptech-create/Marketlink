<?php

namespace App\Support;

/**
 * Offline-safe placeholder images.
 *
 * The app ships no stock photography: every "missing image" is rendered as a
 * small inline SVG (data URI) built from the real record's own name. That keeps
 * the UI honest (no fake photos) and works without any network access.
 */
class Placeholder
{
    private const PALETTE = [
        '#2e7d32', '#388e3c', '#43a047', '#558b2f',
        '#33691e', '#00695c', '#00796b', '#ef6c00',
    ];

    /** Deterministic, colour-coded SVG tile with the label's initials. */
    public static function image(string $label, ?string $seed = null, int $w = 300, int $h = 300): string
    {
        $bg = self::PALETTE[abs(crc32((string) ($seed ?? $label))) % count(self::PALETTE)];
        $text = self::escape(self::initials($label));
        $fontSize = (int) max(18, min($w, $h) / 3);

        $svg = '<svg xmlns="http://www.w3.org/2000/svg" width="' . $w . '" height="' . $h . '" viewBox="0 0 ' . $w . ' ' . $h . '">'
            . '<rect width="100%" height="100%" fill="' . $bg . '"/>'
            . '<circle cx="' . ($w - 18) . '" cy="18" r="' . max(6, $w / 22) . '" fill="#ffffff" opacity="0.15"/>'
            . '<text x="50%" y="52%" fill="#ffffff" font-family="Helvetica,Arial,sans-serif" font-weight="700"'
            . ' font-size="' . $fontSize . '" text-anchor="middle" dominant-baseline="middle">' . $text . '</text>'
            . '</svg>';

        return 'data:image/svg+xml,' . rawurlencode($svg);
    }

    /** Wide banner/farm-cover variant. */
    public static function cover(string $label, ?string $seed = null, int $w = 800, int $h = 300): string
    {
        return self::image($label, $seed, $w, $h);
    }

    public static function initials(string $label): string
    {
        $parts = preg_split('/\s+/', trim($label)) ?: [];
        $parts = array_values(array_filter($parts, fn ($p) => $p !== ''));

        if ($parts === []) {
            return 'ML';
        }

        $first = mb_substr($parts[0], 0, 1);
        $second = count($parts) > 1 ? mb_substr($parts[count($parts) - 1], 0, 1) : '';

        return mb_strtoupper($first . $second);
    }

    private static function escape(string $value): string
    {
        return htmlspecialchars($value, ENT_QUOTES | ENT_XML1, 'UTF-8');
    }
}
