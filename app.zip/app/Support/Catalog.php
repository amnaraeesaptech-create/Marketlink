<?php

namespace App\Support;

use App\Models\Market;
use App\Models\Order;
use App\Models\Product;
use App\Models\Review;
use App\Models\User;
use Illuminate\Support\Collection;

/**
 * Single source of truth for the storefront's data.
 *
 * Every method here reads the database. Nothing is hardcoded: the JS listing
 * widgets, the public farmers/markets pages and the dashboards all consume
 * these arrays, so created/updated/deleted records show up everywhere at once.
 */
class Catalog
{
    /** Live + in-stock products, newest first, shaped for the storefront JS. */
    public static function products(): array
    {
        return Product::with('farmer.farmer')->fromApprovedStall()
            ->fromApprovedStall()
            ->where('is_available', true)
            ->where('stock', '>', 0)
            ->latest()
            ->get()
            ->map(fn (Product $p) => [
                'id' => $p->id,
                'name' => $p->name,
                'farmerId' => $p->farmer_id,
                'farmer' => $p->farmer?->displayName() ?? 'Local Farm',
                'price' => (float) $p->price,
                'unit' => $p->unit,
                'category' => $p->category,
                'rating' => (float) ($p->rating ?? 0),
                'stock' => (int) $p->stock,
                'image' => $p->imageUrl(),
                'description' => $p->description ?? '',
                'markets' => $p->markets ?? [],
            ])
            ->all();
    }

    /** Every active farmer stall with their live product/order/rating totals. */
    public static function farmers(): array
    {
        return User::where('role', User::ROLE_FARMER)
            ->where('is_active', true)
            ->whereHas('farmer', fn ($q) => $q->where('is_approved', true))
            ->with(['farmer', 'markets'])
            ->withCount(['products', 'reviewsReceived'])
            ->latest()
            ->get()
            ->map(fn (User $u) => [
                'id' => $u->id,
                'name' => $u->name,
                'stallName' => $u->farmer?->stall_name ?: $u->name,
                'phone' => $u->phone,
                'address' => $u->farmer?->address ?? $u->address,
                'city' => self::cityOf($u->farmer?->address ?? $u->address),
                'description' => $u->farmer?->description,
                'image' => $u->avatarUrl(),
                'coverImage' => $u->farmer?->avatar
                    ? (str_starts_with($u->farmer->avatar, 'http') ? $u->farmer->avatar : '/storage/' . $u->farmer->avatar)
                    : Placeholder::cover($u->farmer?->stall_name ?: $u->name, 'farmer-' . $u->id, 800, 320),
                'markets' => $u->marketNames(),
                'days' => $u->farmer?->operating_days ?? [],
                'pickupWindows' => $u->farmer?->pickup_windows ?? [],
                'categories' => $u->farmer?->categories ?? [],
                'latitude' => $u->farmer?->latitude,
                'longitude' => $u->farmer?->longitude,
                'rating' => $u->averageRating() ?? 0,
                'reviewCount' => $u->reviews_received_count,
                'productCount' => $u->products_count,
                'productsCount' => $u->products_count,
                'specialties' => implode(', ', $u->farmer?->categories ?? []),
            ])
            ->all();
    }

    /** Active markets with their real stall counts. */
    public static function markets(): Collection
    {
        return Market::withCount('farmers')
            ->where('is_active', true)
            ->orderBy('name')
            ->get();
    }

    /** Markets without the active filter (admin screens). */
    public static function allMarkets(): Collection
    {
        return Market::withCount('farmers')->orderBy('name')->get();
    }

    /** Product counts per category, straight from the catalogue. */
    public static function categoryCounts(): array
    {
        $counts = [];

        foreach (\App\Models\Category::names() as $category) {
            $counts[$category] = Product::fromApprovedStall()->where('category', $category)
                ->where('is_available', true)
                ->where('stock', '>', 0)
                ->count();
        }

        return $counts;
    }

    /** Storefront headline numbers (all live). */
    public static function stats(): array
    {
        $rating = Review::avg('rating');

        return [
            'farmers' => User::where('role', User::ROLE_FARMER)->where('is_active', true)->count(),
            'customers' => User::where('role', User::ROLE_CUSTOMER)->where('is_active', true)->count(),
            'products' => Product::fromApprovedStall()->where('is_available', true)->where('stock', '>', 0)->count(),
            'markets' => Market::where('is_active', true)->count(),
            'orders' => Order::count(),
            'reviews' => Review::count(),
            'rating' => $rating === null ? 0 : round((float) $rating, 1),
        ];
    }

    /** Newest reviews that actually have a comment — used as testimonials. */
    public static function testimonials(int $limit = 3): Collection
    {
        return Review::with(['customer', 'farmer.farmer'])
            ->whereNotNull('comment')
            ->where('comment', '!=', '')
            ->latest()
            ->limit($limit)
            ->get();
    }

    /** Best rated live products for the home page. */
    public static function featuredProducts(int $limit = 4): Collection
    {
        return Product::with('farmer.farmer')
            ->where('is_available', true)
            ->where('stock', '>', 0)
            ->orderByDesc('rating')
            ->latest()
            ->limit($limit)
            ->get();
    }

    /** "Chak Shahzad Farms, Islamabad" -> "Islamabad". */
    public static function cityOf(?string $address): string
    {
        if (! $address) {
            return 'Unknown';
        }

        $parts = array_filter(array_map('trim', explode(',', $address)));

        return $parts === [] ? $address : end($parts);
    }
}
