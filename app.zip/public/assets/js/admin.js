/* ==========================================================================
   MarketLink — admin shell behaviour
   - off-canvas sidebar (phones/tablets)
   - live filtering of admin tables & review cards (client-side, over the
     rows the server rendered from the database)
   - CSV export of the table the admin is looking at
   ========================================================================== */
(function () {
  'use strict';

  /* ---------------- off-canvas sidebar ---------------- */
  function initSidebar() {
    var sidebar = document.getElementById('adminSidebar');
    var toggle = document.querySelector('[data-admin-menu]');
    var backdrop = document.getElementById('adminBackdrop');
    if (!sidebar || !toggle) return;

    var open = function () {
      sidebar.classList.add('show');
      if (backdrop) backdrop.classList.add('show');
      toggle.setAttribute('aria-expanded', 'true');
      document.body.style.overflow = 'hidden';
    };
    var close = function () {
      sidebar.classList.remove('show');
      if (backdrop) backdrop.classList.remove('show');
      toggle.setAttribute('aria-expanded', 'false');
      document.body.style.overflow = '';
    };
    var isOpen = function () { return sidebar.classList.contains('show'); };

    toggle.addEventListener('click', function () { isOpen() ? close() : open(); });
    if (backdrop) backdrop.addEventListener('click', close);
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && isOpen()) close(); });
    sidebar.querySelectorAll('a').forEach(function (a) { a.addEventListener('click', close); });
    window.addEventListener('resize', function () { if (window.innerWidth > 991 && isOpen()) close(); });
  }

  /* ---------------- table filtering ---------------- */
  function cellText(row, index) {
    var cell = row.cells[index];
    return cell ? cell.textContent.replace(/\s+/g, ' ').trim().toLowerCase() : '';
  }

  function applyTableFilters(table) {
    var search = document.querySelector('[data-table-filter="#' + table.id + '"]');
    var selects = Array.prototype.slice.call(document.querySelectorAll('[data-table-select="#' + table.id + '"]'));
    var needle = search ? search.value.toLowerCase().trim() : '';
    var body = table.tBodies[0];
    if (!body) return;

    var rows = Array.prototype.slice.call(body.rows);
    var shown = 0;

    rows.forEach(function (row) {
      if (row.dataset.filterEmpty === '1') return; // "no records" placeholder row
      var ok = !needle || row.textContent.toLowerCase().indexOf(needle) !== -1;

      if (ok) {
        selects.forEach(function (sel) {
          if (!sel.value) return;
          var want = sel.value.toLowerCase();
          var have = cellText(row, parseInt(sel.dataset.col, 10) || 0);
          if (have.indexOf(want) === -1) ok = false;
        });
      }
      row.style.display = ok ? '' : 'none';
      if (ok) shown++;
    });

    var counter = document.querySelector('[data-table-count="#' + table.id + '"]');
    if (counter) counter.textContent = shown + ' of ' + rows.length + ' shown';

    var empty = document.querySelector('[data-table-noresult="#' + table.id + '"]');
    if (empty) empty.style.display = shown === 0 && rows.length ? '' : 'none';
  }

  function initTables() {
    var tables = Array.prototype.slice.call(document.querySelectorAll('table[id][data-filterable]'));
    if (!tables.length) return;

    tables.forEach(function (table) {
      Array.prototype.slice.call(document.querySelectorAll('[data-table-filter="#' + table.id + '"]')).forEach(function (el) {
        el.addEventListener('input', function () { applyTableFilters(table); });
        el.addEventListener('search', function () { applyTableFilters(table); });
      });
      Array.prototype.slice.call(document.querySelectorAll('[data-table-select="#' + table.id + '"]')).forEach(function (el) {
        el.addEventListener('change', function () { applyTableFilters(table); });
      });
      var reset = document.querySelector('[data-table-reset="#' + table.id + '"]');
      if (reset) {
        reset.addEventListener('click', function (e) {
          e.preventDefault();
          var s = document.querySelector('[data-table-filter="#' + table.id + '"]');
          if (s) s.value = '';
          Array.prototype.slice.call(document.querySelectorAll('[data-table-select="#' + table.id + '"]')).forEach(function (sel) { sel.value = ''; });
          applyTableFilters(table);
        });
      }
    });
  }

  /* ---------------- review-card filtering (admin reviews page) ---------------- */
  function initCardFilters() {
    var cards = Array.prototype.slice.call(document.querySelectorAll('[data-card-item]'));
    var select = document.querySelector('[data-card-select]');
    var search = document.querySelector('[data-card-search]');
    if (!cards.length || (!select && !search)) return;

    var apply = function () {
      var rating = select ? select.value : '';
      var needle = search ? search.value.toLowerCase().trim() : '';
      var shown = 0;
      cards.forEach(function (card) {
        var ok = true;
        if (rating && String(card.dataset.rating || '') !== rating) ok = false;
        if (ok && needle && (card.dataset.search || '').indexOf(needle) === -1) ok = false;
        card.style.display = ok ? '' : 'none';
        if (ok) shown++;
      });
      var counter = document.querySelector('[data-card-count]');
      if (counter) counter.textContent = shown + ' of ' + cards.length + ' shown';
      var empty = document.querySelector('[data-card-noresult]');
      if (empty) empty.style.display = shown === 0 ? '' : 'none';
    };

    if (select) select.addEventListener('change', apply);
    if (search) { search.addEventListener('input', apply); search.addEventListener('search', apply); }
  }

  /* ---------------- CSV export of a real table ---------------- */
  function initExport() {
    document.querySelectorAll('[data-export-table]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        var table = document.querySelector(btn.dataset.exportTable);
        if (!table) return;

        var rows = [];
        var head = Array.prototype.slice.call(table.tHead ? table.tHead.rows[0].cells : [])
          .map(function (c) { return c.textContent.replace(/\s+/g, ' ').trim(); });
        rows.push(head);

        Array.prototype.slice.call(table.tBodies[0].rows).forEach(function (r) {
          if (r.style.display === 'none' || r.dataset.filterEmpty === '1') return;
          rows.push(Array.prototype.slice.call(r.cells).map(function (c) {
            return c.textContent.replace(/\s+/g, ' ').trim().replace(/"/g, '""');
          }));
        });

        var csv = rows.map(function (r) {
          return r.map(function (v) { return '"' + v + '"'; }).join(',');
        }).join('\r\n');

        var url = URL.createObjectURL(new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' }));
        var a = document.createElement('a');
        a.href = url;
        a.download = (btn.dataset.exportName || 'marketlink-export') + '-' + new Date().toISOString().slice(0, 10) + '.csv';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      });
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    initSidebar();
    initTables();
    initCardFilters();
    initExport();
  });
})();
