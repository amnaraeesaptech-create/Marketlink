// js/chatbot.js

const chatbotHTML = `
<div id="ml-chatbot-container" style="position: fixed; bottom: 20px; right: 20px; z-index: 9999; font-family: 'Poppins', sans-serif;">
    <!-- Chatbot Toggle Button -->
    <button id="ml-chatbot-toggle" class="btn btn-success rounded-circle animate-pulse shadow-lg" style="width: 60px; height: 60px; display: flex; align-items: center; justify-content: center; border: none; background-color: #28a745;">
        <i class="fas fa-comment-dots fa-2x text-white"></i>
    </button>

    <!-- Chatbot Widget -->
    <div id="ml-chatbot-widget" class="card shadow-lg d-none" style="width: 360px; height: 500px; position: absolute; bottom: 80px; right: 0; border-radius: 15px; overflow: hidden; display: flex; flex-direction: column; background-color: white;">
        
        <!-- Header -->
        <div class="card-header bg-success text-white d-flex justify-content-between align-items-center" style="border-bottom: none; padding: 15px;">
            <div class="d-flex align-items-center">
                <div class="bg-white text-success rounded-circle d-flex justify-content-center align-items-center me-2" style="width: 35px; height: 35px;">
                    <i class="fas fa-seedling"></i>
                </div>
                <div>
                    <h6 class="mb-0 fw-bold">MarketLink AI</h6>
                    <small style="font-size: 0.75rem; opacity: 0.8;">Online | Local Assistant</small>
                </div>
            </div>
            <button id="ml-chatbot-close" class="btn text-white p-0" style="background: transparent; border: none;">
                <i class="fas fa-times fa-lg"></i>
            </button>
        </div>

        <!-- Chat Area -->
        <div id="ml-chatbot-messages" class="card-body bg-light" style="flex-grow: 1; overflow-y: auto; padding: 15px;">
            <!-- Welcome Message -->
            <div class="d-flex mb-3 animate-chatBubblePop">
                <div class="bg-success text-white rounded-circle d-flex justify-content-center align-items-center me-2 flex-shrink-0" style="width: 30px; height: 30px; align-self: flex-end;">
                    <i class="fas fa-seedling" style="font-size: 0.8rem;"></i>
                </div>
                <div class="bg-white p-2 shadow-sm rounded-3" style="max-width: 80%; border-bottom-left-radius: 0;">
                    <p class="mb-0" style="font-size: 0.9rem; color: #333;">Hi! I am the MarketLink Assistant. I can help you find markets, farmers, and fresh products. What would you like to know?</p>
                </div>
            </div>
            
            <!-- Quick Replies -->
            <div class="d-flex flex-wrap gap-2 mb-3" id="ml-chatbot-quick-replies">
                <button class="btn btn-sm btn-outline-success rounded-pill chat-quick-reply" style="font-size: 0.8rem;">Where can I find tomatoes?</button>
                <button class="btn btn-sm btn-outline-success rounded-pill chat-quick-reply" style="font-size: 0.8rem;">Which markets are open today?</button>
                <button class="btn btn-sm btn-outline-success rounded-pill chat-quick-reply" style="font-size: 0.8rem;">Find me fresh organic eggs</button>
            </div>
        </div>

        <!-- Input Area -->
        <div class="card-footer bg-white p-2" style="border-top: 1px solid #eee;">
            <div class="input-group">
                <button class="btn btn-link text-muted" type="button" style="text-decoration: none;">
                    <i class="fas fa-paperclip"></i>
                </button>
                <input type="text" id="ml-chatbot-input" class="form-control border-0" placeholder="Type your message..." style="box-shadow: none; font-size: 0.9rem;" autocomplete="off">
                <button id="ml-chatbot-send" class="btn text-success" type="button" style="background: transparent; border: none;">
                    <i class="fas fa-paper-plane fa-lg"></i>
                </button>
            </div>
        </div>
    </div>
</div>
`;

// Only inject if not on the main ai-assistant page
if (!document.getElementById('ai-assistant-page-marker')) {
    document.addEventListener('DOMContentLoaded', () => {
        document.body.insertAdjacentHTML('beforeend', chatbotHTML);
        initChatbot();
    });
}

function initChatbot() {
    const toggleBtn = document.getElementById('ml-chatbot-toggle');
    const closeBtn = document.getElementById('ml-chatbot-close');
    const widget = document.getElementById('ml-chatbot-widget');
    const messagesContainer = document.getElementById('ml-chatbot-messages');
    const inputField = document.getElementById('ml-chatbot-input');
    const sendBtn = document.getElementById('ml-chatbot-send');
    const quickReplies = document.querySelectorAll('.chat-quick-reply');

    // Toggle widget
    toggleBtn.addEventListener('click', () => {
        widget.classList.toggle('d-none');
        if (!widget.classList.contains('d-none')) {
            inputField.focus();
        }
    });

    closeBtn.addEventListener('click', () => {
        widget.classList.add('d-none');
    });

    // Send Message Event
    sendBtn.addEventListener('click', handleSendMessage);
    inputField.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') handleSendMessage();
    });

    // Quick Replies
    quickReplies.forEach(btn => {
        btn.addEventListener('click', function() {
            inputField.value = this.innerText;
            handleSendMessage();
            document.getElementById('ml-chatbot-quick-replies').style.display = 'none';
        });
    });

    function handleSendMessage() {
        const text = inputField.value.trim();
        if (text === '') return;
        
        // Add User Message
        addUserMessage(text);
        inputField.value = '';

        // Hide quick replies if visible
        const qrContainer = document.getElementById('ml-chatbot-quick-replies');
        if(qrContainer) qrContainer.style.display = 'none';

        // Add Bot Typing indicator (optional, but let's just go direct to response with slight delay)
        setTimeout(() => {
            const response = getBotResponse(text);
            addBotMessage(response);
        }, 600);
    }

    function addUserMessage(text) {
        const html = `
        <div class="d-flex mb-3 justify-content-end animate-chatBubblePop">
            <div class="bg-success text-white p-2 shadow-sm rounded-3" style="max-width: 80%; border-bottom-right-radius: 0;">
                <p class="mb-0" style="font-size: 0.9rem;">${escapeHTML(text)}</p>
            </div>
        </div>`;
        messagesContainer.insertAdjacentHTML('beforeend', html);
        scrollToBottom();
    }

    function addBotMessage(text) {
        // Create element
        const wrapper = document.createElement('div');
        wrapper.className = 'd-flex mb-3 animate-chatBubblePop';
        
        const avatar = document.createElement('div');
        avatar.className = 'bg-success text-white rounded-circle d-flex justify-content-center align-items-center me-2 flex-shrink-0';
        avatar.style = 'width: 30px; height: 30px; align-self: flex-end;';
        avatar.innerHTML = '<i class="fas fa-seedling" style="font-size: 0.8rem;"></i>';
        
        const bubble = document.createElement('div');
        bubble.className = 'bg-white p-2 shadow-sm rounded-3';
        bubble.style = 'max-width: 80%; border-bottom-left-radius: 0;';
        
        const p = document.createElement('p');
        p.className = 'mb-0';
        p.style = 'font-size: 0.9rem; color: #333;';
        
        bubble.appendChild(p);
        wrapper.appendChild(avatar);
        wrapper.appendChild(bubble);
        messagesContainer.appendChild(wrapper);
        
        // Typewriter effect
        let i = 0;
        function typeWriter() {
            if (i < text.length) {
                p.innerHTML += text.charAt(i);
                i++;
                scrollToBottom();
                setTimeout(typeWriter, 15);
            }
        }
        typeWriter();
    }

    function scrollToBottom() {
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }

    function escapeHTML(str) {
        return str.replace(/[&<>'"]/g, 
            tag => ({
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                "'": '&#39;',
                '"': '&quot;'
            }[tag] || tag)
        );
    }
}

// Responses are built from the LIVE catalogue (window.ML, served from the
// database by /data-feed.js). No hardcoded farms, prices or market names.
window.getBotResponse = function (input) {
    var ML = window.ML || { products: [], markets: [], farmers: [], categories: [] };
    var q = (input || '').toLowerCase().trim();
    var products = ML.products || [];
    var markets = ML.markets || [];
    var farmers = ML.farmers || [];
    var money = function (n) { return 'PKR ' + (parseFloat(n) || 0).toLocaleString('en-PK'); };
    var list = function (arr, n) { return arr.slice(0, n || 3).join(', '); };

    // 1. Direct product match (tomatoes, eggs, milk, apples ...)
    var words = q.split(/[^a-z]+/).filter(function (w) { return w.length > 2; });
    var matches = products.filter(function (p) {
        return words.some(function (w) {
            return (p.name || '').toLowerCase().indexOf(w) !== -1 ||
                   (p.category || '').toLowerCase().indexOf(w) !== -1;
        });
    });
    if (matches.length) {
        return matches.slice(0, 3).map(function (p) {
            return p.name + ' — ' + money(p.price) + '/' + (p.unit || 'item') +
                   ' from ' + (p.farmer || 'a local stall') +
                   (p.stock ? ' (' + p.stock + ' left)' : '');
        }).join('\n') + '\nYou can pre-order these from the Products page.';
    }

    // 2. Markets open today
    if (q.indexOf('open') !== -1 || q.indexOf('today') !== -1) {
        var day = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][new Date().getDay()];
        var openToday = markets.filter(function (m) { return (m.days || []).indexOf(day) !== -1; });
        if (!openToday.length) {
            return 'No market is scheduled for ' + day + ' right now. There are ' + markets.length +
                   ' markets on MarketLink — check the Markets page for their opening days.';
        }
        return 'Open today (' + day + '): ' + openToday.map(function (m) {
            return m.name + (m.city ? ' in ' + m.city : '');
        }).join('; ') + '.';
    }

    // 3. Pickup timings
    if (q.indexOf('pickup') !== -1 || q.indexOf('timing') !== -1 || q.indexOf('hours') !== -1) {
        if (!markets.length) return 'No pickup windows have been published yet.';
        return 'Pickup windows: ' + markets.slice(0, 4).map(function (m) {
            return m.name + ' (' + ((m.days || []).join('/') || 'days TBA') + ')';
        }).join('; ') + '. Farmers also list their own windows on their stall pages.';
    }

    // 4. Category questions (dairy, vegetables, fruits, meat, baked goods)
    var cat = (ML.categories || []).filter(function (c) { return q.indexOf(c.toLowerCase()) !== -1; })[0];
    if (cat) {
        var inCat = products.filter(function (p) { return p.category === cat; });
        if (!inCat.length) return 'Nothing in ' + cat + ' is listed right now — check back after the next harvest.';
        return cat + ' currently available: ' + inCat.slice(0, 4).map(function (p) {
            return p.name + ' (' + money(p.price) + '/' + p.unit + ') from ' + p.farmer;
        }).join('; ') + '.';
    }

    // 5. Market questions
    if (q.indexOf('market') !== -1) {
        if (!markets.length) return 'No markets have been added yet.';
        return 'MarketLink has ' + markets.length + ' market' + (markets.length === 1 ? '' : 's') + ': ' +
               list(markets.map(function (m) { return m.name + ' — ' + (m.farmerCount || 0) + ' stall(s)'; }), 4) + '.';
    }

    // 6. Farmer / stall questions
    if (q.indexOf('farmer') !== -1 || q.indexOf('stall') !== -1) {
        if (!farmers.length) return 'No farmer stalls are registered yet.';
        return farmers.length + ' stalls are on MarketLink. Top rated: ' +
               list(farmers.slice().sort(function (a, b) { return (b.rating || 0) - (a.rating || 0); })
                   .map(function (f) {
                       return f.stallName + (f.rating ? ' (' + Number(f.rating).toFixed(1) + ')' : '') +
                              ' — ' + (f.productCount || 0) + ' products';
                   }), 3) + '.';
    }

    // 7. Ratings / reviews
    if (q.indexOf('review') !== -1 || q.indexOf('rating') !== -1) {
        var rated = farmers.filter(function (f) { return f.rating > 0; });
        if (!rated.length) return 'No reviews have been written yet — reviews can be left after a completed pickup.';
        return 'Stall ratings come from real completed orders. Highest: ' +
               list(rated.sort(function (a, b) { return b.rating - a.rating; })
                   .map(function (f) { return f.stallName + ' ' + Number(f.rating).toFixed(1) + '/5 (' + f.reviewCount + ' reviews)'; }), 3) + '.';
    }

    // 8. Fallback
    return 'I read the live catalogue: ' + products.length + ' products, ' + farmers.length +
           ' stalls and ' + markets.length + ' markets right now. Ask me about a product (e.g. "tomatoes"), ' +
           'a category, which markets are open today, or pickup timings.';
};

/* ---------- Full-page AI Assistant (/ai-assistant) ---------- */
document.addEventListener('DOMContentLoaded', function () {
    var win = document.getElementById('full-chat-window');
    var input = document.getElementById('full-chat-input');
    var send = document.getElementById('full-chat-send');
    if (!win || !input || !send) return;

    function esc(s) {
        return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
        });
    }
    function scrollWin() { win.scrollTop = win.scrollHeight; }
    function addUser(text) {
        win.insertAdjacentHTML('beforeend',
            '<div class="user-message-wrapper animate-chatBubblePop"><div class="message-bubble user-message">' + esc(text) + '</div></div>');
        scrollWin();
    }
    function addBot(text) {
        win.insertAdjacentHTML('beforeend',
            '<div class="bot-message-wrapper animate-chatBubblePop"><div class="bot-avatar"><i class="fas fa-seedling"></i></div>' +
            '<div class="message-bubble bot-message">' + esc(text) + '</div></div>');
        scrollWin();
    }
    function handleSend() {
        var t = input.value.trim();
        if (!t) return;
        addUser(t);
        input.value = '';
        setTimeout(function () { addBot(window.getBotResponse(t)); }, 500);
    }
    send.addEventListener('click', handleSend);
    input.addEventListener('keypress', function (e) { if (e.key === 'Enter') handleSend(); });
    document.querySelectorAll('.suggestion-btn').forEach(function (b) {
        b.addEventListener('click', function () { input.value = b.textContent.trim(); handleSend(); });
    });
});
