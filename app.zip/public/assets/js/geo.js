/**
 * MarketLink — geo.js
 * Shared geolocation + Haversine distance utilities.
 * Used by: /markets, /farmers, /preorder
 */
(function (global) {
    'use strict';

    /** Haversine distance in km between two lat/lng pairs. */
    function haversine(lat1, lng1, lat2, lng2) {
        var R = 6371; // Earth radius km
        var dLat = (lat2 - lat1) * Math.PI / 180;
        var dLng = (lng2 - lng1) * Math.PI / 180;
        var a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
            + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180)
            * Math.sin(dLng / 2) * Math.sin(dLng / 2);
        return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    }

    /** Format km distance for display. */
    function fmtDist(km) {
        if (km < 1) return Math.round(km * 1000) + ' m away';
        return km.toFixed(1) + ' km away';
    }

    /**
     * Request the user's location once, cache it in sessionStorage, then
     * call `callback(lat, lng)`. Calls `onDeny()` if permission is denied.
     */
    function getLocation(callback, onDeny) {
        var cached = null;
        try { cached = JSON.parse(sessionStorage.getItem('ml_user_loc')); } catch (e) {}
        if (cached && cached.lat && cached.lng) {
            callback(cached.lat, cached.lng);
            return;
        }
        if (!navigator.geolocation) {
            if (onDeny) onDeny('not_supported');
            return;
        }
        navigator.geolocation.getCurrentPosition(
            function (pos) {
                var loc = { lat: pos.coords.latitude, lng: pos.coords.longitude };
                try { sessionStorage.setItem('ml_user_loc', JSON.stringify(loc)); } catch (e) {}
                callback(loc.lat, loc.lng);
            },
            function (err) {
                if (onDeny) onDeny(err.code);
            },
            { enableHighAccuracy: false, timeout: 8000, maximumAge: 60000 }
        );
    }

    /**
     * Attach distance badges to a grid of cards.
     *
     * Options:
     *   items      — NodeList/Array of card wrapper elements
     *   getLat     — fn(el) -> number|null  latitude for the item
     *   getLng     — fn(el) -> number|null  longitude for the item
     *   badgeClass — CSS class for the badge container (default 'ml-dist-badge')
     *   insertInto — fn(el, badgeEl) inserts the badge into the card element
     */
    function attachDistanceBadges(userLat, userLng, options) {
        var items = Array.from(options.items || []);
        items.forEach(function (el) {
            var lat = parseFloat(options.getLat(el));
            var lng = parseFloat(options.getLng(el));
            if (!lat || !lng) return;

            var dist = haversine(userLat, userLng, lat, lng);
            el.dataset.dist = dist; // numeric, used for sorting

            // Remove any existing badge
            var old = el.querySelector('.' + (options.badgeClass || 'ml-dist-badge'));
            if (old) old.remove();

            var badge = document.createElement('span');
            badge.className = (options.badgeClass || 'ml-dist-badge')
                + ' badge bg-success-subtle text-success-emphasis border border-success-subtle small';
            badge.style.cssText = 'font-size:0.72rem;font-weight:500;';
            badge.innerHTML = '<i class="fas fa-location-arrow me-1" style="font-size:0.6rem;"></i>' + fmtDist(dist);

            options.insertInto(el, badge);
        });
    }

    /**
     * Sort a grid's direct children by data-dist (ascending = nearest first).
     * Items without data-dist float to the end.
     */
    function sortByNearest(gridEl) {
        var children = Array.from(gridEl.children);
        children.sort(function (a, b) {
            var da = parseFloat(a.dataset.dist);
            var db = parseFloat(b.dataset.dist);
            var hasA = !isNaN(da);
            var hasB = !isNaN(db);
            if (hasA && hasB) return da - db;
            if (hasA) return -1;
            if (hasB) return 1;
            return 0;
        });
        children.forEach(function (c) { gridEl.appendChild(c); });
    }

    // Expose
    global.MLGeo = { haversine: haversine, fmtDist: fmtDist, getLocation: getLocation, attachDistanceBadges: attachDistanceBadges, sortByNearest: sortByNearest };

}(window));
